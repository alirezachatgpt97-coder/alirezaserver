#!/usr/bin/env python3
"""Rebuild the original application's payload from readable core/alirezabot."""
import base64,gzip,hashlib,io,json,pathlib,tarfile
root=pathlib.Path(__file__).resolve().parents[1];source=root/'core/alirezabot';out=io.BytesIO()
with gzip.GzipFile(fileobj=out,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as tar:
  for p in sorted(source.rglob('*')):
   if not p.is_file() or '__pycache__' in p.parts:continue
   info=tar.gettarinfo(str(p),arcname=p.relative_to(source).as_posix());info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
   with p.open('rb') as f:tar.addfile(info,f)
data=out.getvalue();(root/'addon/alirezabot-source.tar.b64').write_text(base64.encodebytes(data).decode())
p=root/'addon/reference-versions.json';v=json.loads(p.read_text());v['bot']['packagedSHA256']=hashlib.sha256(data).hexdigest();p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print('Bot payload:',len(data),'SHA256',v['bot']['packagedSHA256'])
