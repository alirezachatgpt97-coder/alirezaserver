#!/usr/bin/env python3
"""Package full installer + compressed modular source for GitHub browser upload."""
import hashlib,pathlib,subprocess,sys,tempfile,zipfile
root=pathlib.Path(__file__).resolve().parents[1]
target=pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'alirezaserver-rc14-web-upload.zip'
with tempfile.TemporaryDirectory(dir=root.parent,prefix='web-package-') as temp:
 temp=pathlib.Path(temp);source=temp/'source-code.zip'
 subprocess.run([sys.executable,str(root/'tools/package.py'),str(source)],check=True)
 files={name:(root/name).read_bytes() for name in ['README.md','install.sh','setup.sh','CHANGELOG.md','SOURCES.md','LICENSE']}
 files.update({p.relative_to(root).as_posix():p.read_bytes() for p in (root/'docs').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.txt','.log']})
 files['source-code.zip']=source.read_bytes()
 files['SHA256SUMS']=''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n' for k,v in sorted(files.items())).encode()
 assert len(files)<100, 'GitHub browser upload file count exceeded'
 assert all(len(v)<25*1024*1024 for v in files.values()),'GitHub per-file limit exceeded'
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for name,data in sorted(files.items()):
   info=zipfile.ZipInfo(name,(2026,10,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o100755 if name in ['install.sh','setup.sh'] else 0o100644)<<16;archive.writestr(info,data)
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None
  for line in z.read('SHA256SUMS').decode().splitlines():
   digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
 print('Web upload package:',target.name,'files:',len(files),'bytes:',target.stat().st_size,'sha256:',hashlib.sha256(target.read_bytes()).hexdigest())
