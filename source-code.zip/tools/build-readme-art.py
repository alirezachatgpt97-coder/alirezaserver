#!/usr/bin/env python3
"""Small decorative animated README banner; requires Pillow only at development time."""
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import math
out=Path(__file__).resolve().parents[1]/'docs/alirezaserver-banner.gif';frames=[]
font=ImageFont.load_default(size=38);small=ImageFont.load_default(size=16)
for i in range(20):
 im=Image.new('RGB',(960,210),'#080e1c');d=ImageDraw.Draw(im)
 for x in range(0,960,32):d.line((x,0,x,210),fill='#101d33')
 for y in range(0,210,32):d.line((0,y,960,y),fill='#101d33')
 for n in range(4):
  x=int((i*32+n*240)%1100)-70;d.line((x,0,x+120,210),fill=(15,46+n*7,65+n*12),width=5)
 pulse=int(140+80*math.sin(i*math.pi/10));d.rounded_rectangle((28,28,932,182),radius=22,fill='#0e1729',outline=(20,pulse,210),width=2)
 d.text((62,58),'ALIREZASERVER',font=font,fill='#e7f5ff')
 d.text((64,120),'NOVA  /  ALIREZABOT  /  SECURE CONTROL  /  ALIREZA CLI',font=small,fill='#73dce7')
 d.ellipse((866,65,882,81),fill=(25,pulse,180));frames.append(im)
frames[0].save(out,save_all=True,append_images=frames[1:],duration=90,loop=0,optimize=True)
print(out)
