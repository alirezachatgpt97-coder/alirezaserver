#!/usr/bin/env python3
"""Patch the verified Nova Xray download and defer trusted TLS until integration is ready."""
import pathlib,sys
OLD='if bash "$XRAY_SH" "${XRAY_ARGS[@]}" >"$XRAY_LOG" 2>&1; then'
NEW='''# Bound the entire child process group, including the installer's own curl.
  # XTLS defines its own curl function, so exporting a wrapper is insufficient.
  say "Xray upstream installation: live output; maximum 240 seconds, then verified mirror fallback."
  if timeout --signal=TERM --kill-after=10s 240s bash "$XRAY_SH" "${XRAY_ARGS[@]}" 2>&1 | tee "$XRAY_LOG"; then'''
def patch(source):
    replacements=[(OLD,NEW),
      ('curl -fsSL --max-time 60 -o "$out" "$u" 2>/dev/null','curl -fSL --connect-timeout 15 --max-time 60 --speed-time 30 --speed-limit 1024 --proto "=https" --proto-redir "=https" -o "$out" "$u"'),
      ('curl -fsSL --max-time 30 -H "Accept: application/vnd.github.v3+json"','curl -fsSL --connect-timeout 15 --max-time 30 -H "Accept: application/vnd.github.v3+json"'),
      ('curl -fsSL --max-time 300 --proto-redir \'=https\' "$XRAY_MIRROR_BASE/$_asset"','curl -fSL --connect-timeout 20 --max-time 300 --speed-time 30 --speed-limit 1024 --proto \'=https\' --proto-redir \'=https\' "$XRAY_MIRROR_BASE/$_asset"'),
      ('install -m 0755 "$_d/xray" /usr/local/bin/xray', 'timeout --kill-after=2s 10s "$_d/xray" version >/dev/null 2>&1 || { rm -rf "$_d"; return 1; }\n  install -m 0755 "$_d/xray" /usr/local/bin/xray'),
      ('XRAY_BIN="$(command -v xray || echo /usr/local/bin/xray)"\nok "xray', 'XRAY_BIN="$(command -v xray || echo /usr/local/bin/xray)"\ntimeout --kill-after=2s 10s "$XRAY_BIN" version >/dev/null 2>&1 || die "xray binary is missing or unusable; installation is incomplete."\nok "xray')]
    for old,new in replacements:
        if source.count(old)!=1:raise ValueError('Unsupported Nova installer contract: '+old[:65])
        source=source.replace(old,new)
    domain_anchor="if [ -n \"${NOVA_DOMAIN:-}\" ]; then\n  say \"Getting a certificate for $NOVA_DOMAIN (Let's Encrypt)\""
    if source.count(domain_anchor)!=1:raise ValueError('Unsupported Nova TLS installer contract')
    source=source.replace(domain_anchor,domain_anchor.replace('if [ -n "${NOVA_DOMAIN:-}" ]; then','if [ -n "${NOVA_DOMAIN:-}" ] && [ "${ALIREZA_DEFER_TLS:-0}" != 1 ]; then'))
    source += '\n# Preserve the requested identity for post-integration certificate verification.\nif [ "${ALIREZA_DEFER_TLS:-0}" = 1 ]; then\n  install -d -m 700 /var/lib/alirezaserver\n  if [ -n "${NOVA_DOMAIN:-}" ]; then\n    printf "%s\\n" "$NOVA_DOMAIN" > /var/lib/alirezaserver/requested-domain\n    chmod 600 /var/lib/alirezaserver/requested-domain\n  fi\n  if [ -n "${PUBIP:-}" ]; then\n    printf "%s\\n" "$PUBIP" > /var/lib/alirezaserver/origin-ip\n    chmod 600 /var/lib/alirezaserver/origin-ip\n  fi\n  printf "%s\\n" "${NOVA_DOMAIN_EMAIL:-}" > /var/lib/alirezaserver/requested-email\n  chmod 600 /var/lib/alirezaserver/requested-email\nfi\n'
    return source
if __name__=='__main__':
    p=pathlib.Path(sys.argv[1]);s=patch(p.read_text());p.write_text(s)
