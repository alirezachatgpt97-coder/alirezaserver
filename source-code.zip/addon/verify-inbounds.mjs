// SPDX-License-Identifier: GPL-3.0-or-later
// Shared by the production installer verifier and regression tests.
export async function verifyInbounds(get,base){
 const old=await get('/alireza/openvpn/');
 if(old.code!==302||old.headers?.location!==(base||'')+'/#inbounds')throw Error('OpenVPN legacy redirect does not reach native Inbounds');
 const components=[['workspace/ui.js','AlirezaUI'],['manual/core.js','AlirezaManualCore'],['manual/editor.js','alirezaManualEditor'],['manual/native.js','alirezaInboundEditor'],['openvpn/inline.js','AlirezaOpenVPN'],['inbounds/ui.js','viewInbounds']];
 for(const [route,marker] of components){const r=await get('/alireza/'+route);if(r.code!==200||!r.body.includes(marker))throw Error('Inbound component unavailable: '+route);}
 const page=await get('/');if(page.code!==200||!page.body.includes('/alireza/openvpn/inline.js')||!page.body.includes('/alireza/manual/native.js'))throw Error('Native panel is missing unified inbound components');
}
