#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Render the single audited Mirza installer template for an isolated instance.
Only a server-derived 24-hex identity enters the template. Secrets enter main()
through JSON after compilation, never through template replacement or argv.
"""
import pathlib,re,json,sys,os,fcntl,signal,subprocess
HERE=pathlib.Path(__file__).resolve().parent
ACTIVE=[]
def tracked_run(args,data=None,timeout=180):
 child=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True);ACTIVE.append(child)
 try:
  try:out,_=child.communicate(data,timeout=timeout)
  except subprocess.TimeoutExpired:raise RuntimeError('COMMAND_TIMEOUT:'+pathlib.Path(args[0]).name)
  if child.returncode:raise RuntimeError('COMMAND_FAILED:'+pathlib.Path(args[0]).name)
  return out
 finally:
  if child.poll() is None:
   try:os.killpg(child.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:
    try:os.killpg(child.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    child.wait()
  ACTIVE.remove(child)
def terminate(*unused):
 for child in list(ACTIVE):
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 raise SystemExit(143)
def render_source(key):
 if not re.fullmatch(r'[a-f0-9]{24}',key):raise RuntimeError('TENANT_INVALID_ID')
 name='azb'+key[:20]
 source=(HERE/'bot-manager.py').read_text().replace('alirezabot',name)
 source=source.replace(name+'-source.tar.b64','alirezabot-source.tar.b64')
 source=source.replace('clear_env=yes','clear_env=yes\nenv[ALIREZABOT_STATE]=/var/lib/'+name)
 # Keep executable PHP/config root-owned. Only runtime assets are writable by
 # the instance identity, so a tenant cannot feed modified PHP to root repair.
 source=source.replace("shutil.chown(APP,user='"+name+"',group='"+name+"')", "shutil.chown(APP,user='root',group='"+name+"')")
 for variable in ['temp','target']:
  source=source.replace("shutil.chown("+variable+",user='"+name+"',group='"+name+"')","shutil.chown("+variable+",user='root',group='"+name+"')")
 begin=source.index("    for path in APP.rglob('*'):")
 end=source.index("    phase('php-runtime',5)",begin)
 block="""    writable=['storage','log','lang/override']
    for path in APP.rglob('*'):
        if path.is_symlink():raise RuntimeError('BOT_SYMLINK_REFUSED')
        rel=path.relative_to(APP).as_posix()
        if any(rel==p or rel.startswith(p+'/') for p in writable):continue
        shutil.chown(path,user='root',group=TENANTNAME)
        os.chmod(path,0o750 if path.is_dir() else 0o640)
    for rel in writable:
        p=APP/rel;p.mkdir(parents=True,exist_ok=True,mode=0o750)
        run(['chown','--no-dereference','-R',TENANTNAME+':'+TENANTNAME,str(p)])
    for rel in ['error_log','panel/error_log','cronbot/error_log','cronbot/.run.lock']:
        p=APP/rel
        if p.is_symlink():raise RuntimeError('BOT_SYMLINK_REFUSED')
        p.touch(exist_ok=True);shutil.chown(p,user=TENANTNAME,group=TENANTNAME);p.chmod(0o640)
""".replace('TENANTNAME',repr(name))
 source=source[:begin]+block+source[end:]
 source=source.replace("backup=STATE/('ui-backup-'", "backup=pathlib.Path(os.environ['ALIREZA_ROOT'])/('ui-backup-'")

 source=source.replace("'User="+name+"\\nGroup="+name+"\\nWorkingDirectory=", "'Environment=ALIREZABOT_STATE=/var/lib/"+name+"\\nUser="+name+"\\nGroup="+name+"\\nWorkingDirectory=")
 # Actual poll template uses a longer unit string: add state before its User line.
 source=source.replace("+common+'User="+name, "+common+'Environment=ALIREZABOT_STATE=/var/lib/"+name+"\\nUser="+name)
 return source
def module_for(key):
 source=render_source(key)
 scope={'__file__':str(HERE/'bot-manager.py'),'__name__':'tenant_bot_template'}
 exec(compile(source,str(HERE/'bot-manager.py'),'exec'),scope)
 scope['run']=tracked_run
 return scope
if __name__=='__main__':
 signal.signal(signal.SIGTERM,terminate)
 try:
  v=json.load(sys.stdin);m=module_for(v.pop('tenantKey',''));state=m['STATE']
  if v.get('operation')=='status':print(json.dumps(m['main'](v)));sys.exit(0)
  state.mkdir(parents=True,exist_ok=True,mode=0o750)
  with os.fdopen(os.open(state/'.operation.lock',os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW,0o600),'a') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   print(json.dumps(m['main'](v)))
 except Exception as e:print(json.dumps({'error':str(e) if isinstance(e,RuntimeError) else type(e).__name__}));sys.exit(1)
