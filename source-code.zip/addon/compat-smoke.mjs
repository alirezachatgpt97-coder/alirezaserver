// SPDX-License-Identifier: GPL-3.0-or-later
// Candidate behavior test in a temporary DB/config tree. No live services or credentials.
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {pathToFileURL} from 'node:url';import assert from 'node:assert/strict';
const dir=path.resolve(process.argv[2]),root=fs.mkdtempSync(path.join(os.tmpdir(),'alireza-compat-'));
Object.assign(process.env,{ALIREZA_NOVA_DIR:dir,ALIREZA_ROOT:root,NOVA_DB:root+'/nova.db',NOVA_NO_EXEC:'1',NOVA_XRAY_CONFIG:root+'/xray/config.json',NOVA_SINGBOX_CONFIG:root+'/sing/config.json',NOVA_CERT_PEM:root+'/origin.pem',NOVA_CERT_KEY:root+'/origin.key'});
let kv,server;
try{
 await import('./host-hooks.mjs');
 const sqlite=await import(pathToFileURL(dir+'/src/kv/sqlite.mjs')),native=await import(pathToFileURL(dir+'/src/server.mjs')),auth=await import(pathToFileURL(dir+'/src/auth.mjs'));
 kv=sqlite.openKv(process.env.NOVA_DB);await auth.setPassword(kv,'ephemeral-compatibility-only');await native.putSettings(kv,{...await native.getSettings(kv),host:'8.8.8.8',insecure:true,panelPath:'compat'});
 server=native.createServer(kv,{managerOpts:{exec:false}});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const {nativeClient}=await import('./native-client.mjs'),{createBridge}=await import('./bot-bridge.mjs'),api=nativeClient(server.address().port,'/compat'),bridge=createBridge(api);
 const identity=await api('/admin/whoami');assert.equal(identity.role,'owner');
 for(const [name,geo] of [['compat-on',true],['compat-off',false]]){const result=await bridge.request('/panel/api/clients/add','POST',{client:{email:name,geoExits:geo},inboundIds:[]});assert.equal(result.success,true);assert.ok(result.obj.configs.length);const user=(await native.getSettings(kv)).users.find(u=>u.name===name);assert.equal(user.geoExits,geo);const link=new URL(result.obj.configs[0]);assert.equal(link.hostname,'8.8.8.8');assert.equal(link.searchParams.get('security'),'tls');assert.equal(link.searchParams.get('type'),'ws');const cfg=JSON.parse(fs.readFileSync(root+'/xray/config.json'));assert.ok(cfg.inbounds.some(i=>i.settings?.clients?.some(c=>c.id===user.uuid)));}
 await bridge.request('/panel/api/clients/update/compat-on','POST',{client:{totalGB:123456}});assert.equal((await bridge.request('/panel/api/clients/get/compat-on')).obj.client.geoExits,true);
 await bridge.request('/panel/api/clients/del/compat-off','POST',{});assert.ok(!(await native.getSettings(kv)).users.find(u=>u.name==='compat-off'));
 const profileModule=await import(pathToFileURL(dir+'/src/xray/inbounds.mjs'));const p=profileModule.normalizeProfile({address:'origin.example',port:443,sni:'tls.example',hostHeader:'host.example',path:'/ws'});assert.equal(p.sni,'tls.example');assert.equal(p.hostHeader,'host.example');
 console.log('Isolated candidate behavior PASS: native owner, bot create/update/delete, per-user country exits, subscriptions, runtime config and host profile');
}finally{if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}kv?.close();fs.rmSync(root,{recursive:true,force:true});}
