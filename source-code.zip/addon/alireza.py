#!/usr/bin/env python3
"""On-demand English root terminal manager. No resident process or password argv."""
import argparse,datetime,getpass,json,os,pathlib,secrets,shutil,socket,ssl,subprocess,sys,urllib.request
APP=pathlib.Path('/opt/alirezaserver')
UNITS={'panel':'nova-agent.service','xray':'xray.service','bot':'alirezabot-php.service','telegram':'alirezabot-poller.service','dns':'AdGuardHome.service'}
def run(args,**kw):return subprocess.run([str(x) for x in args],check=True,**kw)
def bot(operation,**data):return json.loads(run(['node',APP/'bot-control.mjs'],input=json.dumps({'operation':operation,**data}),capture_output=True,text=True).stdout)
def tls_call(value,capture=False):
 return run(['node',APP/'tls-control.mjs'],input=json.dumps(value),capture_output=capture,text=True)
def panels():
 p=run(['nova-access'],capture_output=True,text=True);print(p.stdout,end='')
 for line in p.stdout.splitlines():
  if line.startswith('Panel URL: '):
   url=line.split(': ',1)[1].rstrip('/')+'/'
   for name,tail in [('Bot','bot/web/panel/'),('AI','ai/'),('AdGuard','dns/'),('Remote DNS','alirezadns/')]:print(f'{name:12} {url}alireza/{tail}')
 print('\nInternal sections use the main panel session. OpenVPN is under Inbounds.')
 print('Hashed panel passwords cannot be recovered. Choose Password reset for a new one.')
def openvpn():
 if not sys.stdin.isatty():raise RuntimeError('Credential display requires an interactive terminal.')
 def query(v):return json.loads(run(['node',APP/'terminal-accounts.mjs'],input=json.dumps(v),capture_output=True,text=True).stdout)
 accounts=query({'operation':'list'})
 for n,a in enumerate(accounts,1):print(f"{n:2}. {a['username']} / {'enabled' if a['enabled'] else 'disabled'}")
 if not accounts:print('No OpenVPN accounts configured.');return
 selected=input('Account number (Enter to return): ').strip()
 if not selected:return
 if not selected.isdigit() or not 1<=int(selected)<=len(accounts):raise RuntimeError('Invalid account number.')
 if input('Display the selected password on this terminal? [y/N] ').lower()!='y':return
 c=query({'operation':'credentials','id':accounts[int(selected)-1]['id']});print('Username: '+c['username'])
 print('Password: '+c['password'] if not c.get('needsPassword') else 'Legacy account: set a new password in Inbounds; no recoverable password exists.')
def password(target):
 if not sys.stdin.isatty():raise RuntimeError('Password reset requires an interactive SSH terminal.')
 choice=input('Choose your own password? [y/N] ').strip().lower()
 value=getpass.getpass('New password (12-128 characters): ') if choice=='y' else secrets.token_urlsafe(18)
 if not 12<=len(value)<=128:raise RuntimeError('Password length must be 12-128 characters.')
 if choice=='y' and value!=getpass.getpass('Repeat new password: '):raise RuntimeError('Passwords do not match.')
 if target=='panel':run(['nova-passwd','-'],input=value+'\n',text=True);name='Owner (native Nova sign-in)'
 elif target=='bot':name=bot('reset-password',password=value)['username']
 else:raise RuntimeError('Choose panel or bot. AdGuard uses the existing panel session.')
 print('Username: '+name+'\nNew password: '+value+'\nSave it securely now. It will not be shown again.')
def tls_setup():
 if not sys.stdin.isatty():raise RuntimeError('TLS setup requires an interactive terminal.')
 print('\nTLS SETUP\n1. Trusted public IP certificate (short-lived, automatic renewal)\n2. Domain / HTTP-01 (public port 80 must reach this server)\n3. Domain / Cloudflare DNS-01 (no inbound port 80 validation)')
 mode=input('Mode [1/2/3]: ').strip()
 if mode not in ['1','2','3']:return
 host=input('Public IP address: ' if mode=='1' else 'Domain name: ').strip();email=input('ACME email (optional): ').strip()
 data={'operation':'issue','host':host,'email':email,'method':'cloudflare' if mode=='3' else 'letsencrypt'}
 if mode=='3':
  print('Use Cloudflare Full (strict), not Flexible. Token requires Zone DNS Edit and Zone Read for this zone.')
  data['token']=getpass.getpass('Cloudflare API token (empty = keep connected token): ').strip()
  data['proxied']=input('Enable Cloudflare proxy for this domain? [y/N] ').lower()=='y'
 print('Issuance can take several minutes. Existing native certificate snapshots/rollback remain active.')
 if input('Request and activate this certificate now? [y/N] ').lower()=='y':tls_call(data)
def network():
 s=json.loads(tls_call({'operation':'status'},capture=True).stdout);host=s.get('host','').strip('[]')
 print('\nCONNECTIVITY / TLS CHECK\nHost: '+host+'\nNative TLS state: '+str(s.get('tls'))+'\nCertificate: '+json.dumps(s.get('cert',{})))
 if not host:print('No host configured.');return
 try:
  addresses=sorted({v[4][0] for v in socket.getaddrinfo(host,None,type=socket.SOCK_STREAM)});print('System DNS A/AAAA: '+', '.join(addresses))
 except OSError as e:print('DNS FAILED: '+str(e))
 front=443
 try:
  for line in pathlib.Path('/etc/nova/agent.env').read_text().splitlines():
   if line.startswith('NOVA_FRONT_PORT='):front=int(line.split('=',1)[1])
 except (OSError,ValueError):pass
 for address,port in [('127.0.0.1',front),(host,front)]:
  try:
   with socket.create_connection((address,port),timeout=7):print(f'TCP {address}:{port}: reachable')
  except OSError as e:print(f'TCP {address}:{port}: FAILED ({e})')
 h='['+host+']' if ':' in host else host
 try:
  request=urllib.request.Request('https://'+h+(':'+str(front) if front!=443 else '/') ,method='HEAD')
  with urllib.request.urlopen(request,timeout=10,context=ssl.create_default_context()) as response:print('Public HTTPS with CA verification: HTTP '+str(response.status))
 except Exception as e:print('Public HTTPS result: '+str(e))
 print('This checks from the VPS, not your ISP. IP blocking, routing, ISP DNS and Cloudflare WAF need a client-side comparison. No firewall/DNS settings were changed.')
def repair():
 run(['python3',APP/'xray-access.py'])
 if pathlib.Path('/opt/alirezabot/.alirezaserver-managed').exists():print(json.dumps(bot('repair-web')))
 run(['systemctl','reset-failed','xray.service']);run(['systemctl','restart','xray.service']);run(['bash',APP/'check.sh'])
def support():
 print('ALIREZASERVER READ-ONLY SUPPORT REPORT')
 try:network()
 except Exception as e:print('Network diagnostic unavailable: '+str(e))
 perform('status');perform('ports')
 failure=pathlib.Path('/var/lib/alirezaserver/tls-last-failure.json')
 if failure.exists():
  data=json.loads(failure.read_text());print('Last TLS failure: '+json.dumps(data))
 # Validate as the service identity, not root: root can hide permission bugs.
 result=subprocess.run(['systemctl','show','xray.service','-p','User','--value'],capture_output=True,text=True)
 user=result.stdout.strip() or 'root'
 command=['/usr/local/bin/xray','run','-test','-config','/usr/local/etc/xray/config.json']
 if user!='root':command=['runuser','-u',user,'--',*command]
 try:
  checked=subprocess.run(command,capture_output=True,text=True,timeout=20)
  print('Xray config / certificates / runtime identity: '+('PASS' if checked.returncode==0 else 'FAIL'))
  if checked.returncode:print('Inspect locally with: sudo journalctl -u xray.service -n 30 --no-pager')
 except (OSError,subprocess.SubprocessError) as e:print('Xray check unavailable: '+str(e))
 print('No UUIDs, API tokens or certificate keys included. This is not an external client handshake test.')
def perform(command,target=None):
 if command in ['panel','panels']:panels()
 elif command=='openvpn':openvpn()
 elif command=='ports':run(['ss','-lntup'])
 elif command=='status':run(['systemctl','show',*UNITS.values(),'-p','Id,ActiveState,SubState,Result','--no-pager'])
 elif command=='password':password(target)
 elif command=='tls':tls_setup()
 elif command=='tls-status':print(tls_call({'operation':'status'},capture=True).stdout)
 elif command=='network':network()
 elif command=='support':support()
 elif command in ['start','stop','restart']:
  if target not in UNITS:raise RuntimeError('Allowed services: '+', '.join(UNITS))
  if target=='bot':print(json.dumps(bot(command)))
  else:run(['systemctl',command,UNITS[target]])
 elif command=='doctor':run(['bash',APP/'install-diagnostics.sh']);run(['bash',APP/'check.sh'])
 elif command=='repair':repair()
 elif command=='backup':run(['python3',APP/'backup.py'])
 elif command=='update':run(['python3',APP/'update.py','--retry'])
 elif command=='logs':
  if target not in [None,*UNITS]:raise RuntimeError('Unknown service.')
  run(['journalctl','-u',UNITS.get(target,'nova-agent.service'),'-n','60','--no-pager'])
 else:raise RuntimeError('Unknown command.')
def service_summary():
 values={k:'unknown' for k in UNITS}
 try:
  result=subprocess.run(['systemctl','show',*UNITS.values(),'-p','Id,ActiveState,LoadState','--no-pager'],capture_output=True,text=True,timeout=5)
  reverse={v:k for k,v in UNITS.items()}
  for block in result.stdout.split('\n\n'):
   row=dict(line.split('=',1) for line in block.splitlines() if '=' in line)
   if row.get('Id') in reverse:values[reverse[row['Id']]]='not installed' if row.get('LoadState')=='not-found' else row.get('ActiveState','unknown')
 except (OSError,subprocess.SubprocessError):pass
 return values
def menu():
 groups=[('ACCESS & SECURITY',[('Panel addresses','panels',None),('Reset main panel password','password','panel'),('Reset bot password','password','bot'),('Selected OpenVPN credentials','openvpn',None),('TLS certificate setup','tls',None),('TLS certificate status','tls-status',None)]),('HEALTH & RECOVERY',[('Service status','status',None),('Connection / DNS / TLS doctor','network',None),('Read-only support report','support',None),('Verify installed integration','doctor',None),('Repair Xray / bot web runtime','repair',None),('Create add-on backup','backup',None),('Guarded Nova update','update',None)]),('SERVICES & LOGS',[('Restart panel','restart','panel'),('Restart Xray','restart','xray'),('Restart bot','restart','bot'),('Listening TCP / UDP ports','ports',None),('Xray journal','logs','xray'),('Bot web journal','logs','bot'),('Telegram journal','logs','telegram')])]
 color=sys.stdout.isatty() and 'NO_COLOR' not in os.environ
 def c(value,code):return '\033['+code+'m'+value+'\033[0m' if color else value
 while True:
  width=max(44,min(76,shutil.get_terminal_size((76,24)).columns-2));line='='*width
  print('\n'+c(line,'36'));print(c('  ALIREZA  /  SERVER CONTROL','1;36'));print('  rc.7  |  '+datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'));print(c(line,'36'))
  states=service_summary()
  for names in [('panel','xray','dns'),('bot','telegram')]:
   print('  '+'  |  '.join(name.upper()+': '+c(states[name],'32' if states[name]=='active' else '31' if states[name]=='failed' else '2') for name in names))
  options=[]
  for title,items in groups:
   print('\n  '+c(title,'1;34'))
   for item in items:
    options.append(item);print(f'  {len(options):02}. {item[0]}')
  print('\n  00. Exit\n'+c('-'*width,'36'))
  choice=input('  Select an option: ').strip()
  if choice in ['0','00']:return
  if not choice.isdigit() or not 1<=int(choice)<=len(options):print('Invalid selection.');continue
  label,cmd,target=options[int(choice)-1]
  if cmd in ['repair','update','restart'] and input(label+' now? Connections may be interrupted. [y/N] ').lower()!='y':continue
  try:perform(cmd,target)
  except (RuntimeError,subprocess.SubprocessError,OSError) as e:print(c('Operation failed: '+str(e),'31'))
  input('\nPress Enter to return...')
def main():
 parser=argparse.ArgumentParser(description='alireza - English server control; passwords are reset, never recovered')
 parser.add_argument('command',nargs='?',choices=['openvpn','ports','status','panel','panels','password','tls','tls-status','network','support','start','stop','restart','doctor','repair','backup','update','logs']);parser.add_argument('target',nargs='?');a=parser.parse_args()
 if os.geteuid()!=0:raise RuntimeError('Run with sudo alireza.')
 if a.command:perform(a.command,a.target)
 elif sys.stdin.isatty():menu()
 else:parser.print_help()
if __name__=='__main__':
 try:main()
 except (RuntimeError,OSError,subprocess.SubprocessError) as e:print('alireza: '+str(e),file=sys.stderr);sys.exit(1)
 except (KeyboardInterrupt,EOFError):print();sys.exit(130)
