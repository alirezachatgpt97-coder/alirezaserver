#!/bin/sh
exec /usr/bin/python3 /opt/alirezaserver/alireza.py "$@"
