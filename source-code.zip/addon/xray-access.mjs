// SPDX-License-Identifier: GPL-3.0-or-later
// Keep the native transaction intact; replace only the configured Xray JSON writer.
import{readFileSync,openSync,writeFileSync,fchownSync,fchmodSync,closeSync,renameSync,rmSync,lstatSync}from'node:fs';import{dirname,resolve,join}from'node:path';import{randomBytes}from'node:crypto';
export function writeRuntimeJSON(original,file,value,options){
 let policy;try{policy=JSON.parse(readFileSync(join(process.env.ALIREZA_ROOT||'/var/lib/alirezaserver','xray-access.json'),'utf8'));}catch(e){if(e.code==='ENOENT')return original(file,value,options);throw e;}
 if(resolve(file)!==policy.config)return original(file,value,options);
 if(!Number.isSafeInteger(policy.gid)||policy.gid<0||policy.uid!==0)throw Error('XRAY_ACCESS_POLICY_INVALID');
 for(const p of[dirname(file),file]){try{const st=lstatSync(p);if(st.isSymbolicLink())throw Error('XRAY_ACCESS_SYMLINK_REFUSED');if(st.uid!==0||(st.isDirectory()&&(st.mode&0o022)))throw Error('XRAY_ACCESS_UNSAFE_OWNER_OR_DIRECTORY');}catch(e){if(e.code!=='ENOENT')throw e;}}
 const temp=file+'.tmp-alireza-'+randomBytes(12).toString('hex');let fd;
 try{fd=openSync(temp,'wx',0o600);writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fchownSync(fd,0,policy.gid);fchmodSync(fd,policy.serviceUid===0?0o600:0o640);closeSync(fd);fd=undefined;renameSync(temp,file);}catch(e){if(fd!==undefined)closeSync(fd);rmSync(temp,{force:true});throw e;}
}
