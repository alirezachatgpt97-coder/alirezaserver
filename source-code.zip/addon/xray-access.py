#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Repair only fixed Xray runtime permissions; never use root for the daemon."""
import os,pathlib,pwd,grp,subprocess,json,stat,sys,shlex
ROOT=pathlib.Path('/var/lib/alirezaserver')
def identity():
 out=subprocess.check_output(['systemctl','show','xray.service','-p','User','-p','Group'],text=True)
 values=dict(line.split('=',1) for line in out.splitlines() if '=' in line)
 user=values.get('User') or 'root';account=pwd.getpwuid(int(user)) if user.isdigit() else pwd.getpwnam(user)
 group=values.get('Group');gid=(int(group) if group.isdigit() else grp.getgrnam(group).gr_gid) if group else account.pw_gid
 return account.pw_uid,gid

def repair(root=ROOT,config=pathlib.Path('/usr/local/etc/xray/config.json'),certdir=pathlib.Path('/etc/nova'),logdir=None):
 uid,gid=identity();config=pathlib.Path(config);root=pathlib.Path(root)
 # Refuse unsupported custom service config paths instead of changing unrelated files.
 start=subprocess.check_output(['systemctl','show','xray.service','-p','ExecStart','--value'],text=True)
 if str(config) not in start:raise RuntimeError('XRAY_CUSTOM_CONFIG_REQUIRES_REVIEW')
 paths=[config.parent,config,certdir,certdir/'origin.pem',certdir/'origin.key']
 before=[]
 for p in paths:
  if not p.exists():
   if p==config or p==config.parent:raise RuntimeError('XRAY_CONFIG_MISSING')
   continue
  if p.is_symlink():raise RuntimeError('XRAY_ACCESS_SYMLINK_REFUSED')
  s=p.stat()
  if s.st_uid!=0:raise RuntimeError('XRAY_UNOWNED_RUNTIME_PATH')
  if p.is_dir() and stat.S_IMODE(s.st_mode)&0o022:raise RuntimeError('XRAY_RUNTIME_DIRECTORY_WRITABLE')
  before.append({'path':str(p),'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode)})
 root.mkdir(parents=True,exist_ok=True,mode=0o700)
 backup=root/'xray-access-before.json'
 if not backup.exists():backup.write_text(json.dumps(before,indent=2)+'\n');backup.chmod(0o600)
 # Group readability is limited to the runtime identity already selected by systemd.
 for p in paths:
  if not p.exists():continue
  if uid==0:continue
  s=p.stat();os.chown(p,0,gid)
  if p.is_dir():os.chmod(p,stat.S_IMODE(s.st_mode)|0o050)
  else:os.chmod(p,0o640)
 # Only the fixed Nova log files are repaired. Never recurse into unrelated logs.
 if logdir is not None:
  logdir=pathlib.Path(logdir)
  allowed={0,uid}
  try:allowed.add(pwd.getpwnam('nobody').pw_uid)
  except KeyError:pass
  for p in [logdir,logdir/'access.log',logdir/'error.log']:
   if p.is_symlink():raise RuntimeError('XRAY_LOG_SYMLINK_REFUSED')
   if p.exists() and p.stat().st_uid not in allowed:raise RuntimeError('XRAY_LOG_OWNER_REQUIRES_REVIEW')
  logdir.mkdir(parents=True,exist_ok=True,mode=0o750)
  os.chown(logdir,uid,gid);os.chmod(logdir,0o750)
  for name in ['access.log','error.log']:
   p=logdir/name
   fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW,0o640)
   try:os.fchown(fd,uid,gid);os.fchmod(fd,0o640)
   finally:os.close(fd)
 policy={'uid':0,'gid':gid if uid!=0 else 0,'config':str(config.resolve()),'serviceUid':uid}
 tmp=root/'xray-access.json.tmp';tmp.write_text(json.dumps(policy)+'\n');tmp.chmod(0o600);os.replace(tmp,root/'xray-access.json')
 print('Xray runtime access configured for its existing service identity; config contents unchanged.')
def configure_startup(systemroot=pathlib.Path('/'),root=ROOT):
 drop=pathlib.Path(systemroot)/'etc/systemd/system/xray.service.d/90-alirezaserver-access.conf'
 if drop.is_symlink():raise RuntimeError('XRAY_DROPIN_SYMLINK_REFUSED')
 drop.parent.mkdir(parents=True,exist_ok=True)
 content='[Service]\nExecStartPre=+/usr/bin/python3 /opt/alirezaserver/xray-access.py --before-start\n'
 if drop.exists() and drop.read_text()!=content:
  old=drop.read_text();allowed={'/usr/local/etc/xray/config.json','/etc/nova','/etc/nova/origin.pem','/etc/nova/origin.key','/var/log/nova','/var/log/nova/access.log','/var/log/nova/error.log'}
  # Accept only the narrow console hotfix previously supplied for these paths.
  for line in old.splitlines():
   if not line.strip() or line.strip()=='[Service]' or line.lstrip().startswith('#'):continue
   if not line.startswith('ExecStartPre=+'):raise RuntimeError('XRAY_DROPIN_CONFLICT')
   args=shlex.split(line[len('ExecStartPre=+'):])
   if len(args)<3 or args[0] not in ['/usr/bin/chown','/usr/bin/chmod'] or not set(args[2:])<=allowed:raise RuntimeError('XRAY_DROPIN_CONFLICT')
   values=['0640','0750'] if args[0].endswith('chmod') else ['root:xray','xray:xray','root:nogroup','nobody:nogroup']
   if args[1] not in values:raise RuntimeError('XRAY_DROPIN_CONFLICT')
  backup=pathlib.Path(root)/'xray-dropin-before-rc6.conf'
  if not backup.exists():backup.write_text(old);backup.chmod(0o600)
 changed=not drop.exists() or drop.read_text()!=content
 if changed:
  drop.write_text(content);drop.chmod(0o644)
  subprocess.run(['systemctl','daemon-reload'],check=True)
 rotation=pathlib.Path(systemroot)/'etc/logrotate.d/alirezaserver-xray'
 rotation.parent.mkdir(parents=True,exist_ok=True)
 rotation.write_text('/var/log/nova/access.log /var/log/nova/error.log {\n daily\n maxsize 5M\n rotate 4\n missingok\n notifempty\n compress\n delaycompress\n copytruncate\n}\n')
if __name__=='__main__':
 repair(logdir=pathlib.Path('/var/log/nova'))
 if '--before-start' not in sys.argv:configure_startup()
