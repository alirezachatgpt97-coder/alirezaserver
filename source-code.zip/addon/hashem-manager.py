#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Hashem adapter: private paths, fixed downloads, argument arrays, owned-service guard."""
import shlex,fcntl,gzip,io,base64,hashlib,ipaddress,json,os,pathlib,re,shutil,signal,subprocess,sys,tarfile,tempfile,time,urllib.request
HERE=pathlib.Path(__file__).resolve().parent; ROOT=pathlib.Path('/var/lib/alirezaserver/hashem'); APP=pathlib.Path('/opt/alirezaserver-hashem'); CFG=pathlib.Path('/etc/alirezaserver-hashem')
UNITS=['alireza-hashem-'+n for n in ['frps','frpc','frps-wss','backhaul-server','backhaul-client','az-hashem-gre','hashem-watchdog','carrier']]
SYSTEMD=pathlib.Path('/etc/systemd/system')
MARKER='# alirezaserver-hashem-managed\n'
UNIT_FILES=[n+'.service' for n in UNITS]+['alireza-hashem-hashem-watchdog.timer']
def run(args,timeout=60):
 r=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
 if r.returncode:raise RuntimeError('HASHEM_COMMAND_FAILED:'+pathlib.Path(args[0]).name)
 return r.stdout

def config(v):
 role=v.get('role');engine=v.get('engine','gre');transport=v.get('transport','tcp');carrier=v.get('carrier','direct')
 if role not in ['iran','foreign'] or engine not in ['gre','backhaul','gre-backhaul']:raise RuntimeError('INVALID_TUNNEL_ROLE_OR_ENGINE')
 for k in ['localPub','remotePub']:
  try:ip=ipaddress.ip_address(v.get(k,''))
  except ValueError:raise RuntimeError('INVALID_'+k)
  if ip.version!=4 or ip.is_loopback or ip.is_multicast or ip.is_unspecified:raise RuntimeError('IPV4_REQUIRED_'+k)
 if v['localPub']==v['remotePub']:raise RuntimeError('TUNNEL_ENDPOINTS_MUST_DIFFER')
 allowed=['tcp','kcp','quic','websocket','wss'] if engine=='gre' else ['tcp','tcpmux','ws','wss','wsmux','wssmux']
 if transport not in allowed or not (carrier in ['direct','auto'] or re.fullmatch(r'(fou|wss):([1-9][0-9]{0,4})',carrier)):raise RuntimeError('INVALID_TRANSPORT_OR_CARRIER')
 port=int(v.get('port',3080));ports=sorted(set(int(str(p).strip()) for p in (v.get('ports',[]) if isinstance(v.get('ports'),list) else str(v.get('ports','')).split(',')) if str(p).strip()))
 if not 1<=port<65535 or not ports or any(p<1 or p>65535 for p in ports):raise RuntimeError('INVALID_PORTS')
 token=str(v.get('token',''))
 if not re.fullmatch(r'[A-Za-z0-9_-]{24,128}',token):raise RuntimeError('INVALID_TUNNEL_TOKEN')
 if engine=='backhaul' and carrier!='direct':raise RuntimeError('CARRIER_REQUIRES_GRE_ENGINE')
 if ':' in carrier and int(carrier.split(':')[1])>65535:raise RuntimeError('INVALID_CARRIER_PORT')
 return dict(wssInsecure=v.get('wssInsecure') is True,role=role,engine=engine,transport=transport,carrier=carrier,localPub=str(v['localPub']),remotePub=str(v['remotePub']),port=port,ports=ports,token=token,replace=v.get('replace') is True)
def args_for(v):
 c=config(v);name='setup-'+('' if c['engine']=='gre' else c['engine']+'-')+c['role'];args=[name,'--local-pub',c['localPub'],'--remote-pub',c['remotePub'],'--frp-port' if c['engine']=='gre' else '--port',str(c['port']),'--token',c['token']]
 if c['engine']=='gre' or c['role']=='iran':args+=['--ports',','.join(map(str,c['ports']))]
 if c['engine']=='gre':args+=['--frp-transport',c['transport']]
 elif c['engine']!='gre':args+=['--transport',c['transport']]
 if c['replace']:args+=['--force']
 return args

def managed_script():
 src=(HERE/'hashem-source.sh').read_text();manifest=json.loads((HERE/'reference-versions.json').read_text())
 if hashlib.sha256(src.encode()).hexdigest()!=manifest['hashem']['sha256']:raise RuntimeError('HASHEM_SOURCE_CHECKSUM')
 replacements={'/usr/local/bin':str(APP/'bin'),'/etc/frp':str(CFG/'frp'),'/etc/backhaul':str(CFG/'backhaul'),'/etc/gre-panel':str(CFG/'state'),'/var/lib/gre-panel':str(ROOT/'state'),'/var/backups/hashem':str(ROOT/'backups'),'/var/log/hashem':str(ROOT/'logs'),'19998':'29998','19999':'29999','${HASHEM_SYSTEMD_DIR:-/etc/systemd/system}/':'${HASHEM_SYSTEMD_DIR:-/etc/systemd/system}/alireza-hashem-','/etc/systemd/system/':'/etc/systemd/system/alireza-hashem-','gre-tunnel':'az-hashem-gre','10.10.10.1':'10.251.251.1','10.10.10.2':'10.251.251.2'}
 for a,b in replacements.items():src=src.replace(a,b)
 src=re.sub(r'(?m)^ExecStart=', 'LogRateLimitIntervalSec=30s\nLogRateLimitBurst=200\nExecStart=',src)
 src=src.replace('/alireza-hashem-alireza-hashem-','/alireza-hashem-')
 # Existing Nova supplies the complete web surface; never install a second web listener.
 overrides='''\n# alirezaserver managed embedding: core downloads are verified by the Python adapter.
systemctl(){
 local a out=()
 for a in "$@"; do
 case "$a" in frps*|frpc*|backhaul-server*|backhaul-client*|az-hashem-gre*|hashem-watchdog*|gre-panel*) out+=("alireza-hashem-$a");; *) out+=("$a");; esac
 done
 command systemctl "${out[@]}"
}
# Never rewrite UFW policy or retire a separate Hashem installation.
ufw(){ return 0; }
carrier_init_kernel(){
 modprobe ip_gre >/dev/null 2>&1 || true
 local mode="${TARGET:-$(carrier_get_active)}" p ports=()
 [[ "$(carrier_get_mode)" != auto ]] || mode=auto
 case "$mode" in direct) return 0;; fou:*) ports=("${mode#fou:}");; wss:*) ports=(29998);; auto) ports=(443 55555 29998);; *) return 1;; esac
 modprobe fou >/dev/null 2>&1 || return 1
 mkdir -p "$PANEL_CONFIG_DIR"
 for p in "${ports[@]}"; do
  if ! ip fou show 2>/dev/null | grep -Eq "^port $p([[:space:]]|$)"; then
   ip fou add port "$p" ipproto 47 || return 1
   : > "$PANEL_CONFIG_DIR/.owned-fou-$p"
  elif [[ ! -f "$PANEL_CONFIG_DIR/.owned-fou-$p" ]]; then
   echo 'Foreign FoU port conflict' >&2; return 1
  fi
  iptables -C INPUT -p udp --dport "$p" -j ACCEPT >/dev/null 2>&1 || iptables -I INPUT 1 -p udp --dport "$p" -j ACCEPT
 done
}
purge_legacy_obfuscation(){ return 0; }
iptables(){
 local a op="" chain="" args=("$@") scoped=()
 for a in "$@"; do case "$a" in -A|-I|-C|-D) op="$a";; INPUT|OUTPUT|POSTROUTING) chain="$a";; esac; done
 [[ -n "$op" && -n "$chain" ]] || return 0
 # Only our tagged rules can be queried/deleted. MSS never applies globally.
 scoped=("${args[@]}" -m comment --comment alirezaserver-hashem)
 [[ "$chain" != POSTROUTING ]] || scoped+=(-o "$TUNNEL_NAME")
 command iptables "${scoped[@]}"
}
install_panel(){ return 0; }
install_panel_smart(){ return 0; }
tune_apply(){ return 0; }

get_latest_frp_version(){ FRP_VERSION=0.71.0; }
install_frp_binaries(){ test -x "${INSTALL_DIR}/frps" && test -x "${INSTALL_DIR}/frpc"; }
install_backhaul_binaries(){ test -x "${INSTALL_DIR}/backhaul"; }
'''
 marker='if [[ $# -gt 0 ]]; then\n    case "$1" in'
 if src.count(marker)!=1:raise RuntimeError('HASHEM_CLI_CONTRACT_CHANGED')
 src=src.replace('sysctl -w net.ipv4.ip_forward=1 >/dev/null 2>&1','true # No global IP forwarding change; FRP/Backhaul use local sockets')
 src=src.replace('TOKEN="$2"; shift 2', 'TOKEN="${ALIREZA_HASHEM_TOKEN:-$2}"; shift 2')
 src=src.replace('local SPECIFIC_IF="${2:-}"','local SPECIFIC_IF="$TUNNEL_NAME"')
 return src.replace(marker,overrides+'\n'+marker)

def guard():
 for name in UNIT_FILES:
  p=SYSTEMD/name
  if p.exists() and not p.read_text().startswith(MARKER):raise RuntimeError('EXISTING_SERVICE_CONFLICT:'+name)

def install():
 guard();(APP/'bin').mkdir(parents=True,exist_ok=True);ROOT.mkdir(parents=True,exist_ok=True,mode=0o700);CFG.mkdir(parents=True,exist_ok=True,mode=0o700)
 script=APP/'bin/hashem.sh';script.write_text(managed_script());script.chmod(0o700)
 binary=APP/'bin/hashem'
 if not binary.exists():binary.symlink_to(script)
 run(['bash','-n',str(script)])
 lock=json.loads((HERE/'tunnel-downloads.json').read_text());arch=os.uname().machine;arch={'x86_64':'amd64','aarch64':'arm64'}.get(arch)
 if not arch:raise RuntimeError('UNSUPPORTED_ARCHITECTURE')
 for entry in lock[arch]:
  if all((APP/'bin'/b).exists() and hashlib.sha256((APP/'bin'/b).read_bytes()).hexdigest()==entry['binarySHA256'][b] for b in entry['binaries']):continue
  with tempfile.TemporaryDirectory() as t:
   archive=pathlib.Path(t)/'core.tgz';req=urllib.request.Request(entry['url'],headers={'User-Agent':'alirezaserver'})
   with urllib.request.urlopen(req,timeout=90) as response,archive.open('wb') as out:
    total=0
    while True:
     chunk=response.read(262144)
     if not chunk:break
     total+=len(chunk)
     if total>100*1024*1024:raise RuntimeError('CORE_ARCHIVE_TOO_LARGE')
     out.write(chunk)
   if hashlib.sha256(archive.read_bytes()).hexdigest()!=entry['sha256']:raise RuntimeError('CORE_CHECKSUM_MISMATCH')
   with tarfile.open(archive) as tar:
    for binary in entry['binaries']:
     matches=[m for m in tar.getmembers() if m.isfile() and pathlib.PurePosixPath(m.name).name==binary]
     if len(matches)!=1:raise RuntimeError('CORE_ARCHIVE_INVALID')
     dst=APP/'bin'/binary;temp=dst.with_suffix('.partial')
     with tar.extractfile(matches[0]) as a,temp.open('wb') as b:shutil.copyfileobj(a,b)
     if hashlib.sha256(temp.read_bytes()).hexdigest()!=entry['binarySHA256'][binary]:raise RuntimeError('CORE_BINARY_CHECKSUM')
     temp.chmod(0o700);temp.replace(dst)
 corelock=json.loads((HERE/'hashem-core-build.json').read_text())
 corepath=APP/'bin/gre-panel'
 if not corepath.exists() or hashlib.sha256(corepath.read_bytes()).hexdigest()!=corelock[arch]['sha256']:
  packed=base64.b64decode((HERE/('hashem-core-'+arch+'.b64')).read_bytes())
  if hashlib.sha256(packed).hexdigest()!=corelock[arch]['compressedSHA256']:raise RuntimeError('CARRIER_PAYLOAD_CHECKSUM')
  with gzip.GzipFile(fileobj=io.BytesIO(packed)) as stream:core=stream.read(corelock[arch]['bytes']+1)
  if len(core)!=corelock[arch]['bytes'] or hashlib.sha256(core).hexdigest()!=corelock[arch]['sha256']:raise RuntimeError('CARRIER_CORE_CHECKSUM')
  (APP/'bin/gre-panel').write_bytes(core);(APP/'bin/gre-panel').chmod(0o700)
 adapter=APP/'adapter';adapter.mkdir(parents=True,exist_ok=True,mode=0o700)
 for name in ['hashem-manager.py','hashem-source.sh','reference-versions.json','tunnel-downloads.json','hashem-core-build.json','COPYING.Hashem']:
  source=HERE/name;target=adapter/name
  if source.resolve()!=target.resolve():shutil.copyfile(source,target);target.chmod(0o600)
 return status()
def read_json(p):
 try:return json.loads(p.read_text())
 except FileNotFoundError:return {}
def interface_status():
 try:
  result=subprocess.run(['ip','-j','-s','link','show','dev','az-hashem-gre'],capture_output=True,text=True,timeout=5)
  data=json.loads(result.stdout or '[]')
  if not data:return None
  value=data[0];stats=value.get('stats64',value.get('stats',{}));return {'name':'az-hashem-gre','up':'UP' in value.get('flags',[]),'mtu':value.get('mtu'),'rx':stats.get('rx',{}),'tx':stats.get('tx',{})}
 except (OSError,ValueError,subprocess.TimeoutExpired):return None
def status():
 services={};pids={}
 owned=[name for name in UNITS if (SYSTEMD/(name+'.service')).exists() and (SYSTEMD/(name+'.service')).read_text().startswith(MARKER)]
 if owned:
  result=subprocess.run(['systemctl','show','--no-pager','--property=Id,ActiveState,MainPID',*owned],capture_output=True,text=True,timeout=10)
  for block in result.stdout.split('\n\n'):
   values=dict(line.split('=',1) for line in block.splitlines() if '=' in line);name=values.get('Id','').removesuffix('.service')
   if name in owned:services[name]=values.get('ActiveState','unknown');pids[name]=int(values.get('MainPID','0'))
  for name in owned:services.setdefault(name,'unknown')
 carrier=read_json(CFG/'state/carrier.json');watchdog=read_json(CFG/'state/watchdog.json');wssfile=CFG/'state/wss-status.json';wss=read_json(wssfile)
 if wss:
  wss['stale']=not wssfile.exists() or time.time()-wssfile.stat().st_mtime>10 or services.get('alireza-hashem-carrier')!='active'
  if wss['stale']:wss['running']=False;wss['connected']=False
 return {'installed':(APP/'bin/hashem.sh').exists(),'services':services,'servicePids':pids,'interface':interface_status() if any('gre' in name for name in owned) else {},'carrier':{k:carrier[k] for k in ['mode','active_carrier','switch_count','last_switch'] if k in carrier},'watchdog':{k:watchdog[k] for k in ['enabled','interval_sec','consec_fails','last_check'] if k in watchdog},'wss':wss,'performance':read_json(CFG/'state/perf.json'),'pool':read_json(CFG/'state/auto_pool.json'),'benchmark':read_json(ROOT/'benchmark.json'),'configuration':{k:v for k,v in read_json(ROOT/'last-config.json').items() if k!='token'},'snapshots':sorted(p.name for p in (ROOT/'snapshots').glob('*') if p.is_dir())[-10:]}
def firewall_rules():
 rules={}
 for table in ['filter','nat','mangle']:
  try:text=run(['iptables-save','-t',table],10)
  except (RuntimeError,FileNotFoundError):continue
  entries=[];positions={}
  for line in text.splitlines():
   if not line.startswith('-A '):continue
   chain=shlex.split(line)[1];positions[chain]=positions.get(chain,0)+1
   if '--comment alirezaserver-hashem' in line.replace('"',''):entries.append({'rule':line,'position':positions[chain]})
  rules[table]=entries
 return rules
def restore_firewall(saved):
 current=firewall_rules()
 for table in sorted(set(current)|set(saved)):
  for line in current.get(table,[]):
   args=shlex.split(line['rule'] if isinstance(line,dict) else line);args[0]='-D';subprocess.run(['iptables','-t',table,*args],capture_output=True,timeout=10)
  for line in saved.get(table,[]):
   args=shlex.split(line['rule'] if isinstance(line,dict) else line)
   if isinstance(line,dict):args[0]='-I';args.insert(2,str(line['position']))
   run(['iptables','-t',table,*args],10)
def snapshot():
 dest=ROOT/'snapshots'/str(time.time_ns());dest.mkdir(parents=True,mode=0o700)
 if CFG.exists():shutil.copytree(CFG,dest/'config')
 for name in UNIT_FILES:
  p=SYSTEMD/name
  if p.exists() and p.read_text().startswith(MARKER):shutil.copy2(p,dest/p.name)
 (dest/'timer-active.json').write_text(json.dumps({n:subprocess.run(['systemctl','is-active',n],capture_output=True,text=True,timeout=5).stdout.strip() for n in UNIT_FILES if n.endswith('.timer') and (SYSTEMD/n).exists()}))
 if (ROOT/'last-config.json').exists():shutil.copy2(ROOT/'last-config.json',dest/'last-config.json')
 (dest/'enabled.json').write_text(json.dumps({n:subprocess.run(['systemctl','is-enabled',n],capture_output=True,text=True,timeout=5).stdout.strip() for n in UNIT_FILES if (SYSTEMD/n).exists()}))
 (dest/'firewall.json').write_text(json.dumps(firewall_rules()))
 (dest/'active.json').write_text(json.dumps(status()['services']))
 for old in sorted(p for p in (ROOT/'snapshots').iterdir() if p.is_dir() and not p.is_symlink() and re.fullmatch(r'\d{10,30}',p.name))[:-10]:shutil.rmtree(old)
 return dest
def cleanup_fou(keep=None):
 keep=keep or set()
 for p in (CFG/'state').glob('.owned-fou-*'):
  number=p.name.removeprefix('.owned-fou-')
  if number.isdigit() and p.name not in keep:
   subprocess.run(['ip','fou','del','port',number],capture_output=True,timeout=10);p.unlink()
def restore(dest):
 cleanup_fou({p.name for p in (dest/'config/state').glob('.owned-fou-*')})
 newgre=(SYSTEMD/'alireza-hashem-az-hashem-gre.service').exists() and not(dest/'alireza-hashem-az-hashem-gre.service').exists()
 for name in UNIT_FILES:
  p=SYSTEMD/name;backup=dest/p.name
  if p.exists() and p.read_text().startswith(MARKER):subprocess.run(['systemctl','disable','--now',name],capture_output=True,timeout=30);p.unlink()
  if backup.exists():shutil.copy2(backup,p)
 if newgre:subprocess.run(['ip','link','delete','az-hashem-gre'],capture_output=True,timeout=10)
 restore_firewall(read_json(dest/'firewall.json'))
 if (dest/'config').exists():
  if CFG.exists():shutil.rmtree(CFG)
  shutil.copytree(dest/'config',CFG)
 if (dest/'last-config.json').exists():shutil.copy2(dest/'last-config.json',ROOT/'last-config.json')
 else:(ROOT/'last-config.json').unlink(missing_ok=True)
 run(['systemctl','daemon-reload'])
 for name,state in read_json(dest/'enabled.json').items():
  if state=='enabled':run(['systemctl','enable',name],15)
 for name,state in {**read_json(dest/'active.json'),**read_json(dest/'timer-active.json')}.items():
  if state=='active':run(['systemctl','start',name],30)
def apply_carrier(c):
 if c['engine']=='backhaul':return
 state=CFG/'state';state.mkdir(parents=True,exist_ok=True,mode=0o700)
 (state/'setup.json').write_text(json.dumps(c));(state/'setup.json').chmod(0o600)
 mode=c['carrier'];carrier=read_json(state/'carrier.json');carrier.update(mode=mode,candidates=['direct','fou:443','fou:55555','wss:8443'])
 (state/'carrier.json').write_text(json.dumps(carrier));(state/'carrier.json').chmod(0o600)
 if mode.startswith('wss:') or mode=='auto':
  port=int(mode.split(':')[1]) if ':' in mode else 8443
  wss={'enabled':True,'role':'server' if c['role']=='iran' else 'client','listen_port':port,'remote_addr':c['remotePub']+':'+str(port),'local_bridge_udp':29998,'auth_token':c['token'],'use_tls':True,'sni':c['remotePub'],'insecure_tls':c['wssInsecure']}
  (state/'wss_carrier.json').write_text(json.dumps(wss));(state/'wss_carrier.json').chmod(0o600)
  unit=MARKER+'[Unit]\nDescription=alirezaserver Hashem WSS carrier\nAfter=network-online.target\n[Service]\nExecStart='+str(APP/'bin/gre-panel')+' carrier\nEnvironment=GRE_PANEL_DIR='+str(state)+'\nRestart=on-failure\nRestartSec=3\nLogRateLimitIntervalSec=30s\nLogRateLimitBurst=200\nNoNewPrivileges=true\nPrivateTmp=true\nProtectSystem=strict\nReadWritePaths='+str(state)+'\n[Install]\nWantedBy=multi-user.target\n'
  (SYSTEMD/'alireza-hashem-carrier.service').write_text(unit);run(['systemctl','daemon-reload']);run(['systemctl','enable','--now','alireza-hashem-carrier'],20)
  run(['systemctl','restart','alireza-hashem-carrier'],20)
 else:
  unit=(SYSTEMD/'alireza-hashem-carrier.service')
  if unit.exists() and unit.read_text().startswith(MARKER):run(['systemctl','stop','alireza-hashem-carrier'],20)
 if mode!='auto':run(['bash',str(APP/'bin/hashem.sh'),'carrier','set',mode],30)
 else:run(['bash',str(APP/'bin/hashem.sh'),'watchdog','on'],30)
def check_ports(c,carrier_only=False):
 # Never reuse a port held by Nova, DNS, SSH or another service.
 ports=run(['ss','-H','-lntup'])
 owned=['pid='+str(pid)+',' for pid in status().get('servicePids',{}).values() if pid>0]
 check=[] if carrier_only or c['role']=='foreign' else [c['port'],c['port']+1]+c['ports']
 if not carrier_only and c['role']=='iran' and c['transport']=='wss':check.append(c['port']+2 if c['port']+2<=65535 else c['port']-2)
 if c['carrier']=='auto':check += [443,55555,29998,29999]+([8443] if c['role']=='iran' else [])
 elif c['carrier'].startswith('fou:'):check += [int(c['carrier'].split(':')[1])]
 elif c['carrier'].startswith('wss:'):check += [29998,29999]+([int(c['carrier'].split(':')[1])] if c['role']=='iran' else [])
 for port in check:
  for line in ports.splitlines():
   if re.search(r':'+str(port)+r'\s',line) and not any(pid in line for pid in owned):raise RuntimeError('PORT_IN_USE:'+str(port))

def network_guard(c):
 if c['engine']=='backhaul':return
 fou=run(['ip','fou','show'])
 numbers=[443,55555,29998] if c['carrier']=='auto' else [int(c['carrier'].split(':')[1])] if c['carrier'].startswith('fou:') else [29998] if c['carrier'].startswith('wss:') else []
 for number in numbers:
  if re.search(r'(?m)^port '+str(number)+r'\s',fou) and not(CFG/'state'/('.owned-fou-'+str(number))).exists():raise RuntimeError('FOU_PORT_CONFLICT:'+str(number))
 links=json.loads(run(['ip','-j','link','show']) or '[]')
 owned=(SYSTEMD/'alireza-hashem-az-hashem-gre.service').exists()
 if any(x.get('ifname')=='az-hashem-gre' for x in links) and not owned:raise RuntimeError('EXISTING_GRE_INTERFACE_CONFLICT')
 for route in json.loads(run(['ip','-j','route','show','table','all']) or '[]'):
  dst=route.get('dst','default')
  if dst=='default' or route.get('dev')=='az-hashem-gre':continue
  try:net=ipaddress.ip_network(dst,strict=False)
  except ValueError:continue
  if net.version==4 and net.overlaps(ipaddress.ip_network('10.251.251.0/30')):raise RuntimeError('GRE_SUBNET_ROUTE_CONFLICT')
def setup(v):
 c=config(v);guard();network_guard(c)
 if not(APP/'bin/hashem.sh').exists():raise RuntimeError('INSTALL_HASHEM_FIRST')
 check_ports(c)
 snap=snapshot();before={name:(SYSTEMD/(name+'.service')).exists() for name in UNITS}
 try:
  args=args_for(c);args[args.index('--token')+1]='__ALIREZA_ENV_TOKEN__'
  proc=subprocess.Popen(['bash',str(APP/'bin/hashem.sh'),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,env={**os.environ,'ALIREZA_HASHEM_TOKEN':c['token'],'GRE_SKIP_PANEL':'1','GRE_PANEL_DIR':str(CFG/'state'),'PATH':str(APP/'bin')+':'+os.environ.get('PATH','')})
  try:proc.communicate(timeout=240)
  except BaseException:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.communicate(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.communicate()
   raise
  finally:
   for name in UNITS:
    p=(SYSTEMD/(name+'.service'))
    if p.exists() and (not before[name] or p.read_text().startswith(MARKER)):
     text=p.read_text()
     if not text.startswith(MARKER):p.write_text(MARKER+text)
   timer=(SYSTEMD/'alireza-hashem-hashem-watchdog.timer')
   if timer.exists() and not timer.read_text().startswith(MARKER):timer.write_text(MARKER+timer.read_text())
  for name in UNITS:
   p=(SYSTEMD/(name+'.service'))
   if p.exists() and (not before[name] or p.read_text().startswith(MARKER)):
    text=p.read_text()
    if not text.startswith(MARKER):p.write_text(MARKER+text)
  if proc.returncode:raise RuntimeError('HASHEM_SETUP_FAILED')
  expected='frps' if c['role']=='iran' else 'frpc'
  if c['engine']!='gre':expected='backhaul-server' if c['role']=='iran' else 'backhaul-client'
  run(['systemctl','is-active','--quiet','alireza-hashem-'+expected],10)
  apply_carrier(c)
  (ROOT/'last-config.json').write_text(json.dumps(c));os.chmod(ROOT/'last-config.json',0o600)
  return {'ok':True,'snapshot':snap.name,**status()}
 except Exception:
  restore(snap);raise RuntimeError('HASHEM_SETUP_FAILED_ROLLED_BACK')
def replace_frp_proxies(text,ports,old_ports):
 parts=re.split(r'(?m)^\[\[proxies\]\]\s*$',text);prefix=parts[0];templates={};kept=[]
 for block in parts[1:]:
  kind=re.search(r'(?m)^type\s*=\s*"(tcp|udp)"',block);number=re.search(r'(?m)^localPort\s*=\s*(\d+)',block);name=re.search(r'(?m)^name\s*=\s*"([^"]+)"',block)
  if kind and number and name and int(number[1]) in old_ports and name[1]==kind[1]+'_'+number[1]:templates.setdefault(kind[1],block)
  else:kept.append(block)
 if set(templates)!=set(['tcp','udp']):raise RuntimeError('FRP_PROXY_SCHEMA_CHANGED')
 generated=[]
 for port in ports:
  for kind in ['tcp','udp']:
   b=templates[kind];b=re.sub(r'(?m)^name\s*=.*$', 'name = "'+kind+'_'+str(port)+'"',b);b=re.sub(r'(?m)^(localPort|remotePort)\s*=.*$',lambda m:m[1]+' = '+str(port),b);generated.append(b)
 return prefix+''.join('[[proxies]]\n'+b for b in kept+generated)
def edit_ports(v):
 old=read_json(ROOT/'last-config.json')
 if not old:raise RuntimeError('NO_MANAGED_CONFIGURATION')
 c=config({**old,'ports':v['ports']});check_ports(c);snap=snapshot()
 if c['engine']!='gre' and c['role']=='foreign':
  (ROOT/'last-config.json').write_text(json.dumps(c));os.chmod(ROOT/'last-config.json',0o600);return {'ok':True,'snapshot':snap.name,'requiresPeerApply':True,**status()}
 try:
  if c['engine']=='gre' and c['role']=='foreign':
   p=CFG/'frp/frpc.toml';text=replace_frp_proxies(p.read_text(),c['ports'],old['ports']);temp=p.with_suffix('.new.toml');temp.write_text(text);os.chmod(temp,0o600);run([str(APP/'bin/frpc'),'verify','-c',str(temp)],15);temp.replace(p);unit='alireza-hashem-frpc'
  elif c['engine']=='gre':
   p=CFG/'frp/frps.toml';text=p.read_text();line='allowPorts = ['+', '.join('{start = '+str(n)+', end = '+str(n)+'}' for n in c['ports'])+']'
   text=re.sub(r'(?m)^allowPorts\s*=.*$',line,text) if re.search(r'(?m)^allowPorts\s*=',text) else line+'\n'+text
   temp=p.with_suffix('.new.toml');temp.write_text(text);os.chmod(temp,0o600);run([str(APP/'bin/frps'),'verify','-c',str(temp)],15);temp.replace(p);unit='alireza-hashem-frps'
  else:
   p=CFG/'backhaul/config.toml';text=p.read_text();pattern=r'(?ms)^(mapping|ports)\s*=\s*\[.*?\]';matches=list(re.finditer(pattern,text))
   if len(matches)!=1:raise RuntimeError('BACKHAUL_PORT_SCHEMA_CHANGED')
   text=re.sub(pattern,lambda m:m[1]+' = '+json.dumps([str(x) for x in c['ports']]),text,count=1);p.write_text(text);unit='alireza-hashem-backhaul-server'
  import tomllib
  tomllib.loads(p.read_text());run(['systemctl','restart',unit],30);run(['systemctl','is-active','--quiet',unit],15)
  (ROOT/'last-config.json').write_text(json.dumps(c));os.chmod(ROOT/'last-config.json',0o600);return {'ok':True,'snapshot':snap.name,'forwarderRestarted':True,**status()}
 except Exception:
  restore(snap);raise RuntimeError('PORT_UPDATE_FAILED_ROLLED_BACK')
def set_toml_key(text,key,value):
 pattern=r'(?m)^'+re.escape(key)+r'\s*=.*$'
 encoded=json.dumps(value)
 return re.sub(pattern,lambda m:key+' = '+encoded,text) if re.search(pattern,text) else text.rstrip()+'\n'+key+' = '+encoded+'\n'
def performance(v):
 c=read_json(ROOT/'last-config.json')
 if not c or c['engine']!='gre':raise RuntimeError('PERFORMANCE_REQUIRES_MANAGED_FRP')
 value=v.get('settings',{});keys=['proxy_encryption','proxy_compression','tcp_mux','auto_pool']
 if any(not isinstance(value.get(k),bool) for k in keys):raise RuntimeError('INVALID_PERFORMANCE_FLAGS')
 pool=value.get('frp_pool_count',8);maximum=value.get('frp_max_pool',32)
 if isinstance(pool,bool) or isinstance(maximum,bool) or not isinstance(pool,int) or not isinstance(maximum,int) or not 2<=pool<=maximum<=1000:raise RuntimeError('INVALID_POOL_RANGE')
 snap=snapshot();path=CFG/'frp'/('frpc.toml' if c['role']=='foreign' else 'frps.toml');unit='alireza-hashem-'+('frpc' if c['role']=='foreign' else 'frps')
 try:
  text=path.read_text();blocks=re.split(r'(?m)^\[\[proxies\]\]\s*$',text)
  if re.search(r'(?m)^\[',blocks[0]):raise RuntimeError('MANUAL_TOML_TABLES_REQUIRE_REVIEW')
  blocks[0]=set_toml_key(blocks[0],'transport.tcpMux',value['tcp_mux'])
  blocks[0]=set_toml_key(blocks[0],'transport.poolCount' if c['role']=='foreign' else 'transport.maxPoolCount',pool if c['role']=='foreign' else maximum)
  if c['role']=='foreign':
   for n in range(1,len(blocks)):
    blocks[n]=set_toml_key(blocks[n],'transport.useEncryption',value['proxy_encryption']);blocks[n]=set_toml_key(blocks[n],'transport.useCompression',value['proxy_compression'])
  text=blocks[0]+''.join('[[proxies]]\n'+b for b in blocks[1:]);temp=path.with_suffix('.new.toml');temp.write_text(text);temp.chmod(0o600)
  run([str(APP/'bin'/('frpc' if c['role']=='foreign' else 'frps')),'verify','-c',str(temp)],15)
  temp.replace(path);state=CFG/'state';state.mkdir(parents=True,exist_ok=True,mode=0o700);(state/'perf.json').write_text(json.dumps({**value,'frp_pool_count':pool,'frp_max_pool':maximum}));(state/'perf.json').chmod(0o600)
  run(['systemctl','restart',unit],30);run(['systemctl','is-active','--quiet',unit],15)
  return {'ok':True,'snapshot':snap.name,'forwarderRestarted':True,**status()}
 except Exception:
  restore(snap);raise RuntimeError('PERFORMANCE_APPLY_FAILED_ROLLED_BACK')
def logs():
 units=list(status()['services'])
 if not units:return {'logs':''}
 args=['journalctl','--no-pager','-n','120','-o','cat']
 for unit in units:args+=['-u',unit]
 text=run(args,10);token=read_json(ROOT/'last-config.json').get('token','')
 if token:text=text.replace(token,'[REDACTED]')
 return {'logs':text[-65536:]}
def benchmark():
 c=read_json(ROOT/'last-config.json')
 if not c:raise RuntimeError('NO_MANAGED_CONFIGURATION')
 import socket,statistics
 values=[];failures=0
 for n in range(5):
  started=time.monotonic()
  try:
   with socket.create_connection((c['remotePub'],c['port']),timeout=2):pass
   values.append((time.monotonic()-started)*1000)
  except OSError:failures+=1
 result={'kind':'TCP connect','target':c['remotePub']+':'+str(c['port']),'samples':5,'failures':failures,'failurePercent':failures*20,'meanMs':statistics.mean(values) if values else None,'minMs':min(values) if values else None,'maxMs':max(values) if values else None,'jitterMs':statistics.mean(abs(a-b) for a,b in zip(values,values[1:])) if len(values)>1 else None,'time':int(time.time())}
 (ROOT/'benchmark.json').write_text(json.dumps(result));return result
def main(v):
 op=v.get('operation')
 if op=='validate':return {'config':{k:x for k,x in config(v).items() if k!='token'},'command':args_for(v)}
 if op=='status':return status()
 if op=='install':return install()
 if op=='setup':return setup(v)
 if op=='benchmark':return benchmark()
 if op=='performance':guard();return performance(v)
 if op=='logs':return logs()
 guard();script=str(APP/'bin/hashem.sh')
 if op=='restart':
  for name in status()['services']:run(['systemctl','restart',name],30)
 elif op=='watchdog':
  run(['bash',script,'watchdog','on' if v.get('enabled') else 'off'],30)
  for name in UNIT_FILES:
   p=SYSTEMD/name
   if p.exists() and not p.read_text().startswith(MARKER):p.write_text(MARKER+p.read_text())
 elif op=='carrier':
  if not isinstance(v.get('mode'),str):raise RuntimeError('INVALID_CARRIER')
  old=read_json(ROOT/'last-config.json')
  if not old:raise RuntimeError('NO_MANAGED_CONFIGURATION')
  c=config({**old,'carrier':v['mode']});snap=snapshot()
  try:
   network_guard(c);check_ports(c,carrier_only=True);apply_carrier(c);(ROOT/'last-config.json').write_text(json.dumps(c));os.chmod(ROOT/'last-config.json',0o600);return {'ok':True,'snapshot':snap.name,**status()}
  except Exception:
   restore(snap);raise RuntimeError('CARRIER_UPDATE_FAILED_ROLLED_BACK')
 elif op=='ports':
  old=read_json(ROOT/'last-config.json')
  if not old:raise RuntimeError('NO_MANAGED_CONFIGURATION')
  return edit_ports(v)
 elif op=='backup':return {'snapshot':snapshot().name}
 elif op=='restore':
  sid=str(v.get('snapshot',''))
  if not re.fullmatch(r'\d{10,30}',sid):raise RuntimeError('INVALID_SNAPSHOT')
  dest=ROOT/'snapshots'/sid
  if not dest.is_dir():raise RuntimeError('SNAPSHOT_NOT_FOUND')
  restore(dest)
 elif op=='remove':
  snapshot()
  for name in status()['services']:run(['systemctl','disable','--now',name],30)
  timer=(SYSTEMD/'alireza-hashem-hashem-watchdog.timer')
  if timer.exists() and timer.read_text().startswith(MARKER):run(['systemctl','disable','--now',timer.name],30)
  cleanup_fou();restore_firewall({})
  return {'retained':'Configuration and snapshots retained; managed services stopped.'}
 else:raise RuntimeError('INVALID_OPERATION')
 return status()
if __name__=='__main__':
 try:
  data=json.loads(sys.stdin.read(131073));lock=None
  if data.get('operation') not in ['status','validate']:
   ROOT.mkdir(parents=True,exist_ok=True,mode=0o700);lock=(ROOT/'.operation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  print(json.dumps(main(data)))
 except Exception as e:print(json.dumps({'error':str(e) if isinstance(e,RuntimeError) else type(e).__name__}));sys.exit(1)
