#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Upgrade only already managed Mirza instances; never reset bot DB/config."""
import pathlib,importlib.util,os,fcntl
HERE=pathlib.Path(__file__).resolve().parent
if os.geteuid()!=0:raise SystemExit('Root required')
spec=importlib.util.spec_from_file_location('tenant_manager',HERE/'tenant-manager.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=pathlib.Path('/var/lib/alirezaserver/mirza-tenants')
for directory in sorted(base.glob('*')):
 if len(directory.name)!=24 or any(c not in '0123456789abcdef' for c in directory.name):continue
 scoped=m.module_for(directory.name)
 if not(scoped['APP']/'.alirezaserver-managed').exists():continue
 os.environ['ALIREZA_ROOT']=str(directory)
 with os.fdopen(os.open(scoped['STATE']/'.operation.lock',os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW,0o600),'a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  for op in ['repair-schema','upgrade-ui','repair-web']:scoped['main']({'operation':op})
 print('Managed Mirza instance upgraded:',directory.name)
