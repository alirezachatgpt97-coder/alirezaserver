<?php
// SPDX-License-Identifier: AGPL-3.0-or-later
// Local root-side helper; credentials are loaded locally, never passed in argv.
ini_set('display_errors', '0');
$op = $argv[1] ?? '';
$app = $argv[2] ?? '';
$destination = $argv[3] ?? '';
try {
    chdir($app);
    ob_start();
    require $app . '/config.php';
    ob_end_clean();
    if (!isset($pdo) || !$pdo instanceof PDO) throw new RuntimeException('BOT_DATABASE_UNAVAILABLE');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if ($op === 'check') {
        $stmt = $pdo->query("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='product'");
        $columns = array_map('strtolower', $stmt->fetchAll(PDO::FETCH_COLUMN));
        if (!$columns) throw new RuntimeException('BOT_PRODUCT_TABLE_MISSING');
        $default = $pdo->query("SELECT COLUMN_DEFAULT FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='product' AND COLUMN_NAME='status_product'")->fetchColumn();
        echo json_encode(['az_service'=>in_array('az_service',$columns,true),'geo_exits'=>in_array('geo_exits',$columns,true),'limitip'=>in_array('limitip',$columns,true),'status_product'=>in_array('status_product',$columns,true),'statusDefault'=>is_string($default) && strtoupper($default) !== 'NULL']);
    } elseif ($op === 'backup') {
        $create = $pdo->query('SHOW CREATE TABLE `product`')->fetch(PDO::FETCH_NUM)[1];
        $f = fopen($destination, 'x');
        if (!$f) throw new RuntimeException('BOT_BACKUP_FAILED');
        try {
            fwrite($f, json_encode(['schema'=>$create], JSON_THROW_ON_ERROR) . "\n");
            // Stream the snapshot, avoiding an unbounded array on a 1 GiB VPS.
            $buffered = $pdo->getAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY);
            $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
            try {
                $pdo->exec('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ');
                $pdo->beginTransaction();
                $stmt = $pdo->query('SELECT * FROM `product` ORDER BY `id`');
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    if (fwrite($f, json_encode($row, JSON_THROW_ON_ERROR) . "\n") === false) throw new RuntimeException('BOT_BACKUP_WRITE_FAILED');
                }
                $stmt->closeCursor();
                $pdo->commit();
            } finally {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, $buffered);
            }
            if (!fflush($f)) throw new RuntimeException('BOT_BACKUP_WRITE_FAILED');
        } finally { fclose($f); }
        echo json_encode(['backup'=>true]);
    } elseif ($op === 'migrate') {
        $migration = require $destination;
        $migration($pdo);
        echo json_encode(['migrated'=>true]);
    } else throw new RuntimeException('BOT_INVALID_OPERATION');
} catch (Throwable $e) {
    while (ob_get_level()) ob_end_clean();
    $code = $e instanceof PDOException ? 'BOT_DATABASE_ERROR_' . preg_replace('/[^A-Z0-9]/','',(string)$e->getCode()) : (preg_match('/^BOT_[A-Z_]+$/', $e->getMessage()) ? $e->getMessage() : 'BOT_SCHEMA_REPAIR_FAILED');
    fwrite(STDERR, $code . "\n");
    exit(1);
}
