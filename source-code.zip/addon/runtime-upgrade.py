#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Update only used APT runtimes, then verify patched versions of actual binaries.
No source compilation, third-party repository replacement or whole-system upgrade.
"""
import gzip,hashlib,os,pathlib,re,shutil,subprocess,sys
MIN_NODE={24:(24,22,1),26:(26,12,1)}
MIN_PHP={(8,2):(8,2,35),(8,3):(8,3,36),(8,4):(8,4,27),(8,5):(8,5,12)}
def version(text):
 m=re.search(r'(\d+)\.(\d+)\.(\d+)',text)
 if not m:raise RuntimeError('RUNTIME_VERSION_UNREADABLE')
 return tuple(map(int,m.groups()))
def node_safe(v):return v[0] in MIN_NODE and v>=MIN_NODE[v[0]]
def php_safe(v):return v[:2] in MIN_PHP and v>=MIN_PHP[v[:2]]
def backported(branch):
 cli=pathlib.Path(shutil.which('php') or '/nonexistent').resolve();fpm=pathlib.Path('/usr/sbin')/branch.replace('php','php-fpm',1)
 for binary,package in [(cli,branch+'-cli'),(fpm,branch+'-fpm')]:
  result=subprocess.run(['dpkg-query','-S',str(binary)],capture_output=True,text=True,timeout=15)
  if result.returncode or not result.stdout.startswith(package+':'):return False
 versions=output(['dpkg-query','-W','-f=${Version}\n',branch+'-cli',branch+'-fpm',branch+'-common']).splitlines()
 if len(set(versions))!=1:return False
 files=[pathlib.Path('/usr/share/doc')/(branch+'-common')/'changelog.Debian.gz',pathlib.Path('/usr/share/doc')/(branch+'-fpm')/'changelog.Debian.gz']
 for p in files:
  if p.is_file():
   with gzip.open(p,'rt',errors='replace') as f:text=f.read(1024*1024)
   if all(c in text for c in ['CVE-2026-109618','CVE-2026-109619']):return True
 return False
def output(args):return subprocess.check_output(args,text=True,stderr=subprocess.STDOUT,timeout=30)
def installed_packages(pattern):
 r=subprocess.run(['dpkg-query','-W','-f=${binary:Package} ${db:Status-Status}\n',pattern],capture_output=True,text=True,timeout=30)
 return [line.split()[0] for line in r.stdout.splitlines() if line.endswith(' installed') and re.fullmatch(r'[a-z0-9.+:-]+',line.split()[0])]
def main():
 if os.geteuid()!=0:raise RuntimeError('ROOT_REQUIRED')
 php='--php' in sys.argv or ('--installed' in sys.argv and (pathlib.Path('/opt/alirezabot/.alirezaserver-managed').exists() or any(pathlib.Path('/opt').glob('azb*/.alirezaserver-managed'))))
 packages=[]
 node_path=shutil.which('node');before_node=None
 if node_path:
  with open(node_path,'rb') as f:before_node=hashlib.file_digest(f,'sha256').hexdigest()
 if '--node' in sys.argv or '--installed' in sys.argv:packages+=installed_packages('nodejs')
 if php:
  packages+=installed_packages('php*-cli')+installed_packages('php*-fpm')+installed_packages('php*-common')+installed_packages('php*-mysql')+installed_packages('php*-curl')+installed_packages('php*-mbstring')+installed_packages('php*-zip')+installed_packages('php*-gd')+installed_packages('php*-xml')+installed_packages('php*-bcmath')+installed_packages('php*-opcache')
 before_packages=output(['dpkg-query','-W','-f=${binary:Package}=${Version}\n',*sorted(set(packages))]) if packages else ''
 if packages:
  subprocess.run(['apt-get','-o','DPkg::Lock::Timeout=300','update'],check=True,timeout=300)
  subprocess.run(['apt-get','-o','DPkg::Lock::Timeout=300','install','--only-upgrade','-y',*sorted(set(packages))],check=True,timeout=600)
 if '--node' in sys.argv or '--installed' in sys.argv:
  binary=shutil.which('node');v=version(output([binary,'--version']))
  if not node_safe(v):raise RuntimeError('NODE_SECURITY_UPDATE_REQUIRED: selected binary '+str(binary)+' is '+'.'.join(map(str,v))+'; use patched Node 24/26 from its supported repository')
  with open(binary,'rb') as f:after_node=hashlib.file_digest(f,'sha256').hexdigest()
  if before_node and before_node!=after_node:print('NODE_RESTART_REQUIRED')
  print('Node runtime security baseline passed: '+'.'.join(map(str,v)))
 if php:
  v=version(output(['php','--version']));branch='php'+'.'.join(map(str,v[:2]));fpm=pathlib.Path('/usr/sbin')/(branch.replace('php','php-fpm',1));fv=version(output([str(fpm),'--version']))
  if v<(8,2,0) or fv<(8,2,0):raise RuntimeError('BOT_REQUIRES_PHP_82_OR_NEWER')
  if not (php_safe(v) and php_safe(fv)) and not (v[:2]==fv[:2] and backported(branch)):raise RuntimeError('PHP_SECURITY_UPDATE_REQUIRED: CLI/FPM need supported security packages; installation retained')
  after_packages=output(['dpkg-query','-W','-f=${binary:Package}=${Version}\n',*sorted(set(packages))]) if packages else ''
  old_php='\n'.join(x for x in before_packages.splitlines() if x.startswith('php'));new_php='\n'.join(x for x in after_packages.splitlines() if x.startswith('php'))
  if old_php!=new_php:print('PHP_RESTART_REQUIRED')
  print('PHP CLI and FPM security baseline passed')
if __name__=='__main__':
 try:main()
 except Exception as e:print(str(e),file=sys.stderr);sys.exit(1)
