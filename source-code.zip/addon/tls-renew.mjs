import {deployIP,validIP} from './tls-core.mjs';import {pathToFileURL} from 'node:url';import fs from 'node:fs';import {createHash,X509Certificate} from 'node:crypto';import {execFile} from 'node:child_process';import {promisify} from 'node:util';
if(process.getuid?.()!==0)throw Error('ROOT_REQUIRED');
const policy='/var/lib/alirezaserver/ip-certificate.json';
if(fs.existsSync(policy)){
 const m=JSON.parse(fs.readFileSync(policy,'utf8'));if(!validIP(m.host)||m.name!=='alireza-ip-'+createHash('sha256').update(m.host).digest('hex').slice(0,16)||m.certPem!=='/etc/nova/origin.pem')throw Error('TLS_INVALID_RENEWAL_POLICY');
 if(new X509Certificate(fs.readFileSync(m.certPem)).fingerprint256===m.lastFingerprint){
  await promisify(execFile)('/opt/alirezaserver-acme/bin/certbot',['--config-dir','/var/lib/alirezaserver/ip-acme/config','--work-dir','/var/lib/alirezaserver/ip-acme/work','--logs-dir','/var/lib/alirezaserver/ip-acme/logs','renew','--cert-name',m.name,'--quiet'],{timeout:240000,maxBuffer:1048576});
  const{writeFileAtomic}=await import(pathToFileURL((process.env.ALIREZA_NOVA_DIR||'/opt/nova-node-agent')+'/src/cert.mjs'));console.log(JSON.stringify(await deployIP({write:writeFileAtomic})));
 }else console.log('IP renewal inactive: the primary certificate was replaced.');
}
