#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Loopback-only FastCGI gateway reached exclusively through a pinned SSH tunnel."""
import http.server,threading,socket,struct,json,pathlib,subprocess,os,hmac,mimetypes,urllib.parse,tempfile,tarfile
HERE=pathlib.Path(__file__).resolve().parent
CONF=json.loads((HERE/'remote-gateway.json').read_text()) if __name__=='__main__' else {}
APP=pathlib.Path(os.environ.get('ALIREZABOT_APP','/opt/alirezabot'))
SOCKET=os.environ.get('ALIREZABOT_SOCKET','/run/alirezabot/php.sock')
SLOTS=threading.BoundedSemaphore(6)
def record(t,b=b''):return struct.pack('!BBHHBB',1,t,1,len(b),0,0)+b
def nv(n):return bytes([n]) if n<128 else struct.pack('!I',n|0x80000000)
def params(env):
 out=b''
 for k,v in env.items():
  a=k.encode();b=str(v).encode();out+=nv(len(a))+nv(len(b))+a+b
 return out
def fcgi_socket():
 # TCP override is loopback-only and used by isolated development tests.
 if SOCKET.startswith('tcp:127.0.0.1:'):
  return socket.create_connection(('127.0.0.1',int(SOCKET.rsplit(':',1)[1])),90)
 s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.settimeout(90);s.connect(SOCKET);return s
def exact(s,n):
 out=b''
 while len(out)<n:
  b=s.recv(n-len(out))
  if not b:raise RuntimeError('FASTCGI_CLOSED')
  out+=b
 return out
def public_path(tail):
 name=urllib.parse.unquote(tail.split('?')[0])
 if any(ord(c)<32 for c in name) or '\\' in name or any(p=='..' or p.startswith('.') for p in name.split('/')):return None
 if not name:name='panel/'
 if name.split('/')[0] not in ['panel','app','api','payment','sub','fonts','storage']:return None
 if any(p in ['inc','vendor','state','db'] for p in name.split('/')):return None
 if pathlib.Path(name).suffix.lower() in ['.sql','.log','.bak','.b64']:return None
 if name.startswith('storage/') and pathlib.Path(name).suffix.lower() not in ['.png','.jpg','.jpeg','.webp','.gif']:return None
 if name.startswith('sub/') and len(name.split('/'))==2 and 32<=len(name.split('/')[1])<=64:name='sub/index.php'
 if name.startswith('app/') and not pathlib.Path(name).suffix and not name.endswith('/'):name='app/index.php'
 return name+'index.php' if name.endswith('/') else name
class Handler(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.0'
 def log_message(self,*a):pass # No tokens, subscription URLs or request bodies in logs.
 def send(self,code,data=b'',kind='application/json'):
  if not isinstance(data,bytes):data=json.dumps(data).encode()
  self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
 def do_GET(self):self.handle_request()
 def do_POST(self):self.handle_request()
 def do_PUT(self):self.handle_request()
 def do_DELETE(self):self.handle_request()
 def do_PATCH(self):self.handle_request()
 def handle_request(self):
  if not hmac.compare_digest(self.headers.get('X-AZ-Gateway',''),CONF.get('token','')):self.send(403,{'error':'GATEWAY_AUTH_REQUIRED'});return
  if not SLOTS.acquire(False):self.send(503,{'error':'GATEWAY_BUSY'});return
  try:self.dispatch()
  except (BrokenPipeError,ConnectionResetError):pass
  except Exception:self.send(502,{'error':'REMOTE_WEB_UNAVAILABLE'})
  finally:SLOTS.release()
 def dispatch(self):
  self.connection.settimeout(95)
  size=int(self.headers.get('Content-Length','0'))
  if size<0 or size>16*1024*1024:self.send(413,{'error':'BODY_TOO_LARGE'});return
  data=self.rfile.read(size) if size else b''
  if self.path=='/_backup' and self.command=='POST':
   with tempfile.TemporaryDirectory(prefix='alirezabot-backup-') as temp:
    dump=pathlib.Path(temp)/'alirezabot.sql'
    with dump.open('wb') as stream:
     result=subprocess.run(['mariadb-dump','--protocol=socket','-u','root','--single-transaction','--routines','--triggers','--events','--databases','alirezabot'],stdout=stream,stderr=subprocess.PIPE,timeout=180)
    if result.returncode:self.send(502,{'error':'REMOTE_DATABASE_BACKUP_FAILED'});return
    archive=pathlib.Path(temp)/'remote-bot.tar.gz'
    with tarfile.open(archive,'w:gz') as tar:
     tar.add(dump,arcname='database/alirezabot.sql')
     for source in ['/opt/alirezabot','/var/lib/alirezabot','/opt/alirezaserver-remote-bot']:
      tar.add(source,arcname=source.lstrip('/'),filter=lambda m:None if '/sess_' in m.name else m)
    self.send_response(200);self.send_header('Content-Type','application/gzip');self.send_header('Content-Length',str(archive.stat().st_size));self.send_header('Cache-Control','no-store');self.end_headers()
    with archive.open('rb') as stream:
     while True:
      block=stream.read(65536)
      if not block:break
      self.wfile.write(block)
   return
  if self.path=='/_manage' and self.command=='POST':
   v=json.loads(data);op=v.get('operation')
   if op not in ['status','start','stop','restart','uninstall','retry-failed','repair-web','reset-password','sync-local','upgrade-ui','repair-schema']:self.send(403,{'error':'OPERATION_REFUSED'});return
   p=subprocess.run(['python3',str(HERE/'bot-manager.py')],input=json.dumps(v),capture_output=True,text=True,timeout=720)
   try:r=json.loads(p.stdout)
   except ValueError:r={'error':'REMOTE_MANAGEMENT_FAILED'}
   self.send(200 if p.returncode==0 else 502,r);return
  if not self.path.startswith('/web/'):self.send(404,{});return
  tail=self.path[5:];name=public_path(tail)
  if not name:self.send(404,{});return
  root=APP;file=root/name
  if file.is_symlink() or not file.is_file() or not file.resolve().is_relative_to(root):self.send(404,{});return
  if file.suffix!='.php':
   kind=mimetypes.guess_type(str(file))[0]
   if not kind or file.suffix.lower() not in ['.css','.js','.svg','.png','.jpg','.jpeg','.webp','.woff2','.woff','.ttf','.ico','.json','.gif']:self.send(404,{});return
   body=file.read_bytes()
   if kind=='text/css' and name.startswith('app/assets/'):body=body.replace(b'url(/app/',b'url(../')
   self.send(200,body,kind);return
  prefix=self.headers.get('X-AZ-Prefix','')
  if not prefix.startswith('/') or any(c in prefix for c in '\r\n;') or len(prefix)>512:self.send(400,{});return
  env={'GATEWAY_INTERFACE':'CGI/1.1','SERVER_SOFTWARE':'alirezaserver','REQUEST_METHOD':self.command,'SCRIPT_FILENAME':str(file),'SCRIPT_NAME':prefix+name,'REQUEST_URI':prefix+tail,'QUERY_STRING':tail.partition('?')[2],'DOCUMENT_ROOT':str(root),'SERVER_PROTOCOL':'HTTP/1.1','SERVER_NAME':self.headers.get('Host','localhost').split(':')[0],'SERVER_PORT':'443','HTTPS':'on','REMOTE_ADDR':self.headers.get('X-AZ-Client','127.0.0.1'),'CONTENT_TYPE':self.headers.get('Content-Type',''),'CONTENT_LENGTH':str(len(data)),'PHP_VALUE':'session.cookie_path='+prefix+'\nsession.cookie_secure=1\nsession.cookie_httponly=1\nsession.cookie_samesite=Lax'}
  for k,v in self.headers.items():
   if k.lower() not in ['connection','transfer-encoding','content-length','content-type','proxy','cookie'] and not k.lower().startswith(('x-forwarded-','x-az-')):env['HTTP_'+k.upper().replace('-','_')]=v
  env['HTTP_COOKIE']='; '.join(x.strip() for x in self.headers.get('Cookie','').split(';') if x.strip().startswith(('PHPSESSID=','XSRF-TOKEN=')))
  with fcgi_socket() as s:
   s.sendall(record(1,b'\x00\x01'+b'\x00'*6))
   for typ,body in [(4,params(env)),(5,data)]:
    for i in range(0,len(body),65535):s.sendall(record(typ,body[i:i+65535]))
    s.sendall(record(typ))
   pending=b'';sent=False
   while True:
    head=exact(s,8);_,kind,_,length,padding,_=struct.unpack('!BBHHBB',head);body=exact(s,length);exact(s,padding)
    if kind==3:
     if not sent:self.send(502,{'error':'PHP_NO_RESPONSE'})
     return
    if kind!=6:continue
    if not sent:
     pending+=body
     if len(pending)>65536:raise RuntimeError('PHP_HEADERS_TOO_LARGE')
     sep=b'\r\n\r\n' if b'\r\n\r\n' in pending else b'\n\n'
     if sep not in pending:continue
     h,body=pending.split(sep,1);headers=[];status=200
     for line in h.decode(errors='replace').splitlines():
      k,_,v=line.partition(':');v=v.strip()
      if k.lower()=='status':status=int(v[:3])
      elif k.lower() not in ['content-length','transfer-encoding','connection','x-powered-by']:
       if k.lower()=='set-cookie':
        import re
        v=re.sub(r'Path=[^;]*','Path='+prefix,v,flags=re.I)
       if k.lower()=='location' and v.startswith('/'):v=prefix+v.lstrip('/');status=302 if status==200 else status
       headers.append((k,v))
     self.send_response(status)
     for k,v in headers:self.send_header(k,v)
     self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();sent=True
    if body:self.wfile.write(body)
if __name__=='__main__':
 server=http.server.ThreadingHTTPServer(('127.0.0.1',int(CONF['port'])),Handler);server.daemon_threads=True;server.serve_forever()
