import {selectProfile} from './compat-profile.mjs';
// SPDX-License-Identifier: GPL-3.0-or-later
// Narrow, hash-guarded ESM decorators. Native files on disk remain unchanged.
import{registerHooks}from'node:module';import{readFileSync}from'node:fs';import{createHash}from'node:crypto';import{resolve}from'node:path';import{pathToFileURL,fileURLToPath}from'node:url';
const dir=resolve(process.env.ALIREZA_NOVA_DIR||'/opt/nova-node-agent');const expected=selectProfile(dir).files;const helper=new URL('./host-core.mjs',import.meta.url).href;
const coordinator=new URL('./tls-coordinator.mjs',import.meta.url).href;
const tls=new URL('./tls-core.mjs',import.meta.url).href;
const access=new URL('./xray-access.mjs',import.meta.url).href;
const decorators={
 'src/server.mjs':`const __azHealth=certHealth;certHealth=(f,h)=>__azTLS.certificateHealth(__azHealth,f,h);const __azDomainJob=runDomainJob;runDomainJob=(kv,o,p,d)=>__azCoordinator.coordinatedJob(__azDomainJob,kv,o,p,d,{getSettings,resolveXrayOpts:xrayOptsFor,provision:provisionCert,findZone:cfFindZone});`,
 'src/cert.mjs':`withPort80Free=action=>action();const __azCert=provisionCert,__azValid=isValidDomain,__azCovers=certCoversDomain;isValidDomain=v=>__azTLS.validIP(String(v))||__azValid(v);certCoversDomain=(c,h)=>__azTLS.covers(__azCovers,c,h);provisionCert=o=>__azTLS.provision(__azCert,o,{writeFileAtomic});`,
 'src/xray/manager.mjs':`const __azWriteRuntime=writeJsonAtomic;writeJsonAtomic=(p,v,o)=>__azAccess.writeRuntimeJSON(__azWriteRuntime,p,v,o);`,
 'src/xray/inbounds.mjs':`const __azNormalizeProfile=normalizeProfile,__azApplyProfile=applyProfile;normalizeProfile=v=>__az.normalizeHost(__azNormalizeProfile,v);applyProfile=(i,p)=>__azApplyProfile(i,p?.keepSniBlank?{...p,sni:''}:p);`,
 'src/subscription.mjs':`const __azLine=inboundLine;inboundLine=(u,i,o)=>__az.inboundURI(__azLine,u,i,o);const __azBuildSub=buildSub;buildSub=(u,o)=>__az.rawSubscription(__azBuildSub,u,o,normalizeInbound);`,
 'src/sub-formats.mjs':`const __azEnumerate=enumerateProxies,__azClash=toClash,__azSingbox=toSingbox;enumerateProxies=(u,o)=>__az.enumerate(__azEnumerate,u,o,normalizeInbound);toClash=(p,o)=>__az.clash(__azClash,p,o);toSingbox=(p,o)=>__az.singbox(__azSingbox,p,o);`,
 'src/xray-json.mjs':`const __azClient=xrayClientConfig;xrayClientConfig=(p,o)=>__az.xrayConfig(__azClient,p,o);`
};
registerHooks({load(url,context,next){const key=Object.keys(decorators).find(k=>url===pathToFileURL(resolve(dir,k)).href);const result=next(url,context);if(!key)return result;const source=typeof result.source==='string'?result.source:Buffer.from(result.source).toString();if(createHash('sha256').update(source).digest('hex')!==expected[key])throw Error('HOST_NATIVE_CONTRACT_CHANGED: '+key);return{...result,source:source+'\nimport * as __az from '+JSON.stringify(helper)+';\n'+(key==='src/xray/manager.mjs'?'import * as __azAccess from '+JSON.stringify(access)+';\n':'')+(['src/cert.mjs','src/server.mjs'].includes(key)?'import * as __azTLS from '+JSON.stringify(tls)+';\n':'')+(key==='src/server.mjs'?'import * as __azCoordinator from '+JSON.stringify(coordinator)+';\n':'')+decorators[key]+'\n'};}});
