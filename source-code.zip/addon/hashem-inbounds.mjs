// SPDX-License-Identifier: GPL-3.0-or-later
// Explicit native inbound provisioning; never edits an existing listener/account.
import{randomBytes}from'node:crypto';
let busy=false;
const fail=(code,status=400)=>Object.assign(Error(code),{status,code});
export async function createMatching(native,v){
 if(v.confirm!==true)throw fail('HASHEM_CONFIRM_REQUIRED');
 if(busy)throw fail('HASHEM_INBOUND_BUSY',409);
 const ports=[...new Set(String(v.ports||'').split(/[\s,]+/).map(Number))],host=String(v.host||'').trim(),path=String(v.path||'/@alirezaserver').trim(),nodeId=String(v.nodeId||'local');
 if(!ports.length||ports.length>32||ports.some(p=>!Number.isInteger(p)||p<1||p>65535))throw fail('HASHEM_INVALID_INBOUND_PORTS');
 if(!host||host.length>253||/[\s/@?#]/.test(host)||!/^\/[\x21-\x7e]{0,255}$/.test(path)||nodeId!=='local')throw fail('HASHEM_INVALID_INBOUND_SETTINGS');
 busy=true;const batch='Hashem-'+randomBytes(12).toString('hex')+'-',created=[];
 try{
  const current=(await native('/admin/inbounds')).inbounds||[];
  for(const port of ports)if(current.some(i=>(i.nodeId||'local')===nodeId&&Number(i.port)===port))throw fail('HASHEM_INBOUND_PORT_CONFLICT:'+port,409);
  for(const port of ports){const inbound={protocol:'vless',network:'ws',security:'none',port,listen:'0.0.0.0',path,remark:batch+port,nodeId,enabled:true,allUsers:false,userIds:[],profiles:[{name:'Hashem',address:host,port,path}]};
   const result=await native('/admin/inbounds','POST',{action:'add',inbound});
   const row=result.inbounds?.find(i=>i.remark===inbound.remark);if(row)created.push(row.id);
   if(result.apply?.ok===false)throw fail('HASHEM_NATIVE_CORE_REJECTED',502);
   if(!row)throw fail('HASHEM_NATIVE_CREATE_UNCONFIRMED',502);
  }
  return{ok:true,ids:created,ports,requiresUserAssignment:true};
 }catch(e){
  // A timed-out native request may have committed before its response was lost.
  // Recover only this unpredictable batch's IDs, then delete just those records.
  try{const rows=(await native('/admin/inbounds')).inbounds||[];for(const i of rows)if(i.remark?.startsWith(batch)&&!created.includes(i.id))created.push(i.id);}catch{e=fail('HASHEM_CREATE_STATE_UNCERTAIN_INSPECT_INBOUNDS',502);}
  let failed=0;for(const id of created.reverse())try{const r=await native('/admin/inbounds','POST',{action:'delete',id});if(r.apply?.ok===false)failed++;}catch{failed++;}
  if(failed)throw fail('HASHEM_INBOUND_ROLLBACK_INCOMPLETE_INSPECT_INBOUNDS',502);throw e;
 }finally{busy=false;}
}
