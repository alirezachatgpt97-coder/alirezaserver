// SPDX-License-Identifier: GPL-3.0-or-later
// Narrow 3x-ui compatibility surface for Mirza. Existing Nova accounts are never adopted.
import {randomBytes,randomUUID} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync,renameSync} from 'node:fs';
const root=process.env.ALIREZA_ROOT||'/var/lib/alirezaserver';
const fail=(message,status=400)=>Object.assign(Error(message),{status});
export function createBridge(native,{load,save}={}){
 load ||=()=>{try{return JSON.parse(readFileSync(root+'/bot-users.json'));}catch(e){if(e.code==='ENOENT')return {};throw e;}};
 save ||=v=>{mkdirSync(root,{recursive:true,mode:0o700});writeFileSync(root+'/bot-users.json.tmp',JSON.stringify(v),{mode:0o600});renameSync(root+'/bot-users.json.tmp',root+'/bot-users.json');};
 let queue=Promise.resolve();
 const serial=f=>{const p=queue.then(f);queue=p.catch(()=>{});return p;};
 const answer=obj=>({success:true,msg:'',obj});
 async function users(){return(await native('/admin/network-settings.json')).users||[];}
 async function lookup(name){const all=load(),entry=all[name]||Object.values(all).find(v=>v.uuid===name),u=entry&&(await users()).find(u=>u.id===entry.id);if(!entry||!u)throw fail('BOT_ACCOUNT_NOT_FOUND',404);return{entry,u,all};}
 async function connection(u,entry){const links=await native('/admin/user-links?id='+encodeURIComponent(u.id));return{client:client(u,entry),inboundIds:u.inboundIds||[],configs:(links.links||[]).map(l=>l.uri).filter(Boolean),subscriptionUrl:links.subUrl};}
 const expiry=u=>u.expiry?Date.parse(u.expiry):0;
 const client=(u,entry)=>({id:u.uuid,email:entry.name,enable:u.enabled!==false,totalGB:Number(u.quotaBytes)||0,expiryTime:expiry(u),limitIp:Number(u.ipLimit)||0,subId:entry.subId,comment:u.note||'',geoExits:u.geoExits===true});
 const shape=(c,old={})=>{if(c.expiryTime!==undefined&&(!Number.isSafeInteger(Number(c.expiryTime))||Number(c.expiryTime)<0))throw fail('NOVA_ON_HOLD_EXPIRY_NOT_SUPPORTED');const quota=c.totalGB===undefined?old.quotaBytes:Number(c.totalGB);if(quota!==undefined&&(!Number.isSafeInteger(quota)||quota<0))throw fail('INVALID_QUOTA');const limit=c.limitIp===undefined?old.ipLimit:Number(c.limitIp);if(limit!==undefined&&(!Number.isInteger(limit)||limit<0))throw fail('INVALID_DEVICE_LIMIT');if(c.geoExits!==undefined&&typeof c.geoExits!=='boolean')throw fail('INVALID_GEO_EXITS');const result={...old,...(c.geoExits!==undefined?{geoExits:c.geoExits}:{}),...(c.enable!==undefined?{enabled:!!c.enable}:{}),...(quota!==undefined?{quotaBytes:quota}:{}),...(limit!==undefined?{ipLimit:limit}:{}),...(c.comment!==undefined?{note:String(c.comment).slice(0,4000)}:{})};if(c.expiryTime!==undefined)result.expiry=Number(c.expiryTime)?new Date(Number(c.expiryTime)).toISOString():'';if(c.id!==undefined){if(!/^[a-f0-9-]{36}$/i.test(c.id))throw fail('INVALID_UUID');result.uuid=c.id;}return result;};
 async function perform(route,method,data){
  if(route==='/panel/api/inbounds/list'&&method==='GET'){const r=await native('/admin/inbounds');return answer(r.inbounds.map(i=>({id:i.id,remark:i.remark,port:i.port,protocol:i.protocol,enable:i.enabled!==false})));}
  if(route==='/panel/api/server/status'&&method==='GET'){await native('/admin/whoami');return answer({appStats:{version:'alirezaserver'},capabilities:{onHold:false,trafficDirections:false}});}
  if(route==='/panel/api/clients/add'&&method==='POST'){
   const c=data.client||{},name=String(c.email||'');if(!/^[A-Za-z0-9_.@-]{1,128}$/.test(name))throw fail('INVALID_USERNAME');if(c.subId&&!/^[a-f0-9]{16,64}$/.test(c.subId))throw fail('INVALID_SUBSCRIPTION_ID');const all=load(),existing=(await users()).find(u=>(u.name||u.email)===name);if(existing&&!all[name])throw fail('USERNAME_EXISTS',409);
   const available=(await native('/admin/inbounds')).inbounds||[];const requested=data.inboundIds;const ids=Array.isArray(requested)&&!requested.length?(available.filter(i=>i.enabled!==false).map(i=>i.id).length?available.filter(i=>i.enabled!==false).map(i=>i.id):null):requested;if(ids!==undefined&&ids!==null&&(!Array.isArray(ids)||ids.some(id=>!available.some(i=>i.id===id&&i.enabled!==false))))throw fail('INVALID_INBOUND_ASSIGNMENT');
   const id=existing?.id||all[name]?.id||'bot-'+randomBytes(8).toString('hex'),user=shape(c,existing||{id,uuid:randomUUID(),name,email:name,enabled:true,inboundIds:ids||null,quotaBytes:0,ipLimit:0});
   const result=await native('/admin/users.json','POST',{action:existing?'update':'add',user});all[name]={...all[name],id,name,uuid:user.uuid,subId:all[name]?.subId||c.subId||randomBytes(24).toString('hex')};save(all);if(result.apply?.ok===false)throw fail('NOVA_CORE_APPLY_FAILED',502);
   const connected=await connection(user,all[name]);all[name].subUrl=connected.subscriptionUrl;save(all);if(!connected.configs.length)throw fail('NOVA_NO_ACTIVE_CONNECTION_LINKS: enable an inbound and retry this account',409);return answer(connected);
  }
  let m=route.match(/^\/panel\/api\/clients\/(get|update|del|resetTraffic|traffic)\/([^/]+)$/);const attach=route.match(/^\/panel\/api\/clients\/([^/]+)\/attach$/);if(attach){m=[attach[0],'attach',attach[1]];if(Array.isArray(data))data={inboundIds:data};}if(!m)throw fail('BOT_ROUTE_NOT_SUPPORTED',404);
  const op=m[1],name=decodeURIComponent(m[2]),{entry,u,all}=await lookup(name);
  if(op==='get'&&method==='GET')return answer(await connection(u,entry));
  if(op==='traffic'&&method==='GET'){const r=await native('/admin/usage-data'),used=r.usage?.[u.id];if(used===undefined)throw fail('NOVA_TRAFFIC_NOT_AVAILABLE',503);const total=Number(used);if(!Number.isFinite(total))throw fail('NOVA_TRAFFIC_NOT_AVAILABLE',503);return answer({up:0,down:total,lastOnline:Number(r.lastActive?.[u.id]||0),trafficDirectionUnavailable:true});}
  if(method!=='POST')throw fail('METHOD_NOT_ALLOWED',405);
  if(op==='del'){const applied=await native('/admin/users.json','POST',{action:'delete',user:{id:u.id}});delete all[entry.name];save(all);if(applied.apply?.ok===false)throw fail('NOVA_CORE_APPLY_FAILED',502);return answer(null);}
  if(op==='resetTraffic'){const result=await native('/admin/users.json','POST',{action:'bulk',op:'reset',ids:[u.id]});if(result.apply?.ok===false)throw fail('NOVA_CORE_APPLY_FAILED',502);return answer(null);}
  if(op==='update'||op==='attach'){
   const change=data.client||data;if(change.subId&&!/^[a-f0-9]{16,64}$/.test(change.subId))throw fail('INVALID_SUBSCRIPTION_ID');const updated=shape(change,u);if(op==='attach'||data.inboundIds){const ids=data.inboundIds;const available=(await native('/admin/inbounds')).inbounds||[];if(!Array.isArray(ids)||!ids.length||ids.some(id=>typeof id!=='string'||!available.some(i=>i.id===id)))throw fail('INVALID_INBOUND_ASSIGNMENT');updated.inboundIds=ids;}
   const applied=await native('/admin/users.json','POST',{action:'update',user:updated});entry.uuid=updated.uuid;save(all);if(applied.apply?.ok===false)throw fail('NOVA_CORE_APPLY_FAILED',502);const c=data.client||data;if(c.subId){if(!/^[a-f0-9]{16,64}$/.test(c.subId))throw fail('INVALID_SUBSCRIPTION_ID');entry.subId=c.subId;entry.subUrl=(await native('/admin/user-links?id='+encodeURIComponent(u.id))).subUrl;}save(all);return answer(await connection(updated,entry));
  }throw fail('BOT_ROUTE_NOT_SUPPORTED',404);
 }
 return{request:(route,method='GET',data={})=>serial(()=>perform(route,method,data)),async subscription(token){if(!/^[a-f0-9]{16,64}$/.test(token))return null;const entry=Object.values(load()).find(v=>v.subId===token);if(!entry)return null;const u=(await users()).find(u=>u.id===entry.id);if(!u||u.enabled===false)return null;return(await connection(u,entry)).subscriptionUrl||null;}};
}
