// SPDX-License-Identifier: GPL-3.0-or-later
// Product contracts for real Nova grants and the existing OpenVPN/HyperDNS APIs.
import {randomBytes} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync,renameSync} from 'node:fs';
import https from 'node:https';
import * as ovpn from './backend.mjs';
import * as dns from './alirezadns.mjs';
import {seal,unseal} from './vault.mjs';
import {publicOrigin} from './site-address.mjs';
const root=process.env.ALIREZA_ROOT||'/var/lib/alirezaserver';
export const FLAGS=['awg','mtproto','mieru','soar','tgweb','smartDns','smartDnsVip'];
const fail=(m,s=400)=>Object.assign(Error(m),{status:s,code:m});
export function spec(v){
 if(v===undefined||v===null||v==='')return null;
 if(typeof v==='string'){try{v=JSON.parse(v);}catch{throw fail('BOT_SERVICE_INVALID');}}
 if(!v||typeof v!=='object'||Array.isArray(v))throw fail('BOT_SERVICE_INVALID');
 if(v.kind==='nova'){
  if(!Array.isArray(v.grants)||v.grants.some(x=>!FLAGS.includes(x))||!Array.isArray(v.inboundIds)||v.inboundIds.length>1000||v.inboundIds.some(x=>typeof x!=='string'||x.length>128))throw fail('BOT_SERVICE_INVALID');
  const grants=[...new Set(v.grants)];if(grants.includes('smartDnsVip')&&!grants.includes('smartDns'))grants.push('smartDns');
  if(!grants.length&&!v.inboundIds.length)throw fail('BOT_SERVICE_EMPTY');return{kind:'nova',grants,inboundIds:[...new Set(v.inboundIds)]};
 }
 if(v.kind==='openvpn'&&/^[a-f0-9]{12}$/.test(v.serverId||''))return{kind:'openvpn',serverId:v.serverId};
 if(v.kind==='alirezadns'&&/^[a-f0-9]{12}$/.test(v.nodeId||''))return{kind:'alirezadns',nodeId:v.nodeId};
 throw fail('BOT_SERVICE_INVALID');
}
const keyFile=root+'/bot-dns-keys.json';
function keys(){try{return unseal(JSON.parse(readFileSync(keyFile)),'bot-dns-keys');}catch(e){if(e.code==='ENOENT')return{};throw e;}}
export async function dnsRequest(id,route,method='GET',data,key){
 const n=dns.node(id),k=key||keys()[id];if(!k)throw fail('BOT_DNS_API_KEY_REQUIRED',409);
 if(!/^\/(?:api\/v[12]\/(?:status|version|clients(?:[/?][A-Za-z0-9_/?=&.-]+)?)|sub\/)/.test(route))throw fail('BOT_DNS_ROUTE_REFUSED');
 return new Promise((resolve,reject)=>{const req=https.request({hostname:n.domain,port:n.port,servername:n.domain,path:'/'+n.adminPath+route,method,lookup:(_h,o,cb)=>cb(null,o?.all?[{address:n.host,family:4}]:n.host,4),headers:{'X-API-Key':k,'content-type':'application/json'},timeout:20000},res=>{let text='';res.on('data',b=>{text+=b;if(text.length>2*1024*1024)req.destroy(fail('BOT_DNS_RESPONSE_SIZE',502));});res.on('end',()=>{try{if(res.statusCode>=400)throw fail('BOT_DNS_HTTP_'+res.statusCode,502);resolve(text?JSON.parse(text):{});}catch(e){reject(e);}});});req.on('timeout',()=>req.destroy(fail('BOT_DNS_TIMEOUT',504)));req.on('error',()=>reject(fail('BOT_DNS_UNREACHABLE',502)));req.end(data?JSON.stringify(data):undefined);});
}
export async function connectDNS(id,key){dns.node(id);if(typeof key!=='string'||key.length<16||key.length>512||/[\r\n]/.test(key))throw fail('BOT_DNS_INVALID_KEY');await dnsRequest(id,'/api/v2/status','GET',undefined,key);const all=keys();all[id]=key;mkdirSync(root,{recursive:true,mode:0o700});writeFileSync(keyFile+'.new',JSON.stringify(seal(all,'bot-dns-keys')),{mode:0o600});renameSync(keyFile+'.new',keyFile);return{ok:true};}
export function createServices(native,{owner=true,openvpn=ovpn,dnsCall=dnsRequest,dnsNodes=()=>dns.list().nodes.filter(n=>keys()[n.id]),origin}={}){
 async function catalog(){const s=await native('/admin/network-settings.json'),ib=await native('/admin/inbounds'),who=await native('/admin/whoami');const allowed=who.selling||{};
 const nativeOptions=FLAGS.filter(f=>f!=='smartDnsVip'||owner).map(f=>({id:f,label:{awg:'AmneziaWG',mtproto:'Telegram MTProto',mieru:'mieru',soar:'SOAR',tgweb:'Telegram Web',smartDns:'Nova Smart DNS',smartDnsVip:'Nova Smart DNS VIP'}[f],available:s[f==='smartDnsVip'?'smartDns':f]?.enabled===true&& (owner||allowed[{awg:'allowAwg',mtproto:'allowMtproto',mieru:'allowMieru',soar:'allowSoar',tgweb:'allowTgweb',smartDns:'allowSmartDns'}[f]]===true)}));
 return{native:nativeOptions,inbounds:(ib.inbounds||[]).filter(i=>i.enabled!==false).map(i=>({id:i.id,label:(i.remark||i.tag||i.id)+' · '+i.protocol})),openvpn:owner?openvpn.servers().filter(s=>s.enabled).map(s=>({id:s.id,label:s.name||s.id})):[],dns:owner?dnsNodes().map(n=>({id:n.id,label:n.domain||n.host})):[],owner};}
 async function validate(v){v=spec(v);if(!v)return null;const c=await catalog();if(v.kind==='nova'){if(v.grants.some(g=>!c.native.some(x=>x.id===g&&x.available))||v.inboundIds.some(id=>!c.inbounds.some(i=>i.id===id)))throw fail('BOT_SERVICE_UNAVAILABLE',409);}else if(!owner||!(v.kind==='openvpn'?c.openvpn:c.dns).some(x=>x.id===v[v.kind==='openvpn'?'serverId':'nodeId']))throw fail('BOT_SERVICE_UNAVAILABLE',409);return v;}
 async function webOrigin(){return origin?await origin():publicOrigin(await native('/admin/network-settings.json'));}
 async function provision(entry,c,persist=()=>{}){const v=await validate(entry.service);if(v.kind==='nova')return v;
 if(v.kind==='openvpn'){
  const current=entry.providerId&&openvpn.users().find(u=>u.id===entry.providerId),named=openvpn.users().find(u=>u.username===entry.providerName);
  if(!current&&named&&!entry.pending)throw fail('BOT_SERVICE_NAME_CONFLICT',409);
  const existing=current||named;const result=await openvpn.saveUser({username:entry.providerName,password:existing?'':unseal(entry.passwordSeal,'bot-service').password,serverIds:[v.serverId],enabled:c.enable!==false,expiry:Number(c.expiryTime)?new Date(Number(c.expiryTime)).toISOString():'',quotaGB:Number(c.totalGB||0)/1e9,devices:Number(c.limitIp)||1},existing?.id);entry.providerId=result.id;return v;
 }
 let old=entry.providerId?await dnsCall(v.nodeId,'/api/v2/clients/'+encodeURIComponent(entry.providerId)):null;
 if(!old){let cursor='0';for(let page=0;page<200;page++){const list=await dnsCall(v.nodeId,'/api/v2/clients?limit=200&cursor='+encodeURIComponent(cursor));const found=(list.items||[]).find(x=>x.display_name===entry.providerName);if(found){old=found;entry.providerId=found.id;break;}if(!list.next_cursor)break;cursor=list.next_cursor;if(page===199)throw fail('BOT_DNS_RECONCILE_LIMIT',409);}}
 if(!old){if(entry.createSentAt)throw fail('BOT_DNS_CREATION_UNCERTAIN_CHECK_DESTINATION',409);entry.createSentAt=Date.now();persist();const expiry=Number(c.expiryTime||0),days=expiry?Math.ceil((expiry-Date.now())/86400000):0;if(expiry&&days<=0)throw fail('BOT_SERVICE_EXPIRED');old=await dnsCall(v.nodeId,'/api/v2/clients','POST',{display_name:entry.providerName,validity_days:days,quota_limit_gb:Number(c.totalGB||0)/1e9,quota_reset_cycle:'',note:'alirezaserver bot '+entry.providerName});entry.providerId=old.id;persist();}if(c.enable===false)await dnsCall(v.nodeId,'/api/v2/clients/'+encodeURIComponent(entry.providerId),'PATCH',{enabled:false});
 if(!entry.providerId||!old.token)throw fail('BOT_DNS_INVALID_RESPONSE',502);return v;
 }
 async function connection(entry,c){const v=spec(entry.service),base=await webOrigin();if(v.kind==='openvpn'){const u=openvpn.users().find(u=>u.id===entry.providerId);if(!u)throw fail('BOT_ACCOUNT_NOT_FOUND',404);const share=openvpn.shareInfo(u.id);if(!share.token)throw fail('BOT_SUBSCRIPTION_REVOKED',409);return{client:{...c,id:entry.uuid,enable:u.enabled,totalGB:u.quota,expiryTime:u.expiry*1000,limitIp:u.devices},configs:[base+'/alireza-sub/'+share.token+'/'],subscriptionUrl:base+'/alireza-sub/'+share.token+'/',service:v.kind,serviceSpec:v};}
 const n=dns.node(v.nodeId),u=await dnsCall(v.nodeId,'/api/v2/clients/'+encodeURIComponent(entry.providerId));if(!u.token)throw fail('BOT_DNS_INVALID_RESPONSE',502);const url='https://'+n.domain+':'+n.port+'/sub/'+encodeURIComponent(u.token);return{client:{...c,id:entry.uuid,enable:u.enabled!==false,totalGB:Number(u.quota_limit_gb||0)*1e9,expiryTime:u.expires_at?Date.parse(u.expires_at):0},configs:[url],subscriptionUrl:url,service:v.kind,serviceSpec:v};}
 async function operation(entry,op,c={}){const v=spec(entry.service);if(!owner)throw fail('BOT_SERVICE_FORBIDDEN',403);
 if(v.kind==='openvpn'){const u=openvpn.users().find(u=>u.id===entry.providerId);if(!u)throw fail('BOT_ACCOUNT_NOT_FOUND',404);if(op==='del')return openvpn.removeUser(u.id);if(op==='resetTraffic')return openvpn.resetUsage(u.id);if(op==='traffic'){const seen=openvpn.database().prepare('SELECT MAX(seen) AS last FROM sessions WHERE name=?').get(u.username)?.last||0;return{up:0,down:u.used,lastOnline:Number(seen)*1000,trafficDirectionUnavailable:true};}if(op==='update'){if(c.id||c.subId)openvpn.rotateShare(u.id);await openvpn.saveUser({username:u.username,password:'',serverIds:u.serverIds,enabled:c.enable===undefined?u.enabled:c.enable,expiry:c.expiryTime===undefined?(u.expiry?new Date(u.expiry*1000).toISOString():''):(c.expiryTime?new Date(c.expiryTime).toISOString():''),quotaGB:Number(c.totalGB??u.quota)/1e9,devices:Number(c.limitIp??u.devices)||1},u.id);return;}return;}
 const r='/api/v2/clients/'+encodeURIComponent(entry.providerId);if(op==='del')return dnsCall(v.nodeId,r,'DELETE');if(op==='resetTraffic')return dnsCall(v.nodeId,r+'/actions/reset-traffic','POST',{});if(op==='traffic'){const u=await dnsCall(v.nodeId,'/api/v1/clients/'+encodeURIComponent(entry.providerId));if(!Number.isFinite(u.traffic_used_bytes))throw fail('BOT_TRAFFIC_NOT_AVAILABLE',503);return{up:0,down:u.traffic_used_bytes,lastOnline:0,onlineUnavailable:true,trafficDirectionUnavailable:true};}
 if(op==='update'){if(c.id||c.subId)await dnsCall(v.nodeId,r+'/actions/regenerate-uuid','POST',{});const body={};if(c.enable!==undefined)body.enabled=!!c.enable;if(c.totalGB!==undefined)body.quota_limit_gb=Number(c.totalGB)/1e9;if(c.expiryTime!==undefined){const old=await dnsCall(v.nodeId,r);const current=old.expires_at?Date.parse(old.expires_at):0;if(Number(c.expiryTime)===current){}else {if(!c.expiryTime||!Number.isFinite(current)||!current)throw fail('BOT_DNS_EXPIRY_CHANGE_NOT_SUPPORTED',409);const days=Math.round((Number(c.expiryTime)-current)/86400000);if(days<0||Math.abs(Number(c.expiryTime)-current-days*86400000)>60000)throw fail('BOT_DNS_EXPIRY_CHANGE_NOT_SUPPORTED',409);if(days)body.validity_days_add=days;}}return dnsCall(v.nodeId,r,'PATCH',body);}
 }
 return{catalog,validate,provision,connection,operation};
}
