#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Pinned bootstrap; thereafter a restricted key forwards loopback HTTP in both directions.
No shell password arguments; no public PHP/management port; existing bot data retained.
"""
import base64,hashlib,io,ipaddress,json,os,pathlib,re,secrets,shlex,socket,subprocess,sys,time
import paramiko
HERE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path(os.environ.get('ALIREZA_ROOT','/var/lib/alirezaserver'))
REMOTE='/opt/alirezaserver-remote-bot'
FILES=['bot-manager.py','bot_schema.py','bot-schema-tool.php','bot-product-schema.php','runtime-upgrade.py','reference-versions.json','alirezabot-source.tar.b64','bot-remote-gateway.py']
def known_name(host,port):return host if port==22 else '['+host+']:'+str(port)
def connect(v):
 host=str(v.get('host','')).strip()
 if not re.fullmatch(r'[A-Za-z0-9.-]{1,253}',host):raise RuntimeError('BOT_REMOTE_HOST_INVALID')
 ips=socket.getaddrinfo(host,None,socket.AF_INET,socket.SOCK_STREAM);address=ipaddress.ip_address(ips[0][4][0])
 if not address.is_global:raise RuntimeError('BOT_REMOTE_PUBLIC_IPV4_REQUIRED')
 port=int(v.get('sshPort',22));user=str(v.get('username','root'))
 if not 1<=port<=65535 or not re.fullmatch(r'[a-z_][a-z0-9_-]{0,31}',user):raise RuntimeError('BOT_REMOTE_SSH_INVALID')
 sock=socket.create_connection((str(address),port),15);t=paramiko.Transport(sock);t.start_client(timeout=20)
 key=t.get_remote_server_key();fp='SHA256:'+base64.b64encode(hashlib.sha256(key.asbytes()).digest()).decode().rstrip('=')
 if v.get('operation')=='probe':t.close();sock.close();return {'host':str(address),'sshPort':port,'fingerprint':fp,'keyType':key.get_name()}
 if not secrets.compare_digest(fp,str(v.get('fingerprint',''))):t.close();raise RuntimeError('BOT_REMOTE_FINGERPRINT_CHANGED')
 if v.get('privateKey'):
  if len(v['privateKey'])>32768:raise RuntimeError('BOT_REMOTE_KEY_TOO_LARGE')
  parsed=None
  for kind in [paramiko.Ed25519Key,paramiko.ECDSAKey,paramiko.RSAKey]:
   try:parsed=kind.from_private_key(io.StringIO(v['privateKey']),password=v.get('passphrase') or None);break
   except (paramiko.SSHException,ValueError):pass
  if not parsed:raise RuntimeError('BOT_REMOTE_KEY_INVALID')
  t.auth_publickey(user,parsed)
 else:
  if len(str(v.get('password','')))>4096:raise RuntimeError('BOT_REMOTE_PASSWORD_INVALID')
  t.auth_password(user,v.get('password',''))
 return t,sock,key,str(address),port,user

def main(v):
 if v.get('operation')=='repair-tunnel':
  subprocess.run(['systemctl','restart','alirezabot-remote-tunnel.service'],check=True,capture_output=True,timeout=30);return {'ok':True}
 result=connect(v)
 if isinstance(result,dict):return result
 t,sock,key,host,port,user=result
 def command(cmd,data=None,timeout=2100,progress=False):
  channel=t.open_session(timeout=20);channel.exec_command(('' if user=='root' else 'sudo -n ')+cmd)
  if data is not None:channel.sendall(json.dumps(data).encode())
  channel.shutdown_write();out=bytearray();deadline=time.monotonic()+timeout;last=0
  try:
   while not channel.exit_status_ready() or channel.recv_ready() or channel.recv_stderr_ready():
    if time.monotonic()>deadline:raise RuntimeError('BOT_REMOTE_TIMEOUT')
    if channel.recv_ready():out.extend(channel.recv(65536))
    if channel.recv_stderr_ready():channel.recv_stderr(65536)
    if len(out)>131072:raise RuntimeError('BOT_REMOTE_RESPONSE_TOO_LARGE')
    if progress and time.monotonic()-last>5:
     last=time.monotonic()
     # Public progress only; never copy credentials or arbitrary remote output.
     try:
      probe=t.open_session(timeout=3);probe.exec_command(('' if user=='root' else 'sudo -n ')+'cat /var/lib/alirezaserver/bot-phase.json');p=json.loads(probe.makefile('rb').read(4096));probe.close()
      if p.get('id')==v.get('jobId') and re.fullmatch(r'[a-z-]{1,30}',p.get('stage','')):
       (ROOT/'bot-phase.json').write_text(json.dumps({k:p[k] for k in ['id','stage','step']}));os.chmod(ROOT/'bot-phase.json',0o600)
     except Exception:pass
    time.sleep(.05)
   if channel.recv_exit_status()!=0:
    try:err=json.loads(out.decode()).get('error','')
    except (ValueError,UnicodeError):err=''
    raise RuntimeError(err if re.fullmatch(r'[A-Z][A-Z0-9_:.-]{0,120}',err) else 'BOT_REMOTE_COMMAND_FAILED')
   return out.decode()
  finally:channel.close()
 try:
  if command('id -u',timeout=20).strip()!='0':raise RuntimeError('BOT_REMOTE_ROOT_OR_PASSWORDLESS_SUDO_REQUIRED')
  command("sh -c 'command -v python3 >/dev/null || { apt-get update && apt-get install -y python3; }'",timeout=600)
  machine=command('cat /etc/machine-id',timeout=20).strip()
  if machine and machine==pathlib.Path('/etc/machine-id').read_text().strip():raise RuntimeError('BOT_REMOTE_IS_THIS_SERVER_USE_LOCAL')
  if v.get('operation')=='verify-token':
   if not re.fullmatch(r'\d{5,16}:[A-Za-z0-9_-]{20,100}',str(v.get('token',''))):raise RuntimeError('BOT_INVALID_CREDENTIALS')
   verify="import json,sys,urllib.request;v=json.load(sys.stdin);r=json.load(urllib.request.urlopen('https://api.telegram.org/bot'+v['token']+'/getMe',timeout=15));print(json.dumps({'username':r.get('result',{}).get('username','')}))"
   checked=json.loads(command('python3 -c '+shlex.quote(verify),{'token':v['token']},timeout=30))
   if not re.fullmatch(r'[A-Za-z0-9_]{1,64}',checked.get('username','')):raise RuntimeError('BOT_REMOTE_TOKEN_DENIED')
   return checked
  ROOT.mkdir(parents=True,exist_ok=True,mode=0o700)
  old=json.loads((ROOT/'bot-remote.json').read_text()) if (ROOT/'bot-remote.json').exists() else None
  if old and (old['host']!=host or old['sshPort']!=port or old['username']!=user):raise RuntimeError('BOT_REMOTE_DESTINATION_CHANGE_REQUIRES_MIGRATION')
  identity=ROOT/'bot-remote-key'
  if not identity.exists():subprocess.run(['ssh-keygen','-q','-t','ed25519','-N','','-f',str(identity)],check=True,capture_output=True,timeout=20)
  pub=identity.with_suffix('.pub').read_text().split();public=' '.join(pub[:2]);known=ROOT/'bot-remote-known-hosts';known.write_text(known_name(host,port)+' '+key.get_name()+' '+key.get_base64()+'\n');known.chmod(0o600)
  def freeport():
   with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
  localPort=old['localPort'] if old else freeport()
  config={**(old or {}),'host':host,'sshPort':port,'username':user,'localPort':localPort,'gatewayToken':(old or {}).get('gatewayToken') or secrets.token_hex(32)}
  temp='/tmp/alirezabot-stage-'+secrets.token_hex(12);sftp=paramiko.SFTPClient.from_transport(t);sftp.mkdir(temp,0o700)
  try:
   for name in FILES:sftp.put(str(HERE/name),temp+'/'+name);sftp.chmod(temp+'/'+name,0o600)
   bootstrap=r'''
import pathlib,os,json,socket,shutil,pwd,subprocess,sys
v=json.load(sys.stdin)
release=pathlib.Path('/etc/os-release').read_text()
if not any(x in release for x in ['ID=debian','ID=ubuntu','ID=\"ubuntu\"','ID=\"debian\"']):raise SystemExit(6)
stage=pathlib.Path(v['stage']);target=pathlib.Path('/opt/alirezaserver-remote-bot')
if target.is_symlink() or (target.exists() and not (target/'.managed').exists()):raise SystemExit(2)
if pathlib.Path('/var/lib/alirezaserver/installed.json').exists():raise SystemExit(3)
marker=target/'.managed'
if marker.exists() and marker.read_text().strip()!=v['public']:raise SystemExit(5)
target.mkdir(mode=0o700,exist_ok=True);marker.write_text(v['public']+'\n')
for p in stage.iterdir():shutil.copyfile(p,target/p.name);os.chmod(target/p.name,0o600)
def free():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
f=target/'remote-gateway.json';old=json.loads(f.read_text()) if f.exists() else {}
c={'port':old.get('port') or free(),'apiPort':old.get('apiPort') or free(),'token':v['token']}
while c['port']==c['apiPort']:c['apiPort']=free()
f.write_text(json.dumps(c));f.chmod(0o600)
u=pwd.getpwnam(v['username']);ssh=pathlib.Path(u.pw_dir)/'.ssh';ssh.mkdir(mode=0o700,exist_ok=True)
if ssh.is_symlink():raise SystemExit(4)
os.chown(ssh,u.pw_uid,u.pw_gid);auth=ssh/'authorized_keys'
if auth.is_symlink():raise SystemExit(4)
old=auth.read_text() if auth.exists() else ''
line='restrict,port-forwarding,command="/bin/false",permitopen="127.0.0.1:'+str(c['port'])+'",permitlisten="127.0.0.1:'+str(c['apiPort'])+'" '+v['public']+' alirezaserver-remote-bot'
lines=[x for x in old.splitlines() if not x.endswith(' alirezaserver-remote-bot')];lines.append(line);auth.write_text('\n'.join(lines)+'\n');auth.chmod(0o600);os.chown(auth,u.pw_uid,u.pw_gid)
print(json.dumps(c))
'''
   # Fixed bootstrap code is passed with shlex quoting; secrets are stdin JSON only.
   r=json.loads(command('python3 -c '+shlex.quote(bootstrap),{'stage':temp,'token':config['gatewayToken'],'username':user,'public':public}));config.update(remotePort=r['port'],apiPort=r['apiPort'])
   context=dict(v['context']);context['bridgeURL']=re.sub(r'^http://127\.0\.0\.1:\d+', 'http://127.0.0.1:'+str(r['apiPort']),context['bridgeURL'])
   if not context['bridgeURL'].startswith('http://127.0.0.1:'):raise RuntimeError('BOT_REMOTE_BRIDGE_INVALID')
   mainPort=int(v['context']['bridgeURL'].split(':',2)[2].split('/')[0])
   command('/usr/bin/true',timeout=10)
   # No firewall, public listener, TLS or Nova service is modified on either machine.
   unit='''[Unit]\nDescription=Alirezabot pinned remote SSH transport\nAfter=network-online.target\nWants=network-online.target\n[Service]\nType=simple\nExecStart=/usr/bin/ssh -N -T -F /dev/null -o IdentitiesOnly=yes -o ForwardAgent=no -o LogLevel=ERROR -o BatchMode=yes -o ExitOnForwardFailure=yes -o StrictHostKeyChecking=yes -o UserKnownHostsFile=KNOWN -o ServerAliveInterval=20 -o ServerAliveCountMax=3 -o ConnectTimeout=15 -i KEY -p PORT -L 127.0.0.1:LOCAL:127.0.0.1:REMOTE -R 127.0.0.1:API:127.0.0.1:MAIN USER@HOST\nRestart=always\nRestartSec=5\nUMask=0077\nNoNewPrivileges=true\n[Install]\nWantedBy=multi-user.target\n'''
   replacements={'KNOWN':str(known),'KEY':str(identity),'PORT':str(port),'LOCAL':str(localPort),'REMOTE':str(r['port']),'API':str(r['apiPort']),'MAIN':str(mainPort),'USER':user,'HOST':host}
   for k,val in replacements.items():unit=unit.replace(k,val)
   if not all(re.fullmatch(r'[A-Za-z0-9/_.:@-]+',x) for x in replacements.values()):raise RuntimeError('BOT_REMOTE_SYSTEMD_ARGUMENT_INVALID')
   pathlib.Path('/etc/systemd/system/alirezabot-remote-tunnel.service').write_text(unit);subprocess.run(['systemctl','daemon-reload'],check=True,capture_output=True,timeout=20);subprocess.run(['systemctl','enable','--now','alirezabot-remote-tunnel.service'],check=True,capture_output=True,timeout=30);subprocess.run(['systemctl','restart','alirezabot-remote-tunnel.service'],check=True,capture_output=True,timeout=30)
   cfg=ROOT/'bot-remote.json';pending=cfg.with_suffix('.new');pending.write_text(json.dumps(config));pending.chmod(0o600);pending.replace(cfg)
   inputs={**v['install'],**context,'operation':'install','jobId':v.get('jobId')};response=json.loads(command('python3 '+REMOTE+'/bot-manager.py',inputs,progress=True))
   if response.get('error'):raise RuntimeError(response['error'])
   gateway='''[Unit]\nDescription=Alirezabot private remote gateway\nAfter=network-online.target alirezabot-php.service\n[Service]\nExecStart=/usr/bin/python3 /opt/alirezaserver-remote-bot/bot-remote-gateway.py\nRestart=on-failure\nRestartSec=5\nUMask=0077\nPrivateTmp=true\nNoNewPrivileges=true\nProtectHome=true\n[Install]\nWantedBy=multi-user.target\n'''
   activate="import pathlib,subprocess,json,sys;v=json.load(sys.stdin);pathlib.Path('/etc/systemd/system/alirezabot-remote-gateway.service').write_text(v['unit']);subprocess.run(['systemctl','daemon-reload'],check=True);subprocess.run(['systemctl','enable','--now','alirezabot-remote-gateway.service'],check=True);subprocess.run(['systemctl','restart','alirezabot-remote-gateway.service'],check=True);print('{}')"
   command('python3 -c '+shlex.quote(activate),{'unit':gateway},timeout=30)
   for _ in range(30):
    try:
     import urllib.request
     req=urllib.request.Request('http://127.0.0.1:'+str(localPort)+'/_manage',data=b'{"operation":"status"}',headers={'X-AZ-Gateway':config['gatewayToken'],'Content-Type':'application/json'})
     with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=10) as answer:health=json.load(answer)
     if health.get('running'):return health
    except Exception:pass
    time.sleep(1)
   raise RuntimeError('BOT_REMOTE_TUNNEL_OR_SERVICES_NOT_READY')
  finally:
   for name in FILES:
    try:sftp.remove(temp+'/'+name)
    except OSError:pass
   try:sftp.rmdir(temp)
   except OSError:pass
   sftp.close()
 finally:t.close();sock.close()
if __name__=='__main__':
 try:print(json.dumps(main(json.loads(sys.stdin.read(196609)))))
 except paramiko.AuthenticationException:print(json.dumps({'error':'BOT_REMOTE_AUTHENTICATION_FAILED'}));sys.exit(1)
 except Exception as e:print(json.dumps({'error':str(e) if isinstance(e,RuntimeError) else 'BOT_REMOTE_'+type(e).__name__.upper()}));sys.exit(1)
