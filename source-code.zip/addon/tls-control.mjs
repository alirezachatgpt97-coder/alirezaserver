// Root CLI/installer bridge to native domain jobs: keep native snapshots and rollback.
import fs from 'node:fs';import {execFile} from 'node:child_process';import {promisify} from 'node:util';import {isIP} from 'node:net';import {originAddress,recordTLSFailure} from './tls-coordinator.mjs';import {publicInstance,instanceID} from './site-address.mjs';import {nativeClient} from './native-client.mjs';
if(process.getuid?.()!==0)throw Error('ROOT_REQUIRED');
const env=Object.fromEntries(fs.readFileSync('/etc/nova/agent.env','utf8').split('\n').filter(l=>/^[A-Z_]+=/.test(l)).map(l=>{const i=l.indexOf('=');return[l.slice(0,i),l.slice(i+1).replace(/^['"]|['"]$/g,'')];}));
process.env.NOVA_DB=env.NOVA_DB||process.env.NOVA_DB||'/var/lib/nova/nova.db';
// Discover the hidden path from the authoritative local settings, never from input URLs.
const {openKv}=await import('file:///opt/nova-node-agent/src/kv/sqlite.mjs');const kv=openKv(process.env.NOVA_DB);const settings=JSON.parse(await kv.get('network-settings.json')||'{}');kv.close();
const base=settings.panelPath?'/'+settings.panelPath.replace(/^\/+|\/+$/g,''):'',api=nativeClient(Number(env.NOVA_PORT||8088),base);
async function syncBot(){try{await api('/alireza/api/bot/sync','POST',{});}catch(e){console.log('Bot local synchronization warning: '+e.message);}}
async function checkPublic(host){await publicInstance(host,Number(env.NOVA_FRONT_PORT||443),base,instanceID());console.log('Public HTTPS / CA / this Nova instance: verified');await syncBot();}
let value='';for await(const b of process.stdin)value+=b;if(value.length>8192)throw Error('TLS_INPUT_TOO_LARGE');const input=value?JSON.parse(value):{operation:'auto'};
try{
 if(!['status','auto','issue','verify'].includes(input.operation))throw Error('TLS_INVALID_OPERATION');
 if(input.operation==='verify'){const s=await api('/admin/domain');if(!s.cert?.ok||s.cert.selfSigned)throw Error('TLS_TRUSTED_CERTIFICATE_REQUIRED');await checkPublic(s.host);console.log('Trusted certificate verified for '+s.host);}
 else if(input.operation==='status'){console.log(JSON.stringify(await api('/admin/domain')));}
 else{
  const origin=originAddress(settings);if(!settings.directHost&&origin){await api('/admin/network-settings.json','POST',{directHost:origin});}
  const status=await api('/admin/domain');let host=String(input.host||settings.host||'').replace(/^\[|\]$/g,'');
  if(input.operation==='auto'){
   const pending='/var/lib/alirezaserver/requested-domain';if(fs.existsSync(pending)){const wanted=fs.readFileSync(pending,'utf8').trim();if(wanted)host=wanted;}
   if(status.host===host&&status.cert?.ok&&!status.cert.selfSigned&&status.cert.expiresAt>Date.now()+172800000){await checkPublic(status.host);console.log('Trusted TLS already active.');process.exit(0);}
  }
  if(!host)throw Error('TLS_HOST_MISSING: choose a public IP or domain with alireza tls');
  if(input.token){await api('/admin/cloudflare','POST',{token:input.token});}
  if(isIP(host))await promisify(execFile)('python3',['/opt/alirezaserver/tls-runtime.py'],{timeout:600000,maxBuffer:1048576});
  let email=input.email||'';if(!email)try{email=fs.readFileSync('/var/lib/alirezaserver/requested-email','utf8').trim();}catch{}
  const method=input.method||'letsencrypt';
  await api('/admin/domain','POST',{domain:host,method,email,proxied:input.proxied===true});
  let done=false;
  for(let i=0;i<180;i++){await new Promise(r=>setTimeout(r,2000));const s=await api('/admin/domain');if(s.state==='active'){if(!s.cert?.ok||s.cert.selfSigned)throw Error('TLS_CERTIFICATE_NOT_TRUSTED');await checkPublic(s.host);console.log('Trusted TLS active for '+s.host);done=true;break;}if(s.state==='error')throw Error(s.error||'TLS_ISSUANCE_FAILED');if(i%15===0)console.log('Certificate request running ('+(i*2)+'s).');}
  if(!done)throw Error('TLS_JOB_STILL_RUNNING: use alireza tls-status; do not request repeatedly');
 }
}catch(e){recordTLSFailure(e,{host:input.host||settings.host,token:input.token});console.error('TLS: '+e.message);process.exitCode=1;}finally{process.exit(process.exitCode||0);}
