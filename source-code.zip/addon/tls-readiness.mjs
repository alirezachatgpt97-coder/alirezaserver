// SPDX-License-Identifier: GPL-3.0-or-later
// Type=simple being active does not mean its authenticated HTTP API is ready.
import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import {randomBytes} from 'node:crypto';
export async function waitTLSAPI(api,{attempts=40,interval=500,delay=ms=>new Promise(r=>setTimeout(r,ms))}={}){
 let last;for(let n=0;n<attempts;n++){try{const s=await api('/admin/domain');if(s&&s.host&&s.cert)return s;last=Error('TLS_API_NOT_READY');}catch(e){if(e.status>=400&&e.status<500&&![408,429].includes(e.status))throw e;last=e;}if(n+1<attempts)await delay(interval);}throw last||Error('TLS_API_NOT_READY');
}
export async function probeHTTPChallenge(root,{port=80,attempts=20,interval=500}={}){
 const token=randomBytes(24).toString('hex'),value=randomBytes(24).toString('hex'),dir=path.join(root,'.well-known/acme-challenge'),file=path.join(dir,token);
 fs.mkdirSync(dir,{recursive:true,mode:0o755});for(let p=path.resolve(dir);p!=='/';p=path.dirname(p))if(fs.lstatSync(p).isSymbolicLink())throw Error('TLS_UNSAFE_WEBROOT');
 fs.writeFileSync(file,value,{mode:0o644,flag:'wx'});
 try{for(let n=0;n<attempts;n++){const ok=await new Promise(resolve=>{const r=http.get({host:'127.0.0.1',port,path:'/.well-known/acme-challenge/'+token,timeout:1500},res=>{let data='';res.on('data',b=>{data+=b;if(data.length>256)r.destroy();});res.on('end',()=>resolve(res.statusCode===200&&data===value));res.on('error',()=>resolve(false));});r.on('timeout',()=>r.destroy());r.on('error',()=>resolve(false));});if(ok)return true;if(n+1<attempts)await new Promise(r=>setTimeout(r,interval));}throw Error('TLS_HTTP01_LOCAL_HANDLER_NOT_READY');}finally{fs.rmSync(file,{force:true});}
}
