/* SPDX-License-Identifier: GPL-3.0-or-later */
(()=>{'use strict';if(typeof viewInbounds!=='function')return;const U=window.AlirezaUI;
 function decorate(section){if(!U||typeof isOwner!=='function'||!isOwner()||section.querySelector('[data-az-manual]'))return section;const header=section.querySelector('.view-head');if(!header)return section;header.style.flexWrap='wrap';const b=document.createElement('button');b.type='button';b.className='btn primary';b.dataset.azManual='';b.textContent=U.tr('＋ ساخت دستی اینباند','＋ Create inbound manually');b.onclick=()=>window.alirezaInboundEditor('vless',section);header.append(b);if(!(typeof isPaas==='function'&&isPaas()))window.AlirezaOpenVPN?.attach(section);return section;}
 const original=viewInbounds;viewInbounds=function(...args){return decorate(original.apply(this,args));};const section=document.querySelector('#inb-add')?.closest('section.view');if(section)decorate(section);
})();
