import * as bulk from './inbound-bulk.mjs';
import * as panels from './panel-account.mjs';
// SPDX-License-Identifier: GPL-3.0-or-later
import * as shop from './shop.mjs';import {telegram} from './shop-worker.mjs';
export async function shopAPI(auth,operation,input,context){const owner=shop.ownerOf(auth),native=context.native(owner);
 if(operation==='catalog')return shop.catalog(owner,native);
 if(operation==='config')return shop.config(owner);
 if(operation==='configure')return shop.configure(owner,input,{telegram,mainToken:context.mainToken});
 if(operation==='plans')return{items:shop.plans(owner,{offset:input.offset||0})};
 if(operation==='save-plan')return shop.savePlan(owner,input,native);
 if(operation==='archive-plan')return shop.archive(owner,input.id);
 if(operation==='orders')return{items:shop.orders(owner,undefined,input.offset||0)};
 if(operation==='credits')return{items:shop.credits(owner,input.offset||0)};
 if(operation==='approve-credit'||operation==='reject-credit')return shop.decideCredit(owner,input.id,operation==='approve-credit');
 if(operation==='credentials'){const r={...shop.findOrder(owner,input.id),id:input.id};if(!r)throw Object.assign(Error('SHOP_ORDER_NOT_FOUND'),{status:404});return shop.order(owner,r.buyer,input.id,{credentials:true});}
 if(operation==='cancel'){const r={...shop.findOrder(owner,input.id),id:input.id};if(r.data.externalPaid)throw Object.assign(Error('SHOP_USE_MAIN_BOT_REFUND'),{status:409});return shop.cancel(owner,input.id,native);}
 if(operation==='retry'){const r={...shop.findOrder(owner,input.id),id:input.id};if(!r)throw Object.assign(Error('SHOP_ORDER_NOT_FOUND'),{status:404});if(r.data.externalPaid&&r.status==='awaiting_payment')throw Object.assign(Error('SHOP_PAYMENT_REQUIRED'),{status:409});shop.database().prepare("UPDATE orders SET lease=0 WHERE id=? AND owner=? AND status='review'").run(r.id,owner);return shop.purchase(owner,r.buyer,r.id,native,{externalPaid:r.data.externalPaid,panelURL:await context.panelURL()});}
 throw Object.assign(Error('SHOP_ROUTE_NOT_FOUND'),{status:404});}
export async function rootBotShop(operation,input,context){const native=context.native('owner');
 if(operation==='bulk-catalog')return bulk.catalog(input,native);
 if(operation==='bulk-preview')return bulk.preview(input,native);
 if(operation==='bulk-status')return bulk.status(input.id,{offset:input.offset||0,filter:input.filter||'all'});
 if(operation==='bulk-list')return bulk.list();
 if(operation==='bulk-control')return bulk.control(input.id,input.action);
 if(operation==='bulk-undo')return bulk.undo(input.id,native);
 if(operation==='my-panels')return{items:panels.list(input.buyer,input.offset||0)};
 if(operation==='panel-info')return panels.info(input.buyer,input.id,context,{credentials:input.credentials===true});
 if(operation==='panel-password')return panels.rotate(input.buyer,input.id,context);
 if(operation==='catalog')return shop.catalog('owner',native);
 if(operation==='plans')return{items:shop.plans('owner',{active:input.active===true,kind:'admin',offset:input.offset||0,limit:input.limit||100}).filter(p=>p.kind==='admin')};
 if(operation==='plan')return shop.findPlan('owner',input.id);
 if(operation==='save-plan')return shop.savePlan('owner',{...input,kind:'admin'},native);
 if(operation==='archive-plan')return shop.archive('owner',input.id);
 if(operation==='quote'){const q=shop.quote('owner',input.buyer,input.plan,input.units);if(q.plan.kind!=='admin')throw Error('SHOP_ADMIN_PLAN_REQUIRED');await shop.validateGrant(q.plan);return q;}
 if(operation==='quote-info'){const q=shop.getQuote('owner',input.buyer,input.id);await shop.validateGrant(q.plan);return q;}
 if(operation==='reserve')return shop.reserveExternal('owner',input.buyer,input.id);
 if(operation==='purchase')return shop.purchase('owner',input.buyer,input.id,native,{externalPaid:true,panelURL:await context.panelURL()});
 if(operation==='orders')return{items:shop.orders('owner',undefined,input.offset||0)};
 if(operation==='order')return shop.order('owner',input.buyer,input.id,{credentials:true});
 if(operation==='cancel')return shop.cancel('owner',input.id,native);
 throw Object.assign(Error('SHOP_ROUTE_NOT_FOUND'),{status:404});}
