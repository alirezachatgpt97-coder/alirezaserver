// SPDX-License-Identifier: GPL-3.0-or-later
// The dial address and the certificate identity are separate. Never weaken TLS.
import {isIP} from 'node:net';
const bare=v=>String(v||'').replace(/^\[|\]$/g,'').toLowerCase();
export function endpointIdentity(i,h={},o={}){
 h||={};const host=bare(o.host),origin=bare(o.directHost);
 if(!host||isIP(host)||!origin||host===origin||i.nodeId&&i.nodeId!=='local'||i.pubAddr||i.sni||h.address||h.server||h.sni||h.overrideSniFromAddress||h.keepSniBlank||h.security&& !['same','tls'].includes(h.security))return null;
 if(!['vless','vmess','trojan'].includes(i.protocol)||i.security!=='tls')return null;
 const stream=i.raw?.streamSettings;
 if(stream?.tlsSettings?.serverName)return null;
 const certs=stream?.tlsSettings?.certificates||[];
 if(certs.some(c=>c.certificate?.length||c.certificateFile&&c.certificateFile!==(process.env.NOVA_CERT_PEM||'/etc/nova/origin.pem')))return null;
 const proxied=o.proxiedNames instanceof Set?o.proxiedNames.has(host):Array.isArray(o.proxiedNames)&&o.proxiedNames.includes(host);
 return {host,origin,cdn:!!proxied&&(!h.hostHeader||bare(h.hostHeader)===host)&&(!i.host||bare(i.host)===host)&&i.network==='ws'&&[443,2053,2083,2087,2096,8443].includes(Number(h.port||i.port))};
}
export function fixProxy(p,identity){
 if(!identity||bare(p.server)!==identity.origin||p.sni&&bare(p.sni)!==identity.origin)return p;
 return {...p,sni:identity.host,...(identity.cdn?{server:identity.host,wsHost:!p.wsHost||bare(p.wsHost)===identity.origin?identity.host:p.wsHost}:{})};
}
export function fixLink(line,identity){
 if(!identity)return line;
 if(line.startsWith('vmess://')){const v=JSON.parse(Buffer.from(line.slice(8),'base64'));if(bare(v.add)!==identity.origin||v.sni&&bare(v.sni)!==identity.origin)return line;v.sni=identity.host;if(identity.cdn){v.add=identity.host;if(!v.host||bare(v.host)===identity.origin)v.host=identity.host;}return 'vmess://'+Buffer.from(JSON.stringify(v)).toString('base64');}
 let u;try{u=new URL(line);}catch{return line;}
 if(!['vless:','trojan:'].includes(u.protocol)||bare(u.hostname)!==identity.origin||u.searchParams.get('security')!=='tls')return line;
 const sni=u.searchParams.get('sni');if(sni&&bare(sni)!==identity.origin)return line;
 u.searchParams.set('sni',identity.host);if(identity.cdn){u.hostname=identity.host;if(!u.searchParams.has('host')||bare(u.searchParams.get('host'))===identity.origin)u.searchParams.set('host',identity.host);}return u.toString();
}
