// SPDX-License-Identifier: GPL-3.0-or-later
// Exact reviewed profiles or a local receipt issued only after isolated contract tests.
import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
const manifest=()=>JSON.parse(fs.readFileSync(new URL('./compat-profiles.json',import.meta.url)));
export function adapterFingerprint(){const h=createHash('sha256');for(const name of ['compat-profile.mjs','compat-check.mjs','compat-smoke.mjs','host-hooks.mjs','host-core.mjs','tls-core.mjs','tls-coordinator.mjs','xray-access.mjs','endpoint-identity.mjs','bot-bridge.mjs','native-client.mjs','shop-native.mjs','shop.mjs','shop-api.mjs','tenant-bot.mjs','panel-account.mjs','inbound-bulk.mjs']){h.update(name);h.update(fs.readFileSync(new URL('./'+name,import.meta.url)));}return h.digest('hex');}
export function candidateProfile(dir){const files={};for(const name of Object.keys(manifest().profiles[0].files)){const p=path.join(dir,name);if(!fs.existsSync(p))throw Error('NOVA_COMPATIBILITY_REVIEW_REQUIRED: missing '+name);if(!fs.lstatSync(p).isFile())throw Error('NOVA_INVALID_BRIDGE_FILE: '+name);files[name]=createHash('sha256').update(fs.readFileSync(p)).digest('hex');}return{version:JSON.parse(fs.readFileSync(path.join(dir,'package.json'))).version,files};}
export function selectProfile(dir){dir=path.resolve(dir);const actual=candidateProfile(dir),matches=p=>p.version===actual.version&&Object.entries(actual.files).every(([name,digest])=>p.files?.[name]===digest);
 for(const profile of manifest().profiles)if(matches(profile))return profile;
 // This capability exists only in the updater's preflight child. It never writes a receipt.
 if(process.env.ALIREZA_COMPAT_PROBE===dir)return{...actual,provisional:true};
 try{const receipt=JSON.parse(fs.readFileSync(path.join(dir,'.alireza-compat.json')));if(receipt.schema===1&&receipt.adapter===adapterFingerprint()&&matches(receipt))return receipt;}catch(e){if(e.code!=='ENOENT'&&!(e instanceof SyntaxError))throw e;}
 throw Error('NOVA_COMPATIBILITY_REVIEW_REQUIRED: candidate needs isolated compatibility tests; installed panel retained');
}
export function approveCandidate(dir){dir=path.resolve(dir);if(process.env.ALIREZA_COMPAT_PROBE!==dir)throw Error('NOVA_PREFLIGHT_REQUIRED');const receipt={schema:1,...candidateProfile(dir),adapter:adapterFingerprint(),checkedAt:new Date().toISOString()},file=path.join(dir,'.alireza-compat.json'),temp=file+'.tmp';fs.writeFileSync(temp,JSON.stringify(receipt)+'\n',{mode:0o644});fs.chmodSync(temp,0o644);fs.renameSync(temp,file);return receipt;}
