// SPDX-License-Identifier: GPL-3.0-or-later
// Reviewed bridge profiles; never learn/trust hashes from an unreviewed candidate.
import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
export function selectProfile(dir){const manifest=JSON.parse(fs.readFileSync(new URL('./compat-profiles.json',import.meta.url)));const cache=new Map();for(const p of manifest.profiles){if(Object.entries(p.files).every(([name,expected])=>{if(!cache.has(name))try{cache.set(name,createHash('sha256').update(fs.readFileSync(path.join(dir,name))).digest('hex'));}catch{cache.set(name,'missing');}return cache.get(name)===expected;}))return p;}throw Error('NOVA_COMPATIBILITY_REVIEW_REQUIRED: unreviewed bridge files; installed panel retained');}
