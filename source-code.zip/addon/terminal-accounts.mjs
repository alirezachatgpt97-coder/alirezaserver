// On-demand root-only credential helper. JSON input over stdin, never argv.
import {users,accountCredentials,database} from './backend.mjs';
if(process.getuid?.()!==0)throw Error('ROOT_REQUIRED');
let input='';for await(const chunk of process.stdin){input+=chunk;if(input.length>4096)throw Error('INPUT_TOO_LARGE');}
try{const v=JSON.parse(input);if(v.operation==='list')console.log(JSON.stringify(users().map(({id,username,enabled})=>({id,username,enabled}))));else if(v.operation==='credentials')console.log(JSON.stringify(accountCredentials(v.id)));else throw Error('INVALID_OPERATION');}finally{database().close();}
