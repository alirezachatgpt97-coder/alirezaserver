// SPDX-License-Identifier: GPL-3.0-or-later
// Root terminal adapter follows the same stored local/remote destination as the UI.
import {call,isRemote} from './bot.mjs';
let text='';for await(const b of process.stdin){text+=b;if(text.length>131072)throw Error('BODY_TOO_LARGE');}
try{const {operation,...input}=JSON.parse(text);const result=operation==='destination'?{remote:isRemote()}:await call(operation,input);console.log(JSON.stringify(result));}catch(e){console.log(JSON.stringify({error:e.code||'BOT_CONTROL_FAILED'}));process.exitCode=1;}
