#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
import base64,hashlib,io,ipaddress,json,pathlib,re,secrets,socket,sys,time
import paramiko
HERE=pathlib.Path(__file__).resolve().parent

def main(v):
 host=str(v['host']).strip().encode('idna').decode()
 if not re.fullmatch(r'[A-Za-z0-9.-]{1,253}',host) or '..' in host:raise RuntimeError('INVALID_SSH_HOST')
 address=ipaddress.IPv4Address(socket.gethostbyname(host))
 if address.is_loopback or address.is_unspecified or address.is_multicast:raise RuntimeError('REMOTE_UNICAST_IPV4_REQUIRED')
 port=int(v.get('sshPort',22));user=str(v.get('username','root'))
 if not 1<=port<=65535 or not re.fullmatch(r'[a-z_][a-z0-9_-]{0,31}',user):raise RuntimeError('INVALID_SSH_SETTINGS')
 sock=socket.create_connection((str(address),port),15);t=paramiko.Transport(sock)
 try:
  t.start_client(timeout=15);key=t.get_remote_server_key();fp='SHA256:'+base64.b64encode(hashlib.sha256(key.asbytes()).digest()).decode().rstrip('=')
  if v.get('operation')=='probe':return {'fingerprint':fp,'type':key.get_name(),'host':host,'sshPort':port}
  if not secrets.compare_digest(fp,str(v.get('fingerprint',''))):raise RuntimeError('SSH_FINGERPRINT_CHANGED')
  if v.get('privateKey'):
   parsed=None
   for kind in [paramiko.Ed25519Key,paramiko.ECDSAKey,paramiko.RSAKey]:
    try:parsed=kind.from_private_key(io.StringIO(v['privateKey']),password=v.get('passphrase') or None);break
    except (paramiko.SSHException,ValueError):pass
   if parsed is None:raise RuntimeError('SSH_KEY_INVALID')
   t.auth_publickey(user,parsed)
  else:t.auth_password(user,v.get('password',''))
  sudo='' if user=='root' else 'sudo -n '
  def command(cmd,data=None,timeout=900):
   channel=t.open_session(timeout=15);channel.exec_command(sudo+cmd)
   if data is not None:channel.sendall(json.dumps(data).encode())
   channel.shutdown_write();out=bytearray();deadline=time.monotonic()+timeout
   while not channel.exit_status_ready() or channel.recv_ready() or channel.recv_stderr_ready():
    if time.monotonic()>deadline:channel.close();raise RuntimeError('REMOTE_OPERATION_TIMEOUT')
    if channel.recv_ready():out.extend(channel.recv(65536))
    if channel.recv_stderr_ready():channel.recv_stderr(65536)
    if len(out)>1048576:channel.close();raise RuntimeError('REMOTE_RESPONSE_TOO_LARGE')
    time.sleep(.03)
   code=channel.recv_exit_status();channel.close()
   if code:
    try:failure=json.loads(out.decode()).get('error','')
    except (ValueError,UnicodeError):failure=''
    if re.fullmatch(r'[A-Z][A-Z0-9_]*(?::[0-9]+)?',failure):raise RuntimeError('REMOTE_'+failure)
    raise RuntimeError('REMOTE_COMMAND_FAILED')
   return out.decode()
  if command('id -u',timeout=15).strip()!='0':raise RuntimeError('ROOT_OR_PASSWORDLESS_SUDO_REQUIRED')
  if v.get('operation')=='peer-ports':
   result=json.loads(command('python3 /opt/alirezaserver-hashem/adapter/hashem-manager.py',{'operation':'ports','ports':v.get('ports',[])}))
   if result.get('error'):raise RuntimeError(result['error'])
   return result
  arch=command('uname -m',timeout=15).strip();arch={'x86_64':'amd64','aarch64':'arm64'}.get(arch)
  if not arch:raise RuntimeError('REMOTE_ARCHITECTURE_NOT_SUPPORTED')
  remote='/tmp/alireza-hashem-'+secrets.token_hex(16);sftp=paramiko.SFTPClient.from_transport(t);sftp.mkdir(remote,0o700);files=['hashem-manager.py','hashem-source.sh','reference-versions.json','tunnel-downloads.json','hashem-core-build.json','hashem-core-'+arch+'.b64','COPYING.Hashem']
  try:
   for name in files:sftp.put(str(HERE/name),remote+'/'+name);sftp.chmod(remote+'/'+name,0o600)
   install=json.loads(command('python3 '+remote+'/hashem-manager.py',{'operation':'install'}))
   if install.get('error'):raise RuntimeError(install['error'])
   c=dict(v['configuration']);c['operation']='setup';result=json.loads(command('python3 '+remote+'/hashem-manager.py',c))
   if result.get('error'):raise RuntimeError(result['error'])
   return result
  finally:
   for name in files:
    try:sftp.remove(remote+'/'+name)
    except OSError:pass
   try:sftp.rmdir(remote)
   except OSError:pass
   sftp.close()
 finally:t.close();sock.close()
if __name__=='__main__':
 try:print(json.dumps(main(json.loads(sys.stdin.read(131073)))))
 except paramiko.AuthenticationException:print(json.dumps({'error':'SSH_AUTHENTICATION_FAILED'}));sys.exit(1)
 except Exception as e:print(json.dumps({'error':str(e) if isinstance(e,RuntimeError) else type(e).__name__}));sys.exit(1)
