#!/usr/bin/python3
# Consistent SQLite snapshot plus add-on configuration, certificates and data.
# Run alongside Nova's own backup; this archive deliberately does not replace it.
import subprocess, datetime, os, pathlib, sqlite3, tarfile, tempfile, re
if os.geteuid()!=0:raise SystemExit('Run as root.')
out=pathlib.Path('/var/backups/alirezaserver');out.mkdir(parents=True,exist_ok=True,mode=0o700)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
target=out/('alirezaserver-'+stamp+'.tar.gz')
with tempfile.TemporaryDirectory(prefix='alirezaserver-backup-') as temp:
    snapshots=[]
    tenant_paths=[];tenant_dumps=[]
    for app in pathlib.Path('/opt').glob('azb*'):
        if not re.fullmatch(r'azb[a-f0-9]{20}',app.name) or not (app/'.alirezaserver-managed').is_file() or not (app/'.alireza-tenant').is_file():continue
        dump=pathlib.Path(temp)/(app.name+'.sql')
        with dump.open('wb') as target_db:
            result=subprocess.run(['mariadb-dump','--protocol=socket','-u','root','--single-transaction','--routines','--triggers','--events','--databases',app.name],stdout=target_db,stderr=subprocess.PIPE,timeout=180)
        if result.returncode:raise RuntimeError('Tenant bot database backup failed; archive not accepted')
        tenant_dumps.append(dump)
        tenant_paths.extend([app,pathlib.Path('/var/lib')/app.name,pathlib.Path('/etc/logrotate.d')/app.name])
        tenant_paths.extend(pathlib.Path('/etc/systemd/system').glob(app.name+'-*'))
    botdump=None
    if pathlib.Path('/opt/alirezabot/.alirezaserver-managed').exists():
        botdump=pathlib.Path(temp)/'alirezabot.sql'
        with botdump.open('wb') as outdb:
            result=subprocess.run(['mariadb-dump','--protocol=socket','-u','root','--single-transaction','--routines','--triggers','--events','--databases','alirezabot'],stdout=outdb,stderr=subprocess.PIPE,timeout=180)
        if result.returncode:raise RuntimeError('alirezabot database backup failed; archive not accepted')

    snap=pathlib.Path(temp)/'addon.db'
    with sqlite3.connect('/var/lib/alirezaserver/addon.db',timeout=30) as source:
        with sqlite3.connect(snap) as dest:source.backup(dest)
    ai=pathlib.Path('/var/lib/alirezaserver/ai.db')
    if ai.exists():
        ai_snapshot=pathlib.Path(temp)/'ai.db'
        with sqlite3.connect(ai,timeout=30) as src:
            with sqlite3.connect(ai_snapshot) as dst:src.backup(dst)
        snapshots.append(ai_snapshot)
    shop=pathlib.Path('/var/lib/alirezaserver/shop.db')
    if shop.exists():
        shop_snapshot=pathlib.Path(temp)/'shop.db'
        with sqlite3.connect(shop,timeout=30) as src:
            with sqlite3.connect(shop_snapshot) as dst:src.backup(dst)
        snapshots.append(shop_snapshot)
    def filter_entry(entry):
        if any(entry.name=='var/lib/alirezaserver/'+n+s for n in ['addon.db','ai.db','shop.db'] for s in ['', '-wal','-shm']):return None
        if entry.name.endswith('/management.sock') or entry.name.endswith('/openvpn.pid'):return None
        return entry
    with tarfile.open(target,'w:gz') as tar:
        for name in ['etc/nova/origin.pem','etc/nova/origin.key','etc/nova/certs','etc/systemd/system/xray.service.d/90-alirezaserver-access.conf','etc/logrotate.d/alirezaserver-xray','usr/local/bin/alireza','opt/alirezaserver','var/lib/alirezaserver','opt/alirezabot','opt/alirezaserver-hashem','var/lib/alirezabot','etc/alirezaserver-hashem','etc/logrotate.d/alirezabot','etc/systemd/system/AdGuardHome.service','etc/systemd/system/alireza-firewall.service','etc/systemd/system/alireza-openvpn@.service','etc/systemd/system/nova-agent.service.d/alirezaserver.conf','etc/systemd/system/nova-agent.service.d/zz-alirezaserver.conf']:
            if pathlib.Path('/'+name).exists():tar.add('/'+name,arcname=name,filter=filter_entry)
        for name in ['alireza-cert-renew.service','alireza-cert-renew.timer','alireza-update.service','alireza-update.timer','alireza-update-recover.service']:
            path=pathlib.Path('/etc/systemd/system')/name
            if path.exists():tar.add(path,arcname='etc/systemd/system/'+name)
        for pattern in ['alirezabot-*.service','alirezabot-*.timer','alireza-hashem-*.service','alireza-hashem-*.timer']:
            for unit in pathlib.Path('/etc/systemd/system').glob(pattern):tar.add(unit,arcname='etc/systemd/system/'+unit.name)
        for tenant_path in tenant_paths:
            if tenant_path.exists():tar.add(tenant_path,arcname=tenant_path.as_posix().lstrip('/'),filter=filter_entry)
        for dump in tenant_dumps:tar.add(dump,arcname='database/'+dump.name)
        if botdump:tar.add(botdump,arcname='database/alirezabot.sql')
        tar.add(snap,arcname='var/lib/alirezaserver/addon.db')
        for snapshot in snapshots:tar.add(snapshot,arcname='var/lib/alirezaserver/'+snapshot.name)
os.chmod(target,0o600)
print(target)
