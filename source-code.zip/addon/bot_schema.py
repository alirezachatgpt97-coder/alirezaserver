# SPDX-License-Identifier: AGPL-3.0-or-later
"""Product-schema repair only. Called under the existing bot operation lock.
No package installation, service restart or changes to credentials/config files.
"""
import contextlib,datetime,fcntl,hashlib,json,os,pathlib,secrets,subprocess
HERE=pathlib.Path(__file__).resolve().parent
NAME='013_alirezaserver_product_schema.php'

def safe_path(p):
    if not p.is_absolute():raise RuntimeError('BOT_ABSOLUTE_PATH_REQUIRED')
    if any(part.is_symlink() for part in [p,*p.parents]):raise RuntimeError('BOT_SYMLINK_REFUSED')

def command(app,operation,destination=''):
    result=subprocess.run(['php','-d','display_errors=0',str(HERE/'bot-schema-tool.php'),operation,str(app),str(destination)],capture_output=True,text=True,timeout=180)
    if result.returncode:
        error=result.stderr.strip()
        raise RuntimeError(error if error.startswith('BOT_') and len(error)<120 else 'BOT_SCHEMA_COMMAND_FAILED')
    return json.loads(result.stdout)

def verify_schema(app):
    result=command(app,'check')
    if not all(result.values()):raise RuntimeError('BOT_SCHEMA_VERIFICATION_FAILED')
    return result

@contextlib.contextmanager
def operation_lock(state,already_locked):
    if already_locked:
        yield
        return
    state.mkdir(parents=True,exist_ok=True,mode=0o750)
    with os.fdopen(os.open(state/'.operation.lock',os.O_WRONLY|os.O_CREAT|os.O_NOFOLLOW,0o600),'a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('BOT_BUSY_RETRY_AFTER_INSTALL_FINISHES')
        yield

def repair_schema(app,state,root=None,*,already_locked=False,allow_missing=False):
    if os.geteuid()!=0:raise RuntimeError('ROOT_REQUIRED')
    app=pathlib.Path(app);state=pathlib.Path(state);root=pathlib.Path(root or os.environ.get('ALIREZA_ROOT','/var/lib/alirezaserver'))
    for p in [app,state,root]:safe_path(p)
    if not(app/'.alirezaserver-managed').is_file():raise RuntimeError('MANAGED_BOT_NOT_FOUND')
    for p in [app/'config.php',app/'db/bootstrap.php',app/'db/migrations',app/'panel/product.php']:
        safe_path(p)
        if not p.exists():raise RuntimeError('BOT_APPLICATION_INCOMPLETE')
    with operation_lock(state,already_locked):
        try:before=command(app,'check')
        except RuntimeError as error:
            if allow_missing and str(error)=='BOT_PRODUCT_TABLE_MISSING':return {'fresh':True}
            raise
        source=(HERE/'bot-product-schema.php').read_bytes();target=app/'db/migrations'/NAME;safe_path(target)
        if all(before.values()) and target.is_file() and target.read_bytes()==source:return {'changed':False,'schemaReady':True}
        backup=root/'backups'/('bot-plans-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+secrets.token_hex(4))
        safe_path(backup);backup.mkdir(parents=True,mode=0o700);os.chmod(backup,0o700)
        command(app,'backup',backup/'product.jsonl');os.chmod(backup/'product.jsonl',0o600)
        previous=target.read_bytes() if target.exists() else None
        if previous is not None:
            (backup/NAME).write_bytes(previous);os.chmod(backup/NAME,0o600)
        (backup/'metadata.json').write_text(json.dumps({'columnsBefore':before,'previousMigration':previous is not None,'repairSHA256':hashlib.sha256(source).hexdigest()}));os.chmod(backup/'metadata.json',0o600)
        st=(app/'db/bootstrap.php').stat();temp=target.with_name(NAME+'.'+secrets.token_hex(4)+'.tmp')
        try:
            with temp.open('xb') as f:f.write(source)
            os.chown(temp,st.st_uid,st.st_gid);os.chmod(temp,0o640);os.replace(temp,target)
            command(app,'migrate',target)
            verify_schema(app)
        except Exception:
            if previous is None:target.unlink(missing_ok=True)
            else:
                target.write_bytes(previous);os.chown(target,st.st_uid,st.st_gid);os.chmod(target,0o640)
            raise
        finally:temp.unlink(missing_ok=True)
        return {'changed':True,'schemaReady':True,'backup':str(backup)}
