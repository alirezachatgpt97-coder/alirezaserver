<?php
// SPDX-License-Identifier: AGPL-3.0-or-later
// alirezabot managed polling adapter for the Mirza application. Original bot
// handlers and independent web interface retain their upstream authors/licenses.
declare(strict_types=1);
chdir(__DIR__);
require_once __DIR__.'/config.php';
define('BOT_STATE',getenv('ALIREZABOT_STATE')?:'/var/lib/alirezabot');
function privateWrite(string $path,array $value):void {
 $tmp=$path.'.tmp';$data=json_encode($value,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
 if(file_put_contents($tmp,$data,LOCK_EX)===false)throw new RuntimeException('Private state write failed');
 chmod($tmp,0600);if(!rename($tmp,$path))throw new RuntimeException('Private state commit failed');
}
function stateRead(string $path):array {$b=@file_get_contents($path);if($b===false)return[];$v=json_decode($b,true);if(!is_array($v))throw new RuntimeException('Private state is corrupt');return $v;}
function runHandler(array $update):bool {
 $workerLock=fopen(BOT_STATE.'/worker.lock','c');$wait=microtime(true)+180;if(!$workerLock)return false;while(!flock($workerLock,LOCK_EX|LOCK_NB)){if(microtime(true)>$wait)return false;usleep(100000);}
 $proc=proc_open([PHP_BINARY,__DIR__.'/index.php'],[0=>['pipe','r'],1=>['file','/dev/null','a'],2=>['file','/dev/null','a']],$pipes,__DIR__);
 if(!is_resource($proc))return false;
 $payload=json_encode($update,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);$pos=0;$deadline=microtime(true)+180;stream_set_blocking($pipes[0],false);
 while($pos<strlen($payload)&&microtime(true)<$deadline){$n=@fwrite($pipes[0],substr($payload,$pos));if($n===false)break;if($n===0){usleep(100000);continue;}$pos+=$n;}
 fclose($pipes[0]);$exit=-1;
 do {$status=proc_get_status($proc);if(!$status['running']){$exit=$status['exitcode'];break;}if(microtime(true)>$deadline){proc_terminate($proc);usleep(300000);$status=proc_get_status($proc);if($status['running'])proc_terminate($proc,9);break;}usleep(100000);}while(true);
 $closed=proc_close($proc);return $pos===strlen($payload)&&($exit>=0?$exit:$closed)===0;
}
function removeOldDedupe(int $id):void {
 $path=__DIR__.'/storage/cache/recent_updates.json';$h=@fopen($path,'c+');if(!$h)return;
 try{if(flock($h,LOCK_EX)){$v=json_decode(stream_get_contents($h),true);if(is_array($v)){unset($v[(string)$id]);rewind($h);ftruncate($h,0);fwrite($h,json_encode($v,JSON_THROW_ON_ERROR));fflush($h);}flock($h,LOCK_UN);}}finally{fclose($h);}
}
function apiRequest(string $method,array $query=[]):?array {
 global $APIKEY;$ch=curl_init('https://api.telegram.org/bot'.$APIKEY.'/'.$method);
 curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($query),CURLOPT_RETURNTRANSFER=>true,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>40]);
 $raw=curl_exec($ch);curl_close($ch);if(!is_string($raw))return null;$v=json_decode($raw,true);return is_array($v)?$v:null;
}
if(!is_dir(BOT_STATE.'/inbox')&&!mkdir(BOT_STATE.'/inbox',0700,true))throw new RuntimeException('Inbox unavailable');
if(($argv[1]??'')==='--retry-failed'){
 $attempted=0;$success=0;
 foreach(glob(BOT_STATE.'/inbox/*.json')?:[] as $path){$entry=stateRead($path);if(!in_array($entry['status']??'', ['failed','uncertain'],true))continue;if($attempted>=3)break;$attempted++;$id=(int)($entry['update']['update_id']??0);removeOldDedupe($id);$entry['status']='processing';privateWrite($path,$entry);if(runHandler($entry['update'])){$entry['status']='done';privateWrite($path,$entry);if($id<(int)trim((string)@file_get_contents(BOT_STATE.'/telegram-offset')))unlink($path);$success++;}else{$entry['status']='failed';$entry['attempts']=(int)($entry['attempts']??0)+1;privateWrite($path,$entry);}}
 echo json_encode(['attempted'=>$attempted,'succeeded'=>$success]);exit(0);
}
$lock=fopen(BOT_STATE.'/poller.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))exit(0);
if(empty($APIKEY)||$APIKEY==='{API_KEY}')exit(1);
apiRequest('deleteWebhook',['drop_pending_updates'=>'false']);
$offset=(int)trim((string)@file_get_contents(BOT_STATE.'/telegram-offset'));
$commit=function(int $next)use(&$offset):void{$temp=BOT_STATE.'/telegram-offset.tmp';if(file_put_contents($temp,(string)$next,LOCK_EX)===false)throw new RuntimeException('Offset write failed');chmod($temp,0600);if(!rename($temp,BOT_STATE.'/telegram-offset'))throw new RuntimeException('Offset commit failed');$offset=$next;};
$backoff=2;$consecutiveFailures=0;$healthAt=0;$lastOK=(int)(stateRead(BOT_STATE.'/telegram-health.json')['lastPoll']??0);
while(true){
 $response=apiRequest('getUpdates',['offset'=>$offset,'timeout'=>25,'limit'=>100]);
 if(!$response||!($response['ok']??false)||!is_array($response['result']??null)){privateWrite(BOT_STATE.'/telegram-health.json',['connected'=>false,'lastPoll'=>$lastOK,'errorCode'=>(int)($response['error_code']??0)]);$retry=(int)($response['parameters']['retry_after']??$backoff);sleep(max(2,min(60,$retry)));$backoff=min(30,$backoff*2);continue;}
 $backoff=2;$lastOK=time();if(time()-$healthAt>=5){privateWrite(BOT_STATE.'/telegram-health.json',['connected'=>true,'lastPoll'=>$lastOK,'errorCode'=>0]);$healthAt=time();}$updates=$response['result'];usort($updates,fn($a,$b)=>(int)($a['update_id']??0)<=>(int)($b['update_id']??0));
 foreach($updates as $update){$id=$update['update_id']??null;if(!is_int($id)||$id<0)throw new RuntimeException('Invalid update envelope');if($id<$offset)continue;$path=BOT_STATE.'/inbox/'.$id.'.json';$old=stateRead($path);
  if($old){if(($old['status']??'')==='processing'){$old['status']='uncertain';privateWrite($path,$old);}if(($old['status']??'')==='done'){$commit($id+1);unlink($path);}else $commit($id+1);continue;}
  $entry=['status'=>'processing','received'=>time(),'attempts'=>1,'update'=>$update];privateWrite($path,$entry);
  if(runHandler($update)){$entry['status']='done';privateWrite($path,$entry);$commit($id+1);unlink($path);$consecutiveFailures=0;}else{$entry['status']='failed';privateWrite($path,$entry);$commit($id+1);fwrite(STDERR,"alirezabot: handler failed; restricted inbox retained for operator review.\n");$consecutiveFailures++;if($consecutiveFailures>=3){sleep(60);$consecutiveFailures=0;}}
 }
}
