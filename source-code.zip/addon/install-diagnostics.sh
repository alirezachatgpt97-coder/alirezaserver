#!/usr/bin/env bash
# Read-only: no service restart, firewall change, passwords, tokens or journal contents.
set -u
printf 'alirezaserver installation diagnostics\n'
if [[ -f /var/log/alirezaserver/last-failure.json ]]; then cat /var/log/alirezaserver/last-failure.json; fi
systemctl show xray.service nova-agent.service AdGuardHome.service alireza-firewall.service alireza-update-recover.service -p Id -p ActiveState -p SubState -p Result -p ExecMainCode -p ExecMainStatus --no-pager || true
printf '\nRecent private install logs (read locally; remove secrets before sharing):\n'
find /var/log/alirezaserver -maxdepth 1 -type f -name 'install-*.log*' -printf '%f\n' 2>/dev/null | sort | tail -6
exit 0
