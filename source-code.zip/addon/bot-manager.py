#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Install the independently licensed Mirza application in its own service account.
No shell interpolation, no shared PHP pool, no root bot worker, no DB deletion.
"""
import signal,time,fcntl,base64,hashlib,json,os,pathlib,pwd,secrets,shutil,subprocess,sys,tarfile,tempfile
APP=pathlib.Path('/opt/alirezabot'); STATE=pathlib.Path('/var/lib/alirezabot'); HERE=pathlib.Path(__file__).resolve().parent
UNITS=['alirezabot-php.service','alirezabot-poller.service','alirezabot-maintenance.timer']
PROGRESS=None
def phase(stage,step):
    if not PROGRESS:return
    root=pathlib.Path(os.environ.get('ALIREZA_ROOT','/var/lib/alirezaserver'));root.mkdir(parents=True,exist_ok=True,mode=0o700)
    target=root/'bot-phase.json';tmp=target.with_suffix('.tmp')
    with os.fdopen(os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600),'w') as f:json.dump({'id':PROGRESS,'stage':stage,'step':step},f)
    tmp.replace(target)

def run(args,data=None,timeout=180):
    with subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True) as child:
        try:out,_=child.communicate(data,timeout=timeout)
        except subprocess.TimeoutExpired:
            try:os.killpg(child.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:child.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                child.communicate()
            raise RuntimeError('COMMAND_TIMEOUT:'+pathlib.Path(args[0]).name)
        if child.returncode:raise RuntimeError('COMMAND_FAILED:'+pathlib.Path(args[0]).name)
        return out

def status():
    output=subprocess.run(['systemctl','show','--property=Id,ActiveState',*UNITS],capture_output=True,text=True,timeout=10).stdout
    active={u:'unknown' for u in UNITS}
    for block in output.split('\n\n'):
        values=dict(line.split('=',1) for line in block.splitlines() if '=' in line)
        if values.get('Id') in active:active[values['Id']]=values.get('ActiveState','unknown')
    inbox={'failed':0,'uncertain':0,'processing':0}
    for p in (STATE/'inbox').glob('*.json'):
        try:kind=json.loads(p.read_text()).get('status');inbox[kind]=inbox.get(kind,0)+1
        except (OSError,ValueError):inbox['uncertain']+=1
    try:telegram=json.loads((STATE/'telegram-health.json').read_text())
    except (FileNotFoundError,ValueError):telegram={}
    telegram={k:telegram[k] for k in ['connected','lastPoll','errorCode'] if k in telegram}
    telegram['connected']=telegram.get('connected') is True and time.time()-telegram.get('lastPoll',0)<90 and active.get('alirezabot-poller.service')=='active'
    metrics={'users':None,'invoices':None}
    if (APP/'config.php').exists():
        try:
            script="chdir('/opt/alirezabot');require 'config.php';echo json_encode(['users'=>(int)$pdo->query('SELECT COUNT(*) FROM user')->fetchColumn(),'invoices'=>(int)$pdo->query('SELECT COUNT(*) FROM invoice')->fetchColumn()]);"
            metrics=json.loads(run(['php','-r',script],timeout=5))
        except (RuntimeError,ValueError,OSError):pass
    return {'metrics':metrics,'telegram':telegram,'inbox':inbox,'installed':(APP/'config.php').exists(),'services':active,'running':all(v=='active' for v in active.values())}
def phpvalue(v):return "'"+str(v).replace('\\','\\\\').replace("'","\\'")+"'"
def php_fpm():
    php_version=run(['php','-r','echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;'],timeout=15).strip()
    fpm=pathlib.Path('/usr/sbin')/('php-fpm'+php_version)
    if not fpm.is_file():raise RuntimeError('BOT_MATCHING_PHP_FPM_MISSING')
    return fpm
def install(v):
    global PROGRESS
    PROGRESS=v.get('jobId') if isinstance(v.get('jobId'),str) and len(v['jobId'])==32 and all(c in '0123456789abcdef' for c in v['jobId']) else None
    phase('dependencies',1)
    if os.geteuid()!=0:raise RuntimeError('ROOT_REQUIRED')
    if (APP/'config.php').exists() and not(APP/'.alirezaserver-managed').exists():raise RuntimeError('EXISTING_BOT_DIRECTORY_CONFLICT')
    old_fpm={p.name for d in ['/lib/systemd/system','/usr/lib/systemd/system','/etc/systemd/system'] for p in pathlib.Path(d).glob('php*-fpm.service')}
    extensions_ok=False
    if shutil.which('php'):
        extensions_ok=subprocess.run(['php','-r',"exit(count(array_diff(['pdo_mysql','curl','mbstring','zip','gd','dom','bcmath'],get_loaded_extensions()))?1:0);"],capture_output=True,timeout=15).returncode==0
    if not extensions_ok or not shutil.which('php') or not any(pathlib.Path('/usr/sbin').glob('php-fpm*')) or not shutil.which('mariadb') or not shutil.which('logrotate'):
        run(['apt-get','update'],timeout=180);run(['apt-get','install','-y','php-cli','php-fpm','php-mysql','php-curl','php-mbstring','php-zip','php-gd','php-xml','php-bcmath','mariadb-server','logrotate'],timeout=600)
    if int(run(['php','-r','echo PHP_VERSION_ID;'],timeout=15).strip())<80200:raise RuntimeError('BOT_REQUIRES_PHP_82_OR_NEWER')
    fpm=php_fpm()
    # Disable only distribution PHP pools newly introduced by this installation.
    for d in ['/lib/systemd/system','/usr/lib/systemd/system']:
        for unit in pathlib.Path(d).glob('php*-fpm.service'):
            if unit.name not in old_fpm:run(['systemctl','disable','--now',unit.name],timeout=30)
    run(['systemctl','start','mariadb'],timeout=30)
    try:pwd.getpwnam('alirezabot')
    except KeyError:run(['useradd','--system','--home-dir',str(STATE),'--shell','/usr/sbin/nologin','alirezabot'])
    STATE.mkdir(mode=0o750,parents=True,exist_ok=True); APP.mkdir(mode=0o750,parents=True,exist_ok=True)
    phase('application',2)
    payload=base64.b64decode((HERE/'alirezabot-source.tar.b64').read_bytes(),validate=False)
    manifest=json.loads((HERE/'reference-versions.json').read_text())
    if hashlib.sha256(payload).hexdigest()!=manifest['bot']['packagedSHA256']:raise RuntimeError('BOT_PAYLOAD_CHECKSUM')
    with tempfile.TemporaryDirectory() as temp:
        arc=pathlib.Path(temp)/'bot.tgz';arc.write_bytes(payload)
        with tarfile.open(arc) as tar:
            for m in tar.getmembers():
                if m.name.startswith('/') or '..' in pathlib.PurePosixPath(m.name).parts or not(m.isfile() or m.isdir()):raise RuntimeError('UNSAFE_BOT_ARCHIVE')
            members=[m for m in tar.getmembers() if not (m.name.startswith('storage/') and (APP/m.name).exists())]
            tar.extractall(APP,members=members,filter='data')
    # Preserve existing application settings and database; only integration credentials change.
    phase('database',3)
    dbpass=v['dbPassword']
    if not dbpass.isalnum() or len(dbpass)<32:raise RuntimeError('INVALID_DB_SECRET')
    if not(APP/'.alirezaserver-managed').exists():
        if run(['mariadb','--protocol=socket','-u','root','-N','-e',"SHOW DATABASES LIKE 'alirezabot'"]).strip():raise RuntimeError('EXISTING_BOT_DATABASE_CONFLICT')
        (APP/'.alirezaserver-managed').write_text('alirezaserver managed Mirza installation\n')
        os.chmod(APP/'.alirezaserver-managed',0o600)
    sql="CREATE DATABASE IF NOT EXISTS alirezabot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci; CREATE USER IF NOT EXISTS 'alirezabot'@'localhost' IDENTIFIED BY '"+dbpass+"'; GRANT ALL ON alirezabot.* TO 'alirezabot'@'localhost';"
    run(['mariadb','--protocol=socket','-u','root'],sql)
    config='''<?php
$request_exec_timeout = 30000;
$dbhost='localhost';$dbname='alirezabot';$usernamedb='alirezabot';
$passworddb=DBPASSWORD;
$pdo=new PDO('mysql:host=localhost;dbname=alirezabot;charset=utf8mb4',$usernamedb,$passworddb,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
$APIKEY=BOTTOKEN;$adminnumber=ADMINID;$domainhosts=DOMAIN;$usernamebot=BOTNAME;
'''
    for k,value in {'DBPASSWORD':dbpass,'BOTTOKEN':v['token'],'ADMINID':v['adminId'],'DOMAIN':v['domain'],'BOTNAME':v['username']}.items():config=config.replace(k,phpvalue(value))
    (APP/'config.php').write_text(config);os.chmod(APP/'config.php',0o640)
    run(['php','-r',"chdir('/opt/alirezabot');require 'db/bootstrap.php';"],timeout=120)
    if v.get('resetWebPassword'):
        script="require '/opt/alirezabot/config.php';$v=json_decode(stream_get_contents(STDIN),true);$q=$pdo->prepare('UPDATE admin SET username=?,password=?,rule=? WHERE id_admin=?');$q->execute(['admin',password_hash($v['password'],PASSWORD_DEFAULT),'administrator',$v['id']]);"
        run(['php','-r',script],json.dumps({'password':v['webPassword'],'id':v['adminId']}))
    # Register the local panel with real schema defaults and retain existing plans.
    phase('local-panel',4)
    if v.get('bridgeURL'):sync_local(v)
    shutil.chown(APP,user='alirezabot',group='alirezabot');shutil.chown(STATE,user='alirezabot',group='alirezabot')
    for path in APP.rglob('*'):
        if path.is_symlink():raise RuntimeError('BOT_SYMLINK_REFUSED')
        shutil.chown(path,user='alirezabot',group='alirezabot')
        if path.is_file():os.chmod(path,0o640)
        elif path.is_dir():os.chmod(path,0o750)
    phase('php-runtime',5)
    config='''[global]
pid=/run/alirezabot/php.pid
error_log=syslog
daemonize=no
[alirezabot]
user=alirezabot
group=alirezabot
listen=/run/alirezabot/php.sock
listen.mode=0660
listen.owner=root
listen.group=root
pm=ondemand
pm.max_children=3
pm.process_idle_timeout=10s
pm.max_requests=300
clear_env=yes
catch_workers_output=yes
security.limit_extensions=.php
php_admin_flag[display_errors]=off
php_admin_flag[log_errors]=on
php_admin_value[error_log]=syslog
php_admin_value[memory_limit]=192M
php_admin_value[session.save_path]=/var/lib/alirezabot
php_admin_value[opcache.enable]=1
php_admin_value[opcache.memory_consumption]=32
'''
    (APP/'php-fpm.conf').write_text(config)
    common='''After=network-online.target mariadb.service
[Service]
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/alirezabot /var/lib/alirezabot
UMask=0027
StandardOutput=journal
StandardError=journal
LogRateLimitIntervalSec=30s
LogRateLimitBurst=200
'''
    web='[Unit]\nDescription=alirezabot dedicated PHP FastCGI\n'+common+'RuntimeDirectory=alirezabot\nExecStart='+str(fpm)+' --nodaemonize --fpm-config /opt/alirezabot/php-fpm.conf\n[Install]\nWantedBy=multi-user.target\n'
    poll='[Unit]\nDescription=alirezabot Telegram polling\n'+common+'User=alirezabot\nGroup=alirezabot\nWorkingDirectory=/opt/alirezabot\nExecStart=/usr/bin/php /opt/alirezabot/poll.php\n[Install]\nWantedBy=multi-user.target\n'
    for name,content in zip(UNITS,[web,poll]):pathlib.Path('/etc/systemd/system',name).write_text(content)
    maintenance='[Unit]\nDescription=alirezabot scheduled tasks\n'+common+'Type=oneshot\nUser=alirezabot\nGroup=alirezabot\nWorkingDirectory=/opt/alirezabot\nExecStart=/usr/bin/php /opt/alirezabot/cronbot/run.php\n'
    pathlib.Path('/etc/systemd/system/alirezabot-maintenance.service').write_text(maintenance)
    pathlib.Path('/etc/systemd/system/alirezabot-maintenance.timer').write_text('[Unit]\nDescription=alirezabot minute dispatcher\n[Timer]\nOnCalendar=*-*-* *:*:00\nPersistent=true\nRandomizedDelaySec=5\nUnit=alirezabot-maintenance.service\n[Install]\nWantedBy=timers.target\n')
    pathlib.Path('/etc/logrotate.d').mkdir(parents=True,exist_ok=True)
    pathlib.Path('/etc/logrotate.d/alirezabot').write_text('/opt/alirezabot/error_log /opt/alirezabot/panel/error_log /opt/alirezabot/cronbot/error_log /opt/alirezabot/storage/log.txt /opt/alirezabot/*.log /opt/alirezabot/log/*.log /opt/alirezabot/storage/logs/*.log {\n weekly\n rotate 4\n size 5M\n missingok\n notifempty\n compress\n delaycompress\n copytruncate\n su alirezabot alirezabot\n}\n')
    run([str(fpm),'--test','--fpm-config',str(APP/'php-fpm.conf')],timeout=15)
    phase('services',6)
    run(['systemctl','daemon-reload']);run(['systemctl','enable','--now',*UNITS],timeout=30);run(['systemctl','restart',*UNITS],timeout=30)
    phase('health',7)
    repair_web()
    result=status()
    if not result['running']:raise RuntimeError('BOT_SERVICES_NOT_READY')
    phase('complete',8)
    return result
UI_FILES=['panels/Api/alireza_local.php','panels/Drivers/XuiSingle.php','panel/inc/layout_head.php','panel/inc/layout_foot.php','panel/inc/alireza_appearance.php','panel/settings.php','panel/appearance.php','panel/js/app.js','panel/js/settings.js','panel/js/alireza-appearance.js','panel/js/sort_keyboard.js','panel/css/cyberpunk_theme.css','panel/css/alireza-appearance.css']
def upgrade_ui():
    if not (APP/'.alirezaserver-managed').exists():return {'installed':False}
    data=base64.b64decode((HERE/'alirezabot-source.tar.b64').read_bytes())
    manifest=json.loads((HERE/'reference-versions.json').read_text())
    if hashlib.sha256(data).hexdigest()!=manifest['bot']['packagedSHA256']:raise RuntimeError('BOT_PAYLOAD_CHECKSUM')
    import io
    backup=STATE/('ui-backup-'+time.strftime('%Y%m%dT%H%M%SZ')+'.tar.gz')
    changes=[]
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
        for name in UI_FILES:
            member=tar.getmember(name)
            if not member.isfile():raise RuntimeError('UNSAFE_BOT_ARCHIVE')
            path=APP/name
            for ancestor in [path,*path.parents]:
                if ancestor==APP.parent:break
                if ancestor.is_symlink():raise RuntimeError('BOT_SYMLINK_REFUSED')
            content=tar.extractfile(member).read()
            if not path.exists() or path.read_bytes()!=content:changes.append((path,content))
    if not changes:return {'changed':False}
    STATE.mkdir(parents=True,exist_ok=True,mode=0o750)
    with tarfile.open(backup,'w:gz') as old:
        for path,_ in changes:
            if path.exists():old.add(path,arcname=path.relative_to(APP).as_posix())
    backup.chmod(0o600)
    for path,content in changes:
        path.parent.mkdir(parents=True,exist_ok=True)
        temp=path.with_name(path.name+'.rc6-new');temp.write_bytes(content);temp.chmod(0o640);shutil.chown(temp,user='alirezabot',group='alirezabot');os.replace(temp,path)
    return {'changed':True,'backup':str(backup)}

def repair_web():
    if not (APP/'.alirezaserver-managed').exists():return {'installed':False}
    conf=APP/'php-fpm.conf'
    if conf.is_symlink():raise RuntimeError('BOT_CONFIG_SYMLINK_REFUSED')
    old=conf.read_text();new=old.replace('error_log=/proc/self/fd/2','error_log=syslog').replace('php_admin_value[error_log]=/proc/self/fd/2','php_admin_value[error_log]=syslog')
    if new!=old:
        backup=APP/'php-fpm.conf.before-rc6'
        if not backup.exists():backup.write_text(old);backup.chmod(0o600)
        conf.write_text(new);conf.chmod(0o640)
    run([str(php_fpm()),'--test','--fpm-config',str(conf)],timeout=15)
    if new!=old or subprocess.run(['systemctl','is-active','--quiet','alirezabot-php.service']).returncode:
        run(['systemctl','restart','alirezabot-php.service'],timeout=30)
    for _ in range(20):
        if pathlib.Path('/run/alirezabot/php.sock').is_socket() and subprocess.run(['systemctl','is-active','--quiet','alirezabot-php.service']).returncode==0:return {'installed':True,'webReady':True}
        time.sleep(.25)
    raise RuntimeError('BOT_PHP_NOT_READY_CHECK_JOURNAL')

def reset_password(v):
    if os.geteuid()!=0:raise RuntimeError('ROOT_REQUIRED')
    if not (APP/'.alirezaserver-managed').exists():raise RuntimeError('BOT_NOT_INSTALLED')
    password=v.get('password') or secrets.token_urlsafe(18)
    if not isinstance(password,str) or not 12<=len(password)<=128:raise RuntimeError('PASSWORD_LENGTH_12_TO_128')
    script="""require '/opt/alirezabot/config.php';$v=json_decode(stream_get_contents(STDIN),true);$q=$pdo->prepare('SELECT username FROM admin WHERE id_admin=? AND rule=?');$q->execute([$adminnumber,'administrator']);$name=$q->fetchColumn();if(!$name){exit(2);}$q=$pdo->prepare('UPDATE admin SET password=? WHERE id_admin=?');$q->execute([password_hash($v['password'],PASSWORD_DEFAULT),$adminnumber]);echo json_encode(['username'=>$name]);"""
    result=json.loads(run(['php','-r',script],json.dumps({'password':password})))
    (pathlib.Path(os.environ.get('ALIREZA_ROOT','/var/lib/alirezaserver'))/'bot-job-result.json').unlink(missing_ok=True)
    # PHP session files only: preserve Telegram offsets, inbox and appearance data.
    for session in STATE.glob('sess_*'):
        if session.is_file() and not session.is_symlink():session.unlink()
    return {**result,'password':password,'sessionsRevoked':True}

def sync_local(v):
    if not(APP/'.alirezaserver-managed').exists():raise RuntimeError('BOT_NOT_MANAGED')
    script="require '/opt/alirezabot/config.php';require '/opt/alirezabot/panels/Api/alireza_local.php';$v=json_decode(stream_get_contents(STDIN),true);alireza_sync_local($pdo,$v);"
    run(['php','-r',script],json.dumps({'url':v['bridgeURL'],'token':v['bridgeToken'],'sub':v['subscriptionURL'],'inbounds':v.get('inboundIds',[])}))
    domain=v.get('botDomain') or v.get('domain')
    if domain:
        target=APP/'local-domain.php'
        target.write_text('<?php $domainhosts='+phpvalue(domain)+';\n')
        os.chmod(target,0o640);shutil.chown(target,user='alirezabot',group='alirezabot')
        config=APP/'config.php';source=config.read_text()
        if "require __DIR__.'/local-domain.php'" not in source:
            config.write_text(source+"\nif(is_file(__DIR__.'/local-domain.php')) require __DIR__.'/local-domain.php';\n")
    return {'synchronized':True}

def main(v):
    op=v.get('operation')
    if op=='status':return status()
    if op=='upgrade-ui':return upgrade_ui()
    if op=='repair-web':return repair_web()
    if op=='reset-password':return reset_password(v)
    if op=='install':return install(v)
    if op=='sync-local':return sync_local(v)
    if op=='retry-failed':return json.loads(run(['runuser','-u','alirezabot','--','php',str(APP/'poll.php'),'--retry-failed'],timeout=660))
    if op in ['start','stop','restart']:
        run(['systemctl',op,*UNITS],timeout=30)
        if op=='stop':run(['systemctl','stop','alirezabot-maintenance.service'],timeout=30)
        return status()
    if op=='uninstall':
        run(['systemctl','disable','--now',*UNITS],timeout=30)
        run(['systemctl','stop','alirezabot-maintenance.service'],timeout=30)
        for u in UNITS+['alirezabot-maintenance.service']:pathlib.Path('/etc/systemd/system',u).unlink(missing_ok=True)
        run(['systemctl','daemon-reload']);return {'retained':'Application, configuration and database retained.','running':False}
    raise RuntimeError('INVALID_OPERATION')
if __name__=='__main__':
    try:
        v=json.load(sys.stdin);lock=None
        if v.get('operation')!='status':
            STATE.mkdir(parents=True,exist_ok=True,mode=0o750);lock=(STATE/'.operation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        print(json.dumps(main(v)))
    except Exception as e:print(json.dumps({'error':str(e) if isinstance(e,RuntimeError) else type(e).__name__}));sys.exit(1)
