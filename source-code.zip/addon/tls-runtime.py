#!/usr/bin/env python3
"""Install isolated, pinned IP-capable Certbot wheels; never compile on the VPS."""
import json,os,pathlib,subprocess
ROOT=pathlib.Path('/opt/alirezaserver-acme');VERSION='5.8.0'
def run(args,**kw):return subprocess.run(args,check=True,timeout=480,**kw)
def install():
 if os.geteuid()!=0:raise RuntimeError('ROOT_REQUIRED')
 if ROOT.is_symlink():raise RuntimeError('TLS_VENV_SYMLINK_REFUSED')
 binary=ROOT/'bin/certbot'
 if binary.exists():
  version=subprocess.check_output([str(binary),'--version'],text=True,timeout=20).strip()
  if version=='certbot '+VERSION:return
 probe=subprocess.run(['python3','-m','venv','--help'],capture_output=True).returncode==0
 if not probe or not pathlib.Path('/usr/share/python3-wheels').exists():
  run(['apt-get','update']);run(['apt-get','install','-y','python3-venv'])
 run(['python3','-m','venv',str(ROOT)])
 run([str(ROOT/'bin/pip'),'install','--disable-pip-version-check','--no-cache-dir','--only-binary=:all:','--index-url','https://pypi.org/simple','certbot=='+VERSION,'--report',str(ROOT/'installation-report.json')])
 if subprocess.check_output([str(binary),'--version'],text=True,timeout=20).strip()!='certbot '+VERSION:raise RuntimeError('TLS_CERTBOT_VERSION_MISMATCH')
 with (ROOT/'installed-packages.json').open('w') as f:run([str(ROOT/'bin/pip'),'list','--format=json'],stdout=f)
if __name__=='__main__':install()
