// SPDX-License-Identifier: GPL-3.0-or-later
// Queue the external guarded updater; never execute upstream shell inside the panel.
import {spawn} from 'node:child_process';
export function queueUpdate(execute=spawn){return new Promise((resolve,reject)=>{const child=execute('systemctl',['start','--no-block','alireza-update.service'],{stdio:'ignore',shell:false});const timer=setTimeout(()=>{child.kill?.();reject(Object.assign(Error('UPDATE_QUEUE_TIMEOUT'),{status:503}));},15000);child.once('error',()=>{clearTimeout(timer);reject(Object.assign(Error('UPDATE_SERVICE_UNAVAILABLE'),{status:503}));});child.once('close',code=>{clearTimeout(timer);if(code===0)resolve({ok:true,queued:true});else reject(Object.assign(Error('UPDATE_SERVICE_REJECTED'),{status:503}));});});}
