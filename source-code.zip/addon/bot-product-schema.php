<?php
// SPDX-License-Identifier: AGPL-3.0-or-later
// Additive repair for the web product editor. Existing plan values/types are retained; invalid NULL status gets the normal active default.
return static function (PDO $pdo, $schema = null): void {
    $lock = 'alirezabot.product-schema.v1';
    $stmt = $pdo->prepare('SELECT GET_LOCK(?, 15)');
    $stmt->execute([$lock]);
    if ((int) $stmt->fetchColumn() !== 1) {
        throw new RuntimeException('BOT_PRODUCT_SCHEMA_BUSY');
    }
    try {
        $table = $pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='product'")->fetchColumn();
        if (!$table) {
            throw new RuntimeException('BOT_PRODUCT_TABLE_MISSING');
        }
        $read = $pdo->query("SELECT COLUMN_NAME, COLUMN_DEFAULT FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='product'");
        $columns = [];
        foreach ($read->fetchAll(PDO::FETCH_ASSOC) as $column) $columns[strtolower($column['COLUMN_NAME'])] = $column;
        // Additive opt-in: old plans remain disabled.
        if (!isset($columns['geo_exits'])) {
            $pdo->exec('ALTER TABLE `product` ADD COLUMN `geo_exits` TINYINT UNSIGNED NOT NULL DEFAULT 0');
        }
        // Zero is the existing UI's unlimited/default IP count. Never UPDATE old columns.
        if (!isset($columns['limitip'])) {
            $pdo->exec('ALTER TABLE `product` ADD COLUMN `limitip` INT UNSIGNED NOT NULL DEFAULT 0');
        }
        // The initial CREATE definition also omitted this column, while bot queries use it.
        if (!isset($columns['status_product'])) {
            $pdo->exec("ALTER TABLE `product` ADD COLUMN `status_product` VARCHAR(20) NOT NULL DEFAULT 'active'");
        } elseif ($columns['status_product']['COLUMN_DEFAULT'] === null || strtoupper((string)$columns['status_product']['COLUMN_DEFAULT']) === 'NULL') {
            // The older upgrade path added VARCHAR(20) without a SQL DEFAULT.
            // NULL plans otherwise disappear from miniapp's != 'disable' queries.
            $pdo->exec("ALTER TABLE `product` ALTER COLUMN `status_product` SET DEFAULT 'active'");
            $pdo->exec("UPDATE `product` SET `status_product`='active' WHERE `status_product` IS NULL");
        }
    } finally {
        $stmt = $pdo->prepare('SELECT RELEASE_LOCK(?)');
        $stmt->execute([$lock]);
    }
};
