import pathlib,tempfile,unittest,importlib.util,tarfile
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Upgrade(unittest.TestCase):
 def test_managed_bot_editor_update_is_backed_up_and_keeps_account_config(self):
  spec=importlib.util.spec_from_file_location('bot_manager',ROOT/'addon/bot-manager.py');m=importlib.util.module_from_spec(spec)
  import sys
  with patch.dict(sys.modules,{}):
   sys.path.insert(0,str(ROOT/'addon'))
   try:spec.loader.exec_module(m)
   finally:sys.path.pop(0)
  with tempfile.TemporaryDirectory() as directory:
   root=pathlib.Path(directory);app=root/'app';app.mkdir();state=root/'state'
   (app/'.alirezaserver-managed').write_text('managed');(app/'config.php').write_text('private existing credentials')
   for name in m.UI_FILES:
    p=app/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('previous content')
   with patch.object(m,'APP',app),patch.object(m,'STATE',state),patch.object(m.shutil,'chown'):
    result=m.upgrade_ui();self.assertTrue(result['changed']);self.assertFalse(m.upgrade_ui()['changed'])
   self.assertEqual((app/'config.php').read_text(),'private existing credentials')
   for name in ['panel/product.php','panel/js/product.js','api/product.php','panels/Api/x-ui_single.php','panels/Drivers/XuiSingle.php']:
    self.assertEqual((app/name).read_bytes(),(ROOT/'core/alirezabot'/name).read_bytes())
   with tarfile.open(result['backup']) as tar:self.assertEqual(tar.extractfile('panel/product.php').read(),b'previous content')
if __name__=='__main__':unittest.main()
