import test from 'node:test';import assert from 'node:assert/strict';import {EventEmitter} from 'node:events';import{cloudflarePlan,coordinatedJob}from'../addon/tls-coordinator.mjs';import{localContext,publicInstance}from'../addon/site-address.mjs';
test('Automatic Cloudflare DNS01 uses saved scoped token without changing A/AAAA/proxy records',async()=>{
 const kv={get:async()=> 'test-only-token'},seen=[];const helpers={getSettings:async()=>({host:'8.8.8.8'}),findZone:async()=>({id:'zone'}),fetch:async(url,o)=>{seen.push([url,o]);return{ok:true,json:async()=>({success:true,result:[{name:'panel.example.com',type:'A',proxied:true}]})};},provision:async o=>seen.push(o),resolveXrayOpts:async(_,s)=>s};
 const original=async(db,opt,p,d)=>{assert.equal(p.method,'letsencrypt');await d.provision({domain:p.domain,method:p.method});const s={host:p.domain};await d.resolveXrayOpts(db,s);assert.equal(s.directHost,'8.8.8.8');assert.equal(s.hostProxied,true);};
 await coordinatedJob(original,kv,{}, {domain:'panel.example.com',method:'letsencrypt'}, {},helpers);
 assert.equal(seen[1].method,'cloudflare');assert.equal(seen[1].cfToken,'test-only-token');assert.equal(seen[0][1].method,undefined);assert.match(seen[0][0],/dns_records\?name=panel.example.com$/);
 assert.equal(await cloudflarePlan({get:async()=>null},'panel.example.com',()=>{throw Error('must not call');}),null);
});
test('Public origin is canonical, independent of browser host and extra panel port',()=>{assert.deepEqual(localContext({host:'panel.example.com',inbounds:[{id:'a'},{id:'b',enabled:false}]},8088,'/secret','attacker.invalid',443),{bridgeURL:'http://127.0.0.1:8088/secret/alireza/api/bot-bridge',subscriptionURL:'https://panel.example.com/secret/alireza/bot/sub',botDomain:'panel.example.com/secret/alireza/bot/web',inboundIds:['a']});assert.throws(()=>localContext({host:'user@evil.com'},8088,''));});
test('Public check requires same instance, trusted TLS, no cookie; Cloudflare/WAF failures are explicit',async()=>{
 for(const [status,value,ok]of[[200,{product:'alirezaserver',instance:'local'},true],[200,{product:'alirezaserver',instance:'other'},false],[403,{},false],[526,{},false]]){
  let opts;const request=(o,cb)=>{opts=o;const req=new EventEmitter();req.setTimeout=()=>{};req.end=()=>{const res=new EventEmitter();res.statusCode=status;cb(res);res.emit('data',JSON.stringify(value));res.emit('end');};return req;};
  if(ok)assert.equal(await publicInstance('panel.example.com',443,'/secret','local',request),true);else await assert.rejects(publicInstance('panel.example.com',443,'/secret','local',request),/WRONG_ORIGIN|HTTP_403|HTTP_526/);
  assert.equal(opts.rejectUnauthorized,true);assert.equal(opts.headers.cookie,undefined);assert.equal(opts.path,'/secret/alireza/api/instance');
 }
});
