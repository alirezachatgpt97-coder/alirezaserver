import importlib.util,pathlib,tempfile,unittest,os,json
from unittest.mock import patch,Mock
ROOT=pathlib.Path(__file__).resolve().parents[1]
def module(name,file):
 s=importlib.util.spec_from_file_location(name,ROOT/'addon'/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
access=module('xrayrc6','xray-access.py');bot=module('botrc6','bot-manager.py');cli=module('clirc6','alireza.py')
class Repair(unittest.TestCase):
 def test_repeated_runtime_repair_after_atomic_config_replacement_preserves_content(self):
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d);c=root/'xray/config.json';c.parent.mkdir(mode=0o700);c.write_text('first');cert=root/'nova';cert.mkdir(mode=0o700);(cert/'origin.pem').write_text('cert');(cert/'origin.key').write_text('key');logs=root/'logs'
   real_chown=os.chown;calls=[]
   def chown(path,uid,gid):calls.append((str(path),uid,gid));real_chown(path,0,os.getgid())
   with patch.object(access,'identity',return_value=(65534,os.getgid())),patch.object(access.subprocess,'check_output',return_value=str(c)),patch.object(access.os,'chown',side_effect=chown),patch.object(access.os,'fchown'):
    access.repair(root/'state',c,cert,logs)
    new=c.with_suffix('.tmp');new.write_text('second');new.chmod(0o600);os.replace(new,c)
    access.repair(root/'state',c,cert,logs)
   self.assertEqual(c.read_text(),'second');self.assertEqual(c.stat().st_mode&0o777,0o640);self.assertEqual((cert/'origin.key').read_text(),'key');self.assertEqual((logs/'access.log').stat().st_mode&0o777,0o640);self.assertIn((str(logs),65534,os.getgid()),calls)
 def test_log_symlink_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d);c=root/'config.json';c.write_text('{}');logs=root/'logs';logs.mkdir();secret=root/'secret';secret.write_text('unchanged');(logs/'access.log').symlink_to(secret)
   with patch.object(access,'identity',return_value=(0,0)),patch.object(access.subprocess,'check_output',return_value=str(c)):
    with self.assertRaisesRegex(RuntimeError,'SYMLINK'):access.repair(root/'state',c,root/'none',logs)
   self.assertEqual(secret.read_text(),'unchanged')
 def test_console_dropin_migrates_with_backup_and_custom_commands_are_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d);drop=root/'etc/systemd/system/xray.service.d/90-alirezaserver-access.conf';drop.parent.mkdir(parents=True);old='[Service]\nExecStartPre=+/usr/bin/chown root:xray /etc/nova/origin.key\nExecStartPre=+/usr/bin/chmod 0640 /etc/nova/origin.key\n';drop.write_text(old)
   with patch.object(access.subprocess,'run') as run:
    access.configure_startup(root,root);self.assertIn('--before-start',drop.read_text());self.assertEqual((root/'xray-dropin-before-rc6.conf').read_text(),old);self.assertEqual(run.call_count,1);access.configure_startup(root,root);self.assertEqual(run.call_count,1)
    drop.write_text('[Service]\nExecStartPre=/custom/command\n')
    with self.assertRaisesRegex(RuntimeError,'CONFLICT'):access.configure_startup(root,root)
   self.assertEqual(drop.read_text(),'[Service]\nExecStartPre=/custom/command\n')
 def test_bot_repair_changes_only_legacy_error_log_and_requires_socket_health(self):
  with tempfile.TemporaryDirectory() as d:
   app=pathlib.Path(d);(app/'.alirezaserver-managed').touch();config=app/'php-fpm.conf';config.write_text('[global]\nerror_log=/proc/self/fd/2\n[bot]\nphp_admin_value[error_log]=/proc/self/fd/2\n')
   with patch.object(bot,'APP',app),patch.object(bot,'php_fpm',return_value=pathlib.Path('/usr/sbin/php-fpm8.3')),patch.object(bot,'run',return_value=''),patch.object(bot.subprocess,'run',return_value=Mock(returncode=0)),patch.object(pathlib.Path,'is_socket',return_value=True):
    self.assertTrue(bot.repair_web()['webReady']);first=config.read_text();bot.repair_web();self.assertEqual(config.read_text(),first)
   self.assertNotIn('/proc/self/fd/2',first);self.assertEqual((app/'php-fpm.conf.before-rc6').stat().st_mode&0o777,0o600)
 def test_password_reset_is_independent_keeps_non_session_state_and_uses_stdin(self):
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d);(root/'.alirezaserver-managed').touch();(root/'sess_abc').write_text('old');(root/'telegram-health.json').write_text('keep');(root/'appearance-user.json').write_text('keep')
   with patch.object(bot,'APP',root),patch.object(bot,'STATE',root),patch.object(bot,'run',return_value='{"username":"custom-admin"}') as run:
    result=bot.reset_password({'password':'new-test-only-password'})
   self.assertEqual(result['username'],'custom-admin');self.assertFalse((root/'sess_abc').exists());self.assertEqual((root/'telegram-health.json').read_text(),'keep');self.assertEqual((root/'appearance-user.json').read_text(),'keep');self.assertNotIn('new-test-only-password',str(run.call_args.args[0]));self.assertIn('new-test-only-password',run.call_args.args[1])
 def test_terminal_requires_interactive_password_and_service_allowlist(self):
  with patch.object(cli.sys.stdin,'isatty',return_value=False):
   with self.assertRaises(RuntimeError):cli.password('bot')
  with self.assertRaises(RuntimeError):cli.perform('restart','injected;command')
 def test_installer_installs_persistent_hook_cli_and_repairs_existing_bot(self):
  source=(ROOT/'install.sh').read_text();self.assertIn('install -m 0755 "$APP/alireza-cli.sh" /usr/local/bin/alireza',source);self.assertIn('"operation":"upgrade-ui"',source);self.assertIn('"operation":"repair-web"',source);self.assertIn('ExecStartPre=+/usr/bin/python3 /opt/alirezaserver/xray-access.py --before-start',(ROOT/'addon/xray-access.py').read_text());self.assertNotIn('User=root',(ROOT/'addon/xray-access.py').read_text())
if __name__=='__main__':unittest.main()
