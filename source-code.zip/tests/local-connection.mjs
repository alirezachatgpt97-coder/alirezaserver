// Real pinned Nova API/SQLite; no systemd, CA, Telegram or VPS mutation.
import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';
const dir=path.resolve(process.env.NOVA_TEST_DIR||'../nova-native'),root=fs.mkdtempSync(path.resolve(process.env.TMPDIR||'.')+'/local-connection-');
Object.assign(process.env,{ALIREZA_NOVA_DIR:dir,ALIREZA_ROOT:root,NOVA_DB:root+'/nova.db',NOVA_NO_EXEC:'1',NOVA_XRAY_CONFIG:root+'/xray/config.json',NOVA_SINGBOX_CONFIG:root+'/sing/config.json',NOVA_CERT_PEM:root+'/origin.pem',NOVA_CERT_KEY:root+'/origin.key'});
await import('../addon/preload.mjs');
const {openKv}=await import(pathToFileURL(dir+'/src/kv/sqlite.mjs'));const {getSettings,putSettings,createServer,runDomainJob}=await import(pathToFileURL(dir+'/src/server.mjs'));const auth=await import(pathToFileURL(dir+'/src/auth.mjs'));
const kv=openKv(process.env.NOVA_DB);await auth.setPassword(kv,'local-only-test-password');await putSettings(kv,{...await getSettings(kv),host:'8.8.8.8',insecure:true,panelPath:'test'});
const server=createServer(kv,{managerOpts:{exec:false}});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const {nativeClient}=await import('../addon/native-client.mjs');const{createBridge}=await import('../addon/bot-bridge.mjs');const api=nativeClient(server.address().port,'/test'),bridge=createBridge(api);
test('Local bot creates legacy inbound account and supplies native configs without public self-fetch',async()=>{
 const r=await bridge.request('/panel/api/clients/add','POST',{client:{email:'local-test',subId:'a'.repeat(48)},inboundIds:[]});
 assert.equal(r.success,true);assert.ok(r.obj.configs.length);const u=new URL(r.obj.configs[0]);assert.equal(u.hostname,'8.8.8.8');assert.equal(u.searchParams.get('security'),'tls');assert.equal(u.searchParams.get('type'),'ws');
 const stored=JSON.parse(fs.readFileSync(root+'/xray/config.json'));const inbound=stored.inbounds.find(i=>i.tag==='vless-ws');assert.equal(u.searchParams.get('path'),inbound.streamSettings.wsSettings.path);
 assert.ok(inbound.settings.clients.some(c=>c.id===u.username));
 assert.equal(await bridge.subscription('a'.repeat(48)),r.obj.subscriptionUrl);
});
test('Product geoExits opt-in is persisted per native user and preserved by ordinary changes',async()=>{
 for(const [name,flag] of [['geo-on',true],['geo-off',false]]){
  const r=await bridge.request('/panel/api/clients/add','POST',{client:{email:name,geoExits:flag},inboundIds:[]});assert.equal(r.success,true);assert.equal(r.obj.client.geoExits,flag);
  const user=(await getSettings(kv)).users.find(u=>u.name===name);assert.equal(user.geoExits,flag);
 }
 await bridge.request('/panel/api/clients/update/geo-on','POST',{client:{totalGB:123456}});
 assert.equal((await bridge.request('/panel/api/clients/get/geo-on')).obj.client.geoExits,true);
 assert.equal((await bridge.request('/panel/api/clients/get/geo-off')).obj.client.geoExits,false);
 await assert.rejects(bridge.request('/panel/api/clients/add','POST',{client:{email:'bad-geo',geoExits:'false'},inboundIds:[]}),/INVALID_GEO_EXITS/);
 assert.ok(!(await getSettings(kv)).users.find(u=>u.name==='bad-geo'));
});
test('Native domain transaction preserves origin for direct configs and rolls back on runtime failure',async()=>{
 for(const fail of [false,true]){
  const previous=await getSettings(kv),domain=fail?'bad.example.com':'panel.example.com',jobId='local-job-'+(fail?'bad':'good');
  await kv.put('domain:status',JSON.stringify({state:'provisioning',jobId,startedAt:Date.now()}));let restored=false;
  await runDomainJob(kv,{managerOpts:{exec:false}},{domain,method:'letsencrypt',jobId},{provision:async()=>{},captureState:()=>({}),restoreState:async()=>{restored=true;return true;},apply:async()=>{},resolveXrayOpts:async()=>({}),verifyRuntime:async s=>{if(fail&&s.host===domain)throw Error('simulated runtime failure');}});
  const after=await getSettings(kv),status=JSON.parse(await kv.get('domain:status'));
  if(fail){assert.equal(after.host,previous.host);assert.equal(status.state,'error');assert.equal(restored,true);}else{assert.equal(after.host,domain);assert.equal(after.directHost,'8.8.8.8');assert.equal(status.state,'active');}
 }
});
test('Bot subscription follows current canonical domain; rotation and removal revoke old links',async()=>{
 const current=await bridge.subscription('a'.repeat(48));assert.equal(new URL(current).hostname,'panel.example.com');
 const r=await bridge.request('/panel/api/clients/get/local-test');assert.ok(r.obj.configs.length);assert.equal(r.obj.subscriptionUrl,current);
 await bridge.request('/panel/api/clients/update/local-test','POST',{client:{subId:'b'.repeat(48)}});assert.equal(await bridge.subscription('a'.repeat(48)),null);assert.ok(await bridge.subscription('b'.repeat(48)));
 await bridge.request('/panel/api/clients/update/local-test','POST',{client:{enable:false}});assert.equal(await bridge.subscription('b'.repeat(48)),null);
 await bridge.request('/panel/api/clients/del/local-test','POST',{});assert.equal(await bridge.subscription('b'.repeat(48)),null);
});
test('Instance endpoint contains no session or account data and rejects wrong mounts',async()=>{const r=await fetch('http://127.0.0.1:'+server.address().port+'/test/alireza/api/instance');assert.equal(r.status,200);const value=await r.json();assert.deepEqual(Object.keys(value).sort(),['instance','product']);assert.match(value.instance,/^[a-f0-9]{48}$/);assert.equal(value.product,'alirezaserver');});
test.after(async()=>{server.closeAllConnections();await new Promise(r=>server.close(r));kv.close();fs.rmSync(root,{recursive:true,force:true});});
