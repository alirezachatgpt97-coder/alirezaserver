import hashlib,pathlib,json,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Preservation(unittest.TestCase):
 def test_protocol_tls_dns_and_updater_are_preserved(self):
  data=json.loads((ROOT/'docs/RC15-BASELINE.json').read_text())
  allowed=json.loads((ROOT/'docs/RC16-BASELINE.json').read_text())['modifiedRuntimeFiles']
  for name,digest in data['protectedFiles'].items():
   if name in allowed:continue
   self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
  for name in ['addon/update.py','addon/endpoint-identity.mjs','addon/tls-core.mjs','addon/tls-coordinator.mjs','addon/xray-access.py','addon/manual-core.js','addon/host-core.mjs','addon/bot-bridge.mjs']:
   self.assertIn(name,data['protectedFiles'])
 def test_removed_sections_are_not_injected(self):
  pre=(ROOT/'addon/preload.mjs').read_text();brand=(ROOT/'addon/brand.js').read_text();bot=(ROOT/'addon/bot-ui.js').read_text()
  self.assertNotIn('<script src="${base}/alireza/hosts/ui.js',pre)
  self.assertNotIn("b.dataset.azKind='hosts'",brand);self.assertNotIn("b.dataset.azKind='sales'",brand);self.assertNotIn("base+'shop/",bot)
  self.assertIn("if(route.startsWith('shop/'))",pre)
if __name__=='__main__':unittest.main()
