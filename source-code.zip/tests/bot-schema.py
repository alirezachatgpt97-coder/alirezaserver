import base64,contextlib,fcntl,hashlib,importlib.util,io,json,pathlib,re,tarfile,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('bot_schema',ROOT/'addon/bot_schema.py');schema=importlib.util.module_from_spec(spec);spec.loader.exec_module(schema)
class BotSchema(unittest.TestCase):
 def test_preferred_source_matches_both_embedded_payload_and_helper(self):
  source=(ROOT/'core/alirezabot/db/migrations/013_alirezaserver_product_schema.php').read_bytes()
  self.assertEqual(source,(ROOT/'addon/bot-product-schema.php').read_bytes())
  payload=base64.b64decode((ROOT/'addon/alirezabot-source.tar.b64').read_bytes())
  self.assertEqual(hashlib.sha256(payload).hexdigest(),json.loads((ROOT/'addon/reference-versions.json').read_text())['bot']['packagedSHA256'])
  with tarfile.open(fileobj=io.BytesIO(payload))as archive:
   self.assertEqual(archive.extractfile('db/migrations/013_alirezaserver_product_schema.php').read(),source)
   for member in archive.getmembers():
    if member.isfile():self.assertEqual(archive.extractfile(member).read(),(ROOT/'core/alirezabot'/member.name).read_bytes(),member.name)
 def test_runtime_modules_are_embedded_exactly(self):
  s=(ROOT/'install.sh').read_text();embedded={m[1]:m[3]+'\n'for m in re.finditer(r'cat > "\$APP/([^"\n]+)" <<\x27([^\x27]+)\x27\n(.*?)\n\2\n',s,re.S)}
  for name in ['bot_schema.py','bot-product-schema.php','bot-schema-tool.php','bot-manager.py']:self.assertEqual(embedded[name],(ROOT/'addon'/name).read_text(),name)
 def test_installer_handles_existing_db_and_fresh_bootstrap(self):
  s=(ROOT/'addon/bot-manager.py').read_text()
  self.assertLess(s.index('repair_schema(APP,STATE,already_locked=True,allow_missing=True)'),s.index("require 'db/bootstrap.php'"))
  self.assertGreater(s.index('    verify_schema(APP)'),s.index("require 'db/bootstrap.php'"))
  source=(ROOT/'install.sh').read_text().split('STAGE=terminal-management\ninstall -m 0755')[1]
  self.assertLess(source.index('"repair-schema"'),source.index('"upgrade-ui"'))
 def test_all_protected_rc9_files_remain_byte_identical(self):
  data=json.loads((ROOT/'docs/RC10-BASELINE.json').read_text())
  scope=json.loads((ROOT/'docs/RC12-BASELINE.json').read_text());allowed=scope['modifiedRuntimeFiles']+scope['modifiedTests']+json.loads((ROOT/'docs/RC13-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC14-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC15-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC16-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC16-BASELINE.json').read_text())['modifiedTests']+json.loads((ROOT/'docs/RC15-BASELINE.json').read_text())['modifiedTests']+json.loads((ROOT/'docs/RC14-BASELINE.json').read_text())['modifiedTests']
  allowed+=json.loads((ROOT/'docs/RC17-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC17-BASELINE.json').read_text())['modifiedTests']
  for name,digest in data['protectedFiles'].items():
   if name in allowed:continue
   if name in ['addon/update.py','addon/host-hooks.mjs','addon/compat-check.mjs','addon/preload.mjs','tests/native.mjs','tests/regressions.py','tests/release-integrity.py']:continue # reviewed rc.11 updater-only integration changes
   self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
 def test_reject_relative_and_symlink_paths(self):
  with self.assertRaisesRegex(RuntimeError,'ABSOLUTE_PATH'):schema.safe_path(pathlib.Path('relative'))
  with tempfile.TemporaryDirectory()as temp:
   p=pathlib.Path(temp);(p/'real').mkdir();(p/'link').symlink_to(p/'real',target_is_directory=True)
   with self.assertRaisesRegex(RuntimeError,'SYMLINK'):schema.safe_path(p/'link/file')
 def test_existing_install_lock_is_respected(self):
  with tempfile.TemporaryDirectory()as temp:
   p=pathlib.Path(temp)
   with (p/'.operation.lock').open('a')as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    with self.assertRaisesRegex(RuntimeError,'BOT_BUSY'):
     with schema.operation_lock(p,False):self.fail('Overlapping schema operation allowed')
if __name__=='__main__':unittest.main(verbosity=2)
