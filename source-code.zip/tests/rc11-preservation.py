import unittest,pathlib,json,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Preserve(unittest.TestCase):
 def test_rc10_protocols_bot_dns_ui_and_optimizations_unchanged(self):
  data=json.loads((ROOT/'docs/RC11-BASELINE.json').read_text())
  for name,digest in data['protectedFiles'].items():self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
if __name__=='__main__':unittest.main()
