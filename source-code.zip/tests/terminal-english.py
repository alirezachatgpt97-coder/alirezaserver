import importlib.util,pathlib,unittest,io,contextlib
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('english_cli',ROOT/'addon/alireza.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class English(unittest.TestCase):
 def test_no_persian_interface_literals_and_menu_exits_cleanly(self):
  self.assertFalse(any('\u0600'<=c<='\u06ff' for c in (ROOT/'addon/alireza.py').read_text()))
  out=io.StringIO()
  with patch('builtins.input',return_value='0'),contextlib.redirect_stdout(out):m.menu()
  text=out.getvalue();self.assertIn('TLS certificate setup',text);self.assertIn('SERVER CONTROL',text);self.assertIn('Reset bot password',text);self.assertNotIn('\x1b',text)
 def test_no_shell_and_no_token_argv(self):
  source=(ROOT/'addon/alireza.py').read_text();self.assertNotIn('shell=True',source);self.assertIn("getpass.getpass('Cloudflare API token",source);self.assertIn('input=json.dumps(value)',source)
 def test_tls_and_renewal_are_embedded_and_private(self):
  source=(ROOT/'install.sh').read_text();self.assertIn('STAGE=trusted-tls',source);self.assertIn('alireza-cert-renew.timer',source);self.assertIn('"operation":"auto"',source)
  runtime=(ROOT/'addon/tls-runtime.py').read_text();self.assertIn("VERSION='5.8.0'",runtime);self.assertIn("'--only-binary=:all:'",runtime)
if __name__=='__main__':unittest.main()
