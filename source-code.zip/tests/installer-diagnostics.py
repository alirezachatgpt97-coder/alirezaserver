import pathlib,tempfile,subprocess,json,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Diagnostics(unittest.TestCase):
 def run_cleanup(self,code,verify=False):
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d);work=root/'work';work.mkdir();log=root/'install.log'
   if verify:(work/'verify.log').write_text('Integration verification FAILED: test fixture\n')
   source=(ROOT/'install.sh').read_text();cleanup=source[source.index('cleanup(){'):source.index('trap cleanup EXIT')]
   script='set -Eeuo pipefail\nINSTALL_LOG="$1/install.log";WORK="$1/work";ROOT="$1";STAGE=integration-verification;FAIL_LINE=123;HOOK_CHANGED=0;MANAGED=1\nsystemctl(){ printf "Id=nova-agent.service\\nActiveState=active\\n"; };\n'+cleanup+'\ntrap cleanup EXIT\nexit '+str(code)+'\n'
   r=subprocess.run(['bash','-c',script,'test',d],capture_output=True,text=True)
   self.assertEqual(r.returncode,code,r.stderr)
   if code:
    v=json.loads((root/'last-failure.json').read_text());self.assertEqual(v['stage'],'integration-verification');self.assertEqual(v['exitCode'],code);self.assertEqual(v['line'],123);self.assertEqual((root/'last-failure.json').stat().st_mode&0o777,0o600);self.assertEqual((root/'failed-stage').read_text().strip(),'integration-verification');self.assertIn('ActiveState=active',(root/'install.log.services').read_text())
    if verify:self.assertIn('FAILED',(root/'install.log.verify').read_text())
   else:self.assertFalse((root/'last-failure.json').exists())
   self.assertFalse(work.exists())
 def test_failure_preserves_error_status_and_private_verifier_evidence(self):self.run_cleanup(17,True)
 def test_success_does_not_create_failure_metadata(self):self.run_cleanup(0)
if __name__=='__main__':unittest.main()
