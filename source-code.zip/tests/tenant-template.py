import pathlib,unittest,importlib.util
ROOT=pathlib.Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('tm',ROOT/'addon/tenant-manager.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class TenantTemplate(unittest.TestCase):
 def test_complete_mirza_template_is_isolated(self):
  a=m.module_for('a'*24);b=m.module_for('b'*24)
  self.assertNotEqual(a['APP'],b['APP']);self.assertNotEqual(a['STATE'],b['STATE']);self.assertTrue(all('azb'+'a'*20 in n for n in a['UNITS']))
  source=m.render_source('a'*24)
  self.assertIn('Environment=ALIREZABOT_STATE=/var/lib/azb'+'a'*20,source)
  self.assertIn("HERE/'alirezabot-source.tar.b64'",source)
  self.assertNotIn('/opt/alirezabot',source);self.assertNotIn('/var/lib/alirezabot',source);self.assertNotIn('/run/alirezabot',source)
  self.assertIn('GRANT ALL ON azb'+'a'*20+'.*',source)
  self.assertIn('env[ALIREZABOT_STATE]=/var/lib/azb'+'a'*20,source);self.assertIn("shutil.chown(path,user='root'",source);self.assertIn("['storage','log','lang/override']",source);self.assertIn('os.O_NOFOLLOW', (ROOT/'addon/tenant-manager.py').read_text());self.assertIn('pm=ondemand',source);self.assertIn('pm.max_children=3',source)
 def test_ids_cannot_inject_paths_sql_or_python(self):
  for value in ['owner','../x','a'*23+';','x'*24,'a'*25]:
   with self.assertRaises(RuntimeError):m.module_for(value)
if __name__=='__main__':unittest.main()
