import importlib.util,pathlib,socket,threading,unittest,unittest.mock,base64,hashlib
import paramiko,tempfile,subprocess
spec=importlib.util.spec_from_file_location('remote',pathlib.Path(__file__).resolve().parents[1]/'addon/bot-remote-ssh.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
class PasswordServer(paramiko.ServerInterface):
 calls=0
 def check_auth_password(self,user,password):
  type(self).calls+=1
  return paramiko.AUTH_SUCCESSFUL if user=='root' and password=='unit-test-password' else paramiko.AUTH_FAILED
 def get_allowed_auths(self,user):return 'password'
class SSH(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.key=paramiko.RSAKey.generate(2048);cls.sock=socket.socket();cls.sock.bind(('127.0.0.1',0));cls.sock.listen();cls.port=cls.sock.getsockname()[1];cls.stopped=False
  def accept():
   while not cls.stopped:
    try:c,_=cls.sock.accept()
    except OSError:return
    def serve(c):
     t=paramiko.Transport(c);t.add_server_key(cls.key)
     try:t.start_server(server=PasswordServer());t.join(3)
     except (EOFError,paramiko.SSHException):pass
     finally:t.close()
    threading.Thread(target=serve,args=(c,),daemon=True).start()
  threading.Thread(target=accept,daemon=True).start()
 def connection(self,**v):
  real=socket.create_connection;resolve=socket.getaddrinfo
  with unittest.mock.patch.object(mod.socket,'getaddrinfo',side_effect=lambda host,*args,**kw:[(socket.AF_INET,socket.SOCK_STREAM,6,'',('8.8.8.8',0))] if host=='remote.invalid' else resolve(host,*args,**kw)),unittest.mock.patch.object(mod.socket,'create_connection',side_effect=lambda address,timeout:real(('127.0.0.1',self.port),timeout)):
   return mod.connect({'host':'remote.invalid','sshPort':22,'username':'root',**v})
 def test_probe_real_ssh_hostkey_without_authentication(self):
  before=PasswordServer.calls;r=self.connection(operation='probe');self.assertEqual(r['fingerprint'],'SHA256:'+base64.b64encode(hashlib.sha256(self.key.asbytes()).digest()).decode().rstrip('='));self.assertEqual(PasswordServer.calls,before)
 def test_changed_fingerprint_is_rejected_before_password(self):
  before=PasswordServer.calls
  with self.assertRaisesRegex(RuntimeError,'FINGERPRINT_CHANGED'):self.connection(fingerprint='wrong',password='unit-test-password')
  self.assertEqual(PasswordServer.calls,before)
 def test_real_password_authentication_after_fingerprint(self):
  fp=self.connection(operation='probe')['fingerprint'];r=self.connection(fingerprint=fp,password='unit-test-password');self.assertTrue(r[0].is_authenticated());r[0].close();r[1].close()
 def test_openssh_known_host_uses_default_and_custom_port_names(self):
  for port in [22,2222]:
   with tempfile.TemporaryDirectory() as d:
    p=pathlib.Path(d)/'known_hosts';name=mod.known_name('8.8.8.8',port);p.write_text(name+' '+self.key.get_name()+' '+self.key.get_base64()+'\n');result=subprocess.run(['ssh-keygen','-F',name,'-f',str(p)],capture_output=True,text=True);self.assertEqual(result.returncode,0);self.assertEqual(name,'8.8.8.8' if port==22 else '[8.8.8.8]:2222')
 def test_invalid_hostname_refused(self):
  with self.assertRaisesRegex(RuntimeError,'HOST_INVALID'):mod.connect({'host':'$(id)'})
 @classmethod
 def tearDownClass(cls):cls.stopped=True;cls.sock.close()
if __name__=='__main__':unittest.main()
