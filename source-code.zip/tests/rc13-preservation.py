import unittest,pathlib,json,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Preserve(unittest.TestCase):
 def test_update_changes_preserve_ssl_bot_country_exits_protocols_dns_and_ui(self):
  data=json.loads((ROOT/'docs/RC13-BASELINE.json').read_text())
  for name,digest in data['protectedFiles'].items():self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
  for name in ['addon/bot-bridge.mjs','addon/preload.mjs','addon/host-hooks.mjs','addon/endpoint-identity.mjs','addon/tls-core.mjs','addon/theme.css','core/alirezabot/panel/product.php']:self.assertIn(name,data['protectedFiles'])
if __name__=='__main__':unittest.main()
