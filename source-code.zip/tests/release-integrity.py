import pathlib,json,hashlib,base64,tarfile,io,re,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Integrity(unittest.TestCase):
 def test_unrelated_addons_match_authoritative_embedded_rc3_payload(self):
  base=json.loads((ROOT/'docs/RC4-BASELINE.json').read_text())
  allowed=json.loads((ROOT/'docs/RC12-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC13-BASELINE.json').read_text())['modifiedRuntimeFiles']
  for name,digest in base['addonFiles'].items():
   if 'addon/'+name in allowed:continue
   if name not in base['modifiedExisting']+['compat-check.mjs','host-hooks.mjs','preload.mjs','update.py']:self.assertEqual(hashlib.sha256((ROOT/'addon'/name).read_bytes()).hexdigest(),digest,name)
 def test_preferred_carrier_source_is_included_and_unchanged(self):
  with tarfile.open(fileobj=io.BytesIO(base64.b64decode((ROOT/'addon/hashem-source.tar.b64').read_bytes()))) as t:
   files=[p for p in (ROOT/'core/hashem').rglob('*') if p.is_file()];self.assertGreater(len(files),5)
   for p in files:self.assertEqual(t.extractfile('hashem-carrier/'+p.relative_to(ROOT/'core/hashem').as_posix()).read(),p.read_bytes())
 def test_new_verifier_and_diagnostics_are_embedded_exactly(self):
  source=(ROOT/'install.sh').read_text();files={m[1]:m[3]+'\n' for m in re.finditer(r'cat > "\$APP/([^"\n]+)" <<\x27([^\x27]+)\x27\n(.*?)\n\2\n',source,re.S)}
  for name in ['verify-install.mjs','verify-inbounds.mjs','install-diagnostics.sh']:self.assertEqual(files[name],(ROOT/'addon'/name).read_text())
if __name__=='__main__':unittest.main()
