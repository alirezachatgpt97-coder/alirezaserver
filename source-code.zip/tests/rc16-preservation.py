import pathlib,hashlib,json,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Preserve(unittest.TestCase):
 def test_only_bulk_access_and_its_scoped_mirza_ui_change(self):
  d=json.loads((ROOT/'docs/RC16-BASELINE.json').read_text())
  for name,sha in d['protectedFiles'].items():
   if name in json.loads((ROOT/'docs/RC17-BASELINE.json').read_text())['modifiedRuntimeFiles']:continue
   self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),sha,name)
  for name in ['addon/update.py','addon/tls-core.mjs','addon/tls-coordinator.mjs','addon/endpoint-identity.mjs','addon/bot-bridge.mjs','addon/bot.mjs','addon/panel-account.mjs','addon/tenant-bot.mjs','addon/tenant-manager.py','addon/manual-core.js','addon/host-core.mjs','addon/theme.css']:
   self.assertIn(name,d['protectedFiles'])
 def test_reseller_styles_and_bulk_api_have_explicit_owner_scope(self):
  css=(ROOT/'core/alirezabot/panel/css/alireza-appearance.css').read_text().split('/* rc16:')[1]
  self.assertIn('.az-reseller',css);self.assertIn('overflow-wrap:anywhere',css);self.assertIn('input[type=checkbox]',css)
  php=(ROOT/'core/alirezabot/panel/reseller.php').read_text();self.assertLess(php.index('require_auth()'),php.index("'bulk-'"));self.assertLess(php.index("'Owner only."),php.index("'bulk-'"));self.assertIn('csrf_check_post()',php)
if __name__=='__main__':unittest.main()
