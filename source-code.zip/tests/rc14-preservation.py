import hashlib,importlib.util,json,pathlib,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Preservation(unittest.TestCase):
 def test_protected_runtime_is_unchanged(self):
  data=json.loads((ROOT/'docs/RC14-BASELINE.json').read_text())
  allowed=json.loads((ROOT/'docs/RC15-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC16-BASELINE.json').read_text())['modifiedRuntimeFiles']
  allowed=list(allowed)+json.loads((ROOT/'docs/RC17-BASELINE.json').read_text())['modifiedRuntimeFiles']
  for name,digest in data['protectedFiles'].items():
   if name in allowed:continue
   self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
  for name in ['addon/endpoint-identity.mjs','addon/tls-core.mjs','addon/host-core.mjs','addon/manual-core.js','addon/xray-access.py','addon/theme.css']:
   self.assertIn(name,data['protectedFiles'])
 def test_current_installer_identity_matches_known_compatibility_profile(self):
  source=(ROOT/'install.sh').read_text();profiles=json.loads((ROOT/'addon/compat-profiles.json').read_text());self.assertIn('c72fed38575e682ea44ad63e6e755acaa9c1f765',source);self.assertIn('f650eb8aae659a8519096e338cfca1464a618b8f2b639419fcdfc1e0926a89c7',source);self.assertIn('1.92.3',json.dumps(profiles));self.assertIn('Environment=ALIREZA_SHOP_WORKER=1',source)
 def test_runtime_security_baselines_reject_older_release(self):
  spec=importlib.util.spec_from_file_location('runtime_upgrade',ROOT/'addon/runtime-upgrade.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  for v in [(24,22,0),(22,23,3),(26,12,0)]:self.assertFalse(m.node_safe(v))
  for v in [(24,22,1),(26,12,1)]:self.assertTrue(m.node_safe(v))
  for v in [(8,2,34),(8,3,35),(8,4,26),(8,5,11)]:self.assertFalse(m.php_safe(v))
  for v in [(8,2,35),(8,3,36),(8,4,27),(8,5,12)]:self.assertTrue(m.php_safe(v))
if __name__=='__main__':unittest.main()
