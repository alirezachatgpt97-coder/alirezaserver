import unittest,pathlib,json,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Preserve(unittest.TestCase):
 def test_only_product_opt_in_changes_runtime(self):
  data=json.loads((ROOT/'docs/RC12-BASELINE.json').read_text())
  allowed=json.loads((ROOT/'docs/RC13-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC14-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC15-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC16-BASELINE.json').read_text())['modifiedRuntimeFiles']+json.loads((ROOT/'docs/RC16-BASELINE.json').read_text())['modifiedTests']+json.loads((ROOT/'docs/RC15-BASELINE.json').read_text())['modifiedTests']
  allowed=list(allowed)+json.loads((ROOT/'docs/RC17-BASELINE.json').read_text())['modifiedRuntimeFiles']
  for name,digest in data['protectedFiles'].items():
   if name in allowed:continue
   self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
  for name in ['addon/update.py','addon/preload.mjs','addon/host-core.mjs','addon/endpoint-identity.mjs','addon/tls-core.mjs','addon/theme.css']:
   self.assertIn(name,data['protectedFiles'])
if __name__=='__main__':unittest.main()
