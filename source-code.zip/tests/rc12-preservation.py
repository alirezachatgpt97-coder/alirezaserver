import unittest,pathlib,json,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Preserve(unittest.TestCase):
 def test_only_product_opt_in_changes_runtime(self):
  data=json.loads((ROOT/'docs/RC12-BASELINE.json').read_text())
  for name,digest in data['protectedFiles'].items():self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
  for name in ['addon/update.py','addon/preload.mjs','addon/host-core.mjs','addon/endpoint-identity.mjs','addon/tls-core.mjs','addon/theme.css']:
   self.assertIn(name,data['protectedFiles'])
if __name__=='__main__':unittest.main()
