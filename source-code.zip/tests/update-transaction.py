import importlib.util,pathlib,tempfile,unittest,json,os
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('update',ROOT/'addon/update.py');u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u)
class Updates(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.p=pathlib.Path(self.temp.name)
  self.patches=[]
  values={'ROOT':self.p/'state','NOVA':self.p/'nova','BACKUPS':self.p/'backups','APP':ROOT/'addon','DATA':[self.p/f'data{i}' for i in range(6)],'SOURCE':self.p/'state/source.json','STATE':self.p/'state/status.json','NATIVE':self.p/'native-status','JOURNAL':self.p/'state/pending.json'}
  for k,v in values.items():
   p=patch.object(u,k,v);p.start();self.addCleanup(p.stop)
  u.NOVA.mkdir();(u.NOVA/'package.json').write_text('{"version":"1.85.4"}')
  for d in u.DATA:d.mkdir();(d/'secret').write_text('original');(d/'secret').chmod(0o640)
  self.candidate=self.p/'candidate';self.candidate.mkdir();(self.candidate/'package.json').write_text('{"version":"1.91.1"}')
 def test_success_and_snapshot_permissions(self):
  with patch.object(u,'health'),patch.object(u,'retry_health'),patch.object(u,'run'):
   u.activate(self.candidate,{'version':'1.91.1'})
  self.assertFalse(u.JOURNAL.exists());self.assertEqual(json.loads((u.NOVA/'package.json').read_text())['version'],'1.91.1')
  b=next(u.BACKUPS.iterdir());self.assertEqual((b/'data-4/secret').stat().st_mode&0o777,0o640);self.assertEqual((b/'data-4/secret').stat().st_gid,(u.DATA[4]/'secret').stat().st_gid)
 def test_failed_health_restores_config_certificates_and_code(self):
  calls=[]
  def fail():
   calls.append(1)
   if len(calls)==1:
    for d in u.DATA:(d/'secret').write_text('new broken config')
    raise RuntimeError('simulated health failure')
  with patch.object(u,'health'),patch.object(u,'retry_health',side_effect=fail),patch.object(u,'run'),patch.object(u,'runtime_ready') as repair:
   with self.assertRaises(u.RejectedUpdate):u.activate(self.candidate,{'version':'1.91.1'})
   repair.assert_called_once()
  for d in u.DATA:self.assertEqual((d/'secret').read_text(),'original')
  self.assertEqual(json.loads((u.NOVA/'package.json').read_text())['version'],'1.85.4');self.assertFalse(u.JOURNAL.exists())
 def test_unknown_journal_paths_rejected(self):
  with self.assertRaises(RuntimeError):u.snapshot_paths({'dataPaths':['/arbitrary']})
 def test_legacy_snapshot_does_not_remove_new_config_paths(self):
  self.assertEqual(u.snapshot_paths({}),u.DATA[:4])
 def test_rejection_retried_after_guard_change(self):
  previous={'rejected':True,'commit':'a','guardFingerprint':u.guard_fingerprint()}
  self.assertTrue(u.rejected_before(previous,'a'))
  with patch.object(u,'guard_fingerprint',return_value='changed'):self.assertFalse(u.rejected_before(previous,'a'))
 def test_failure_status_has_reason_and_exact_stage(self):
  u.status(None,'compatibility-check')
  u.record_failure(u.RejectedUpdate('NOVA_BEHAVIOR_CONTRACT_FAILED: broken server'),'abc')
  data=json.loads(u.STATE.read_text());self.assertEqual(data['code'],26);self.assertEqual(data['reason'],'UPSTREAM_CONTRACT_CHANGED');self.assertEqual(data['failedStage'],'compatibility-check');self.assertIn('broken server',data['message'])
 def test_long_javascript_stack_keeps_the_actual_error(self):
  import subprocess
  output='minified source '*500+'\nError: NOVA_BAD_CONTRACT: real cause\n'+'    at stack\n'*200
  with patch.object(u.subprocess,'run',side_effect=subprocess.CalledProcessError(1,'node',output=output)):
   with self.assertRaisesRegex(RuntimeError,'NOVA_BAD_CONTRACT: real cause'):u.run(['node','compat-check.mjs'])
 def test_committed_update_is_successful_when_cleanup_fails(self):
  original=u.shutil.rmtree
  def cleanup(path,*args,**kwargs):
   if path==u.NOVA.with_name('.alireza-previous'):raise OSError('cleanup unavailable')
   return original(path,*args,**kwargs)
  with patch.object(u,'health'),patch.object(u,'retry_health'),patch.object(u,'run'),patch.object(u.shutil,'rmtree',side_effect=cleanup):u.activate(self.candidate,{'version':'1.91.1'})
  self.assertTrue(json.loads(u.STATE.read_text())['ok']);self.assertFalse(u.JOURNAL.exists());self.assertIn('warning',json.loads(u.STATE.read_text()))
if __name__=='__main__':unittest.main(verbosity=2)
