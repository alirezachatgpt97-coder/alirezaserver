import pathlib,hashlib,json,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Preservation(unittest.TestCase):
 def test_all_unchanged_files_match_authoritative_rc16(self):
  d=json.loads((ROOT/'docs/RC17-BASELINE.json').read_text())
  for n,digest in d['protectedFiles'].items():self.assertEqual(hashlib.sha256((ROOT/n).read_bytes()).hexdigest(),digest,n)
  for n in ['addon/update.py','addon/tls-core.mjs','addon/tls-coordinator.mjs','addon/xray-access.py','addon/host-core.mjs','addon/manual-core.js','addon/endpoint-identity.mjs','addon/firewall.py','addon/theme.css','core/alirezabot/panel/reseller.php','addon/inbound-bulk.mjs']:
   self.assertIn(n,d['protectedFiles'])
 def test_latest_base_has_matching_official_release_identity(self):
  s=(ROOT/'install.sh').read_text();self.assertIn('NOVA_COMMIT=3b19813ee96591d491eb1dd3030cff0f26e77b98',s);self.assertIn('NOVA_AGENT_SHA=8668c40e0721f7ff861c06b32bf0e1a5605c2b4d93f8ca2821be5bf5a5310722',s)
if __name__=='__main__':unittest.main()
