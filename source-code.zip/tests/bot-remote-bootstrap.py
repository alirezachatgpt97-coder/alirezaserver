import ast,pathlib,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Bootstrap(unittest.TestCase):
 def test_embedded_remote_python_compiles_and_has_instance_and_os_guards(self):
  tree=ast.parse((ROOT/'addon/bot-remote-ssh.py').read_text());values=[n.value for n in ast.walk(tree) if isinstance(n,ast.Constant) and isinstance(n.value,str) and 'target=pathlib.Path' in n.value]
  self.assertEqual(len(values),1);compile(values[0],'<bootstrap>','exec');self.assertIn("marker.read_text().strip()!=v['public']",values[0]);self.assertIn('/var/lib/alirezaserver/installed.json',values[0]);self.assertIn('permitopen=',values[0]);self.assertIn('permitlisten=',values[0]);self.assertIn('command="/bin/false"',values[0])
 def test_gateway_and_tunnel_are_loopback_only(self):
  gateway=(ROOT/'addon/bot-remote-gateway.py').read_text();ssh=(ROOT/'addon/bot-remote-ssh.py').read_text();self.assertIn("(('127.0.0.1',int(CONF['port']))",gateway);self.assertIn('StrictHostKeyChecking=yes',ssh);self.assertIn('ExitOnForwardFailure=yes',ssh);self.assertIn('-R 127.0.0.1:',ssh);self.assertIn('-L 127.0.0.1:',ssh);self.assertNotIn('AutoAddPolicy',ssh)
if __name__=='__main__':unittest.main()
