import unittest,pathlib,tempfile,importlib.util,json,os
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('access',ROOT/'addon/xray-access.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Permissions(unittest.TestCase):
 def test_repair_is_targeted_preserves_contents_and_original_permissions_snapshot(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);configdir=p/'xray';configdir.mkdir(mode=0o700);config=configdir/'config.json';config.write_text('{"private":"unchanged"}');config.chmod(0o600);cert=p/'nova';cert.mkdir(mode=0o700)
   for n in ['origin.pem','origin.key']:(cert/n).write_text('existing cert');(cert/n).chmod(0o600)
   with patch.object(m,'identity',return_value=(65534,os.getgid())),patch.object(m.subprocess,'check_output',return_value=str(config)):
    m.repair(p/'state',config,cert);before=(p/'state/xray-access-before.json').read_text();m.repair(p/'state',config,cert);self.assertEqual((p/'state/xray-access-before.json').read_text(),before)
   self.assertEqual(config.read_text(),'{"private":"unchanged"}');self.assertEqual(config.stat().st_mode&0o777,0o640);self.assertEqual(configdir.stat().st_mode&0o777,0o750);self.assertEqual((cert/'origin.key').stat().st_mode&0o777,0o640);self.assertEqual((p/'state/xray-access.json').stat().st_mode&0o777,0o600)
 def test_custom_unit_config_fails_before_changing_files(self):
  with tempfile.TemporaryDirectory() as d,patch.object(m,'identity',return_value=(65534,os.getgid())),patch.object(m.subprocess,'check_output',return_value='/other/config.json'):
   p=pathlib.Path(d);c=p/'config.json';c.write_text('keep');c.chmod(0o600)
   with self.assertRaisesRegex(RuntimeError,'CUSTOM_CONFIG'):m.repair(p/'state',c,p/'nova')
   self.assertEqual(c.stat().st_mode&0o777,0o600);self.assertFalse((p/'state').exists())
if __name__=='__main__':unittest.main()
