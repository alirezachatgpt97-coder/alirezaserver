// Alirezaserver carrier-only adapter. Adapted Hashem sources retain AGPL-3.0.
package main
import("encoding/json";"fmt";"os";"os/signal";"path/filepath";"syscall";"time")
var configDir="/etc/alirezaserver-hashem/state"
func tlsCertFile()string{return filepath.Join(configDir,"cert.pem")}
func tlsKeyFile()string{return filepath.Join(configDir,"key.pem")}
type tunnelStatus struct{Role string `json:"role"`;RemotePub string `json:"remotePub"`;Gre struct{PeerIP string}}
func localStatus()tunnelStatus{var c tunnelStatus;b,_:=os.ReadFile(filepath.Join(configDir,"setup.json"));_ = json.Unmarshal(b,&c);return c}
func peerOr(s tunnelStatus)string{return s.RemotePub}
func main(){if p:=os.Getenv("GRE_PANEL_DIR");p!=""{configDir=p};if len(os.Args)>1&&os.Args[1]=="tls-proxy"{os.Exit(tlsProxyCmd(os.Args[2:]))};if len(os.Args)!=2||os.Args[1]!="carrier"{fmt.Fprintln(os.Stderr,"Usage: alireza-hashem-core carrier | tls-proxy -listen ADDR -target ADDR");os.Exit(2)};cfg:=loadWSSConfig();if !cfg.Enabled||cfg.AuthToken==""{fmt.Fprintln(os.Stderr,"WSS configuration or authentication token is missing");os.Exit(1)};if err:=startWSSCarrier(cfg);err!=nil{fmt.Fprintln(os.Stderr,"Carrier startup failed");os.Exit(1)};defer stopWSSCarrier();signals:=make(chan os.Signal,1);signal.Notify(signals,syscall.SIGTERM,syscall.SIGINT);ticker:=time.NewTicker(2*time.Second);defer ticker.Stop();for{select{case <-signals:return;case <-ticker.C:status:=getWSSStatus();if !status.Running{fmt.Fprintln(os.Stderr,"Carrier stopped unexpectedly");os.Exit(1)};b,_:=json.Marshal(status);tmp:=filepath.Join(configDir,"wss-status.json.tmp");if os.WriteFile(tmp,b,0600)==nil{_ = os.Rename(tmp,filepath.Join(configDir,"wss-status.json"))}}}}
