module alirezaserver/hashem-carrier

go 1.23

require github.com/gorilla/websocket v1.5.3

replace github.com/gorilla/websocket => ./deps/websocket
