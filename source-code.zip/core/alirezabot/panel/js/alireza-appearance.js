/* SPDX-License-Identifier: AGPL-3.0-or-later */
(function(){'use strict';
 const themes=['navy','purple','emerald','sunset','slate','light','linen','mint','lavender'];
 let value=window.AZ_APPEARANCE||{theme:'navy',accent:'',radius:16},pending=Promise.resolve();
 function paint(v){const root=document.documentElement;root.dataset.theme=v.theme;root.style.colorScheme=['light','linen','mint','lavender'].includes(v.theme)?'light':'dark';root.style.removeProperty('background-color');
  for(const k of ['--ac','--ac2']){if(v.accent)root.style.setProperty(k,v.accent,'important');else root.style.removeProperty(k);}
  root.style.setProperty('--az-custom-accent',v.accent||'#06b6d4');root.style.setProperty('--az-radius',v.radius+'px');root.dataset.customAccent=v.accent?'1':'0';
  if(v.accent){const n=parseInt(v.accent.slice(1),16),lum=(.2126*(n>>16)+.7152*((n>>8)&255)+.0722*(n&255));root.style.setProperty('--az-accent-text',lum>155?'#10121b':'#fff');}
  try{localStorage.setItem('panel-theme',v.theme);}catch{}
 }
 function message(text,bad){const el=document.querySelector('[data-az-appearance-status]');if(el){el.textContent=text;el.setAttribute('role',bad?'alert':'status');}}
 async function save(v){const response=await fetch('appearance.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({...v,_csrf:window.AZ_CSRF})});if(!response.ok)throw Error('ذخیره نشد / Save failed ('+response.status+')');return response.json();}
 window.azSelectTheme=function(t){if(!themes.includes(t))return;value={...value,theme:t};paint(value);pending=pending.catch(()=>{}).then(()=>save({...value})).then(()=>message('ذخیره شد / Saved')).catch(e=>message(e.message,true));};
 paint(value);
 document.addEventListener('DOMContentLoaded',()=>{const form=document.querySelector('[data-az-appearance]');if(!form)return;
  const accent=form.elements.accent,enabled=form.elements.custom,radius=form.elements.radius;
  accent.value=value.accent||'#06b6d4';enabled.checked=!!value.accent;radius.value=value.radius;
  form.oninput=()=>paint({...value,accent:enabled.checked?accent.value:'',radius:Number(radius.value)});
  form.onsubmit=async e=>{e.preventDefault();const button=form.querySelector('[type=submit]');button.disabled=true;try{await pending;value=await save({...value,accent:enabled.checked?accent.value:'',radius:Number(radius.value)});paint(value);message('ذخیره شد / Saved');}catch(e){message(e.message,true);}finally{button.disabled=false;}};
  form.querySelector('[data-reset]').onclick=async()=>{value={theme:'navy',accent:'',radius:16};enabled.checked=false;radius.value=16;paint(value);try{await pending;await save(value);message('پیش‌فرض ذخیره شد / Default saved');}catch(e){message(e.message,true);}};
 });
})();
