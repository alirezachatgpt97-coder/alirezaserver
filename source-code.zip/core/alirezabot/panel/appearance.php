<?php
require __DIR__.'/inc/config.php';
require_auth();
require __DIR__.'/inc/alireza_appearance.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD']==='GET') {echo json_encode(az_appearance_load());exit;}
if ($_SERVER['REQUEST_METHOD']!=='POST') {http_response_code(405);exit;}
$v=json_decode(file_get_contents('php://input'),true);
if (!is_array($v)||empty($v['_csrf'])||!csrf_check_value((string)($v['_csrf']??''))) {http_response_code(403);echo '{"error":"CSRF"}';exit;}
try {
 $clean=az_appearance_validate($v);$path=az_appearance_path();
 if (is_link($path)) throw new RuntimeException('UNSAFE_PATH');
 $tmp=tempnam(dirname($path),'.appearance-');
 if ($tmp===false) throw new RuntimeException('WRITE_FAILED');
 chmod($tmp,0600);
 if (file_put_contents($tmp,json_encode($clean),LOCK_EX)===false||!rename($tmp,$path)) { @unlink($tmp);throw new RuntimeException('WRITE_FAILED'); }
 echo json_encode($clean);
} catch (InvalidArgumentException $e) {http_response_code(400);echo '{"error":"INVALID_APPEARANCE"}';}
catch (Throwable $e) {http_response_code(500);echo '{"error":"SAVE_FAILED"}';}
