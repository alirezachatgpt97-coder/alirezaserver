<?php
// Per-admin appearance, stored outside the application payload. No arbitrary CSS.
function az_appearance_validate(array $v): array {
    $themes=['navy','purple','emerald','sunset','slate','light','linen','mint','lavender'];
    $theme=$v['theme']??'navy';$accent=$v['accent']??'';$radius=$v['radius']??16;
    if (!in_array($theme,$themes,true)||!is_string($accent)||($accent!==''&&!preg_match('/^#[0-9a-fA-F]{6}$/D',$accent))||!is_int($radius)||$radius<8||$radius>24) throw new InvalidArgumentException('INVALID_APPEARANCE');
    return ['theme'=>$theme,'accent'=>$accent,'radius'=>$radius];
}
function az_appearance_path(): string {
    $dir=getenv('ALIREZABOT_STATE')?:'/var/lib/alirezabot';
    return $dir.'/appearance-'.hash('sha256',$_SESSION['admin_user']??'').'.json';
}
function az_appearance_load(): array {
    $v=json_decode(@file_get_contents(az_appearance_path())?:'{}',true);
    try{return az_appearance_validate(is_array($v)?$v:[]);}catch(InvalidArgumentException $e){return az_appearance_validate([]);}
}
