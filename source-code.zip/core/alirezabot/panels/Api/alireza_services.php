<?php
// SPDX-License-Identifier: AGPL-3.0-or-later
function alireza_product_service(PDO $pdo, string $location, $value): ?string {
    if ($value === null || $value === '') return null;
    if ((!is_string($value) && !is_array($value)) || strlen(is_string($value)?$value:json_encode($value)) > 32768) throw new RuntimeException('BOT_SERVICE_INVALID');
    $v = is_array($value) ? $value : json_decode(html_entity_decode($value, ENT_QUOTES|ENT_HTML5, 'UTF-8'), true);
    if (!is_array($v)) throw new RuntimeException('BOT_SERVICE_INVALID');
    $q = $pdo->prepare('SELECT code_panel FROM marzban_panel WHERE name_panel=? LIMIT 1');
    $q->execute([$location]);
    if ($q->fetchColumn() !== 'alirezaserver-local') throw new RuntimeException('BOT_SERVICE_REQUIRES_MANAGED_PANEL');
    $kind = $v['kind'] ?? '';
    if ($kind === 'nova') {
        $flags = ['awg','mtproto','mieru','soar','tgweb','smartDns','smartDnsVip'];
        if (!is_array($v['grants'] ?? null) || !is_array($v['inboundIds'] ?? null) || count($v['inboundIds']) > 1000) throw new RuntimeException('BOT_SERVICE_INVALID');
        foreach ($v['grants'] as $g) if (!in_array($g, $flags, true)) throw new RuntimeException('BOT_SERVICE_INVALID');
        foreach ($v['inboundIds'] as $id) if (!is_string($id) || strlen($id)>128) throw new RuntimeException('BOT_SERVICE_INVALID');
        if (!$v['grants'] && !$v['inboundIds']) throw new RuntimeException('BOT_SERVICE_EMPTY');
        $v = ['kind'=>'nova','grants'=>array_values(array_unique($v['grants'])),'inboundIds'=>array_values(array_unique($v['inboundIds']))];
    } elseif ($kind === 'openvpn' || $kind === 'alirezadns') {
        $key = $kind === 'openvpn' ? 'serverId' : 'nodeId';
        if (!is_string($v[$key] ?? null) || !preg_match('/^[a-f0-9]{12}$/D', $v[$key])) throw new RuntimeException('BOT_SERVICE_INVALID');
        $v = ['kind'=>$kind,$key=>$v[$key]];
    } else throw new RuntimeException('BOT_SERVICE_INVALID');
    return json_encode($v, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
}
function alireza_product_catalog(PDO $pdo): array {
    require_once __DIR__.'/../../request.php';
    $q=$pdo->prepare("SELECT url_panel,password_panel FROM marzban_panel WHERE code_panel='alirezaserver-local' LIMIT 1");$q->execute();$panel=$q->fetch(PDO::FETCH_ASSOC);
    if (!$panel) throw new RuntimeException('BOT_MANAGED_PANEL_NOT_CONNECTED');
    $request = new CurlRequest(rtrim($panel['url_panel'],'/').'/panel/api/services');
    $request->setHeaders(['Accept: application/json']);$request->setBearerToken($panel['password_panel']);
    $response=$request->get();$v=json_decode($response['body']??'',true);
    if (($response['status']??0)!==200 || !($v['success']??false) || !is_array($v['obj']??null)) throw new RuntimeException('BOT_SERVICE_CATALOG_UNAVAILABLE');
    return $v['obj'];
}
function alireza_service_badge(array $product): string {
    $v=json_decode($product['az_service']??'null',true);
    if (!is_array($v)) return '';
    if (($v['kind']??'')==='openvpn') return '🔐 ';
    if (($v['kind']??'')==='alirezadns') return '🌐 ';
    return in_array('smartDns',$v['grants']??[],true)?'🧭 ':'🔌 ';
}
function alireza_renewal_matches($current,$selected): bool {
    $a=is_array($current)?$current:json_decode($current??'null',true);
    $b=is_array($selected)?$selected:json_decode($selected??'null',true);
    $ak=$a['kind']??'nova';$bk=$b['kind']??'nova';
    if ($ak!==$bk) return false;
    if ($ak==='nova') return true;
    $key=$ak==='openvpn'?'serverId':'nodeId';
    return ($a[$key]??null)===($b[$key]??null);
}

function alireza_validate_renewal($panel,string $username,$selected): bool {
    if (!is_array($panel)) return false;
    if (($panel['code_panel']??'')!=='alirezaserver-local') return true;
    require_once __DIR__.'/../../request.php';
    $r=new CurlRequest(rtrim($panel['url_panel'],'/').'/panel/api/services/validate');
    $r->setHeaders(['Accept: application/json','Content-Type: application/json']);$r->setBearerToken($panel['password_panel']);
    $spec=is_array($selected)?$selected:json_decode($selected??'null',true);
    $response=$r->post(json_encode(['username'=>$username,'service'=>$spec]));$v=json_decode($response['body']??'',true);
    return ($response['status']??0)===200 && ($v['success']??false) && ($v['obj']['valid']??false);
}
function alireza_product_limit(int $limit,$service): int {
    $v=is_array($service)?$service:json_decode(html_entity_decode($service??'null',ENT_QUOTES|ENT_HTML5,'UTF-8'),true);
    if (($v['kind']??'')==='openvpn' && ($limit<1 || $limit>64)) throw new RuntimeException('BOT_SERVICE_OPENVPN_DEVICES_1_TO_64');
    return $limit;
}
