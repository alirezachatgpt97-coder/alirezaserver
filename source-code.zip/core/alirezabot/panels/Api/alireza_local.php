<?php
// Managed local connection only; never rename or adopt a remote provider.
function alireza_sync_local(PDO $pdo, array $v): void {
    $schema = new class { public function context($name) { return null; } };
    $definition = require __DIR__ . '/../../db/tables/marzban_panel.php';
    $pdo->beginTransaction();
    try {
        $q = $pdo->prepare('SELECT id FROM marzban_panel WHERE code_panel=? FOR UPDATE');
        $q->execute(['alirezaserver-local']); $id = $q->fetchColumn();
        if (!$id) {
            $name = 'alirezaserver';
            $q = $pdo->prepare('SELECT COUNT(*) FROM marzban_panel WHERE name_panel=?');
            $q->execute([$name]);
            if ($q->fetchColumn()) $name .= '-local-' . bin2hex(random_bytes(3));
            $q = $pdo->prepare("INSERT INTO marzban_panel (code_panel,name_panel,type,status,on_hold_test,version_panel,conecton) VALUES (?,?,?,'active','0','0','offconecton')");
            $q->execute(['alirezaserver-local', $name, 'x-ui_single']); $id = $pdo->lastInsertId();
        }
        // Use the application's own schema defaults. Existing prices and choices survive.
        foreach ($definition['columns'] as [$column, $default]) {
            if ($default === null || in_array($column, ['type','code_panel'], true)) continue;
            $q = $pdo->prepare("UPDATE marzban_panel SET `$column`=? WHERE id=? AND `$column` IS NULL");
            $q->execute([$default, $id]);
        }
        $q = $pdo->prepare('UPDATE marzban_panel SET url_panel=?,password_panel=?,linksubx=?,inbounds=? WHERE id=?');
        $q->execute([$v['url'], $v['token'], $v['sub'], json_encode($v['inbounds']), $id]);
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}
