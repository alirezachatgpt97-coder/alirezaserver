<?php
// SPDX-License-Identifier: AGPL-3.0-or-later
function az_panel_h($v): string {return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function az_panel_bot(PDO $pdo,string $text,string $callback,string $buyer): bool {
 if(is_file(__DIR__.'/.alireza-tenant'))return false;
 $mine=in_array($text,['/mypanels','مدیریت پنل من','🧭 مدیریت پنل من'],true)||$callback==='az:mine'||str_starts_with($callback,'az:mp:');
 if(!$mine&&!preg_match('/^az:(info|secret|resetask|reset):[a-f0-9]{32}$/',$callback))return false;
 try{
  if($mine){$page=str_starts_with($callback,'az:mp:')?max(0,min(1000000,(int)substr($callback,6))):0;$rows=az_shop_call($pdo,'my-panels',['buyer'=>$buyer,'offset'=>$page*10])['items'];$buttons=[];foreach(array_slice($rows,0,10) as $p)$buttons[]=[['text'=>'🖥 '.$p['name'],'callback_data'=>'az:info:'.$p['id']]];$nav=[];if($page)$nav[]=['text'=>'◀️ قبلی','callback_data'=>'az:mp:'.($page-1)];if(count($rows)>10)$nav[]=['text'=>'▶️ بعدی','callback_data'=>'az:mp:'.($page+1)];if($nav)$buttons[]=$nav;$buttons[]=[['text'=>'🛍 خرید پنل','callback_data'=>'az:panels']];sendmessage($buyer,"🧭 <b>مدیریت پنل من</b>\n".($rows?'پنل مورد نظر را انتخاب کنید.':'هنوز پنل خریداری‌شده‌ای ندارید.'),json_encode(['inline_keyboard'=>$buttons]),'HTML');return true;}
  [, $op,$id]=explode(':',$callback);if($op==='resetask'){sendmessage($buyer,"🔐 <b>تغییر رمز پنل</b>\nرمز امن جدید ساخته می‌شود و ورود با رمز قبلی دیگر ممکن نیست. ادامه می‌دهید؟",json_encode(['inline_keyboard'=>[[['text'=>'✅ تغییر رمز','callback_data'=>'az:reset:'.$id]],[['text'=>'↩️ انصراف','callback_data'=>'az:info:'.$id]]]]),'HTML');return true;}
  if($op==='reset'){$r=az_shop_call($pdo,'panel-password',['buyer'=>$buyer,'id'=>$id]);$message="✅ <b>رمز جدید پنل</b>\n🔑 <tg-spoiler>".az_panel_h($r['password'])."</tg-spoiler>\nاین پیام محرمانه است؛ آن را در گروه ارسال نکنید.";}
  else{$r=az_shop_call($pdo,'panel-info',['buyer'=>$buyer,'id'=>$id,'credentials'=>$op==='secret']);$gb=fn($n)=>$n===null?'—':number_format($n/1073741824,2,'.','').' GB';$message="🖥 <b>پنل شما</b>\n👤 ".az_panel_h($r['username'])."\n🏷 نقش: ".az_panel_h($r['role'])."\n📦 سهمیه: ".$gb($r['quotaBytes'])."\n📊 باقی‌مانده: ".$gb($r['remainingBytes'])."\n👥 ظرفیت کاربران باقی‌مانده: ".az_panel_h($r['remainingUsers']??'—');if($r['role']!=='reseller')$message.="\nℹ️ این نقش مدیریتی سهمیهٔ حجمی نماینده ندارد.";if($op==='secret')$message.="\n🌐 ".az_panel_h($r['panelUrl'])."\n🔑 <tg-spoiler>".az_panel_h($r['password'])."</tg-spoiler>\nℹ️ رمز تحویلی ذخیره‌شده است؛ اگر آن را جای دیگری عوض کرده‌اید از تغییر رمز استفاده کنید.";}
  sendmessage($buyer,$message,json_encode(['inline_keyboard'=>[[['text'=>'🔄 تازه‌سازی حجم','callback_data'=>'az:info:'.$id],['text'=>'🌐 ورود به پنل','url'=>$r['panelUrl']]],[['text'=>'🔑 آدرس و رمز','callback_data'=>'az:secret:'.$id],['text'=>'🔐 تغییر رمز','callback_data'=>'az:resetask:'.$id]],[['text'=>'↩️ پنل‌های من','callback_data'=>'az:mine']]]]),'HTML');
 }catch(Throwable $e){sendmessage($buyer,'⚠️ دریافت اطلاعات کامل نشد. ممکن است پنل غیرفعال شده باشد یا ارتباط برقرار نباشد. کمی بعد دوباره تلاش کنید.',json_encode(['inline_keyboard'=>[[['text'=>'🔄 تلاش مجدد','callback_data'=>'az:mine']]]]),'HTML');}
 return true;
}
