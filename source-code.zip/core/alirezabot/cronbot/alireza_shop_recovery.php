<?php
// SPDX-License-Identifier: AGPL-3.0-or-later
// Reuse the existing dispatcher; no extra always-on PHP process.
(function () {
    if(!is_file(dirname(__DIR__).'/.alirezaserver-managed'))return;
    $cwd=getcwd();chdir(dirname(__DIR__));
    try{
        global $pdo,$APIKEY,$adminnumber,$domainhosts,$usernamebot;
        require_once 'config.php';require_once 'alireza-shop.php';require_once 'botapi.php';global $pdo;
        $exists=$pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='alireza_panel_orders'")->fetchColumn();if(!$exists)return;
        $rows=$pdo->query("SELECT * FROM alireza_panel_orders WHERE status='paid' OR (status='ready' AND delivered=0) ORDER BY attempted,created LIMIT 2")->fetchAll(PDO::FETCH_ASSOC);
        foreach($rows as $row){$q=$pdo->prepare('UPDATE alireza_panel_orders SET attempted=? WHERE id=?');$q->execute([time(),$row['id']]);try{$result=az_shop_call($pdo,'purchase',['buyer'=>$row['buyer'],'id'=>$row['id']]);if(($result['status']??'')!=='ready')continue;$q=$pdo->prepare("UPDATE alireza_panel_orders SET status='ready' WHERE id=? AND status IN ('paid','ready')");$q->execute([$row['id']]);$sent=sendmessage($row['buyer'],az_shop_message($result),null,'HTML');if(!empty($sent['ok'])){$q=$pdo->prepare('UPDATE alireza_panel_orders SET delivered=1 WHERE id=?');$q->execute([$row['id']]);}}catch(Throwable $e){/* Pending receipt retained; next run/customer retry is idempotent. */}}
    }finally{if($cwd!==false)chdir($cwd);}
})();
