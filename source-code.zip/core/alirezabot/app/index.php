<!DOCTYPE html>
<html lang="en">
  <head><base href="<?php echo htmlspecialchars(rtrim(dirname($_SERVER["SCRIPT_NAME"]),"/")."/", ENT_QUOTES, "UTF-8"); ?>">
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Alirezabot · مینی‌اپ اختصاصی فروشگاه</title>
    <script src="./js/telegram-web-app.js"></script>
    <script type="module" crossorigin src="./assets/index-C-2a0Dur.js"></script>
    <link rel="modulepreload" crossorigin href="./assets/vendor-CIGJ9g2q.js">
    <link rel="stylesheet" crossorigin href="./assets/index-BoHBsj0Z.css">
    <link rel="stylesheet" href="./assets/cyberpunk-miniapp.css">
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>