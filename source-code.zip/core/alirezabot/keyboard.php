<?php
require_once 'config.php';
require_once __DIR__.'/panels/Api/alireza_services.php';
$setting = select("setting", "*", null, null, "select");
$textbotlang = languagechange();
//-----------------------------[  text panel  ]-------------------------------
$adminrulecheck = select("admin", "*", "id_admin", $from_id, "select");
$admin_idss = $adminrulecheck ? 1 : 0;
if (!$adminrulecheck) {
    $adminrulecheck = array(
        'rule' => '',
    );
}
$users = select("user", "*", "id", $from_id, "select");
if ($users == false) {
    $users = array();
    $users = array(
        'step' => '',
        'agent' => '',
        'limit_usertest' => '',
        'Processing_value' => '',
        'Processing_value_four' => '',
        'cardpayment' => ""
    );
}
$replacements = [
    'text_usertest' => $textbotlang['textbot']['userTest'],
    'text_Purchased_services' => $textbotlang['textbot']['purchasedServices'],
    'text_support' => $textbotlang['textbot']['support'],
    'text_help' => $textbotlang['textbot']['help'],
    'accountwallet' => $textbotlang['textbot']['accountWallet'],
    'text_sell' => $textbotlang['textbot']['sell'],
    'text_Tariff_list' => $textbotlang['textbot']['tariffList'],
    'text_affiliates' => $textbotlang['textbot']['affiliates'],
    'text_wheel_luck' => $textbotlang['textbot']['wheelLuck'],
    'text_extend' => $textbotlang['textbot']['extend'],
    'text_agentpanel' => $textbotlang['textbot']['agentPanel'],
    'text_requestagent' => $textbotlang['textbot']['requestAgent']
];
$temp_addtional_key = [];
$keyboardLayout = json_decode($setting['keyboardmain'], true);
$keyboardRows = [];
if (is_array($keyboardLayout) && isset($keyboardLayout['keyboard']) && is_array($keyboardLayout['keyboard'])) {
    $keyboardRows = $keyboardLayout['keyboard'];
}

$agentPanelAllowed = $users['agent'] != "f";
$agentRequestAllowed = $users['agent'] == "f";
if (!empty($keyboardRows)) {
    $allowed_btn_styles = ['primary', 'success', 'danger'];
    foreach ($keyboardRows as $kb_r => $kb_row) {
        if (!is_array($kb_row)) {
            continue;
        }
        foreach ($kb_row as $kb_c => $kb_btn) {
            if (!is_array($kb_btn)) {
                continue;
            }
            if (isset($kb_btn['style']) && !in_array($kb_btn['style'], $allowed_btn_styles, true)) {
                unset($keyboardRows[$kb_r][$kb_c]['style']);
            }
            $kb_text = isset($kb_btn['text']) ? $kb_btn['text'] : '';
            if (($kb_text === "text_agentpanel" && !$agentPanelAllowed) || ($kb_text === "text_requestagent" && !$agentRequestAllowed)) {
                unset($keyboardRows[$kb_r][$kb_c]);
            }
        }
        $keyboardRows[$kb_r] = array_values($keyboardRows[$kb_r]);
        if (empty($keyboardRows[$kb_r])) {
            unset($keyboardRows[$kb_r]);
        }
    }
    $keyboardRows = array_values($keyboardRows);
}

if ($setting['inlinebtnmain'] == "oninline" && !empty($keyboardRows)) {
    $trace_keyboard = $keyboardRows;
    foreach ($trace_keyboard as $key => $callback_set) {
        foreach ($callback_set as $keyboard_key => $keyboard) {
            if ($keyboard['text'] == "text_sell") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "buy";
            }
            if ($keyboard['text'] == "accountwallet") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "account";
            }
            if ($keyboard['text'] == "text_Tariff_list") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "Tariff_list";
            }
            if ($keyboard['text'] == "text_wheel_luck") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "wheel_luck";
            }
            if ($keyboard['text'] == "text_affiliates") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "affiliatesbtn";
            }
            if ($keyboard['text'] == "text_extend") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "extendbtn";
            }
            if ($keyboard['text'] == "text_support") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "supportbtns";
            }
            if ($keyboard['text'] == "text_Purchased_services") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "backorder";
            }
            if ($keyboard['text'] == "text_help") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "helpbtns";
            }
            if ($keyboard['text'] == "text_usertest") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "usertestbtn";
            }
            if ($keyboard['text'] == "text_agentpanel") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "agentpanel";
            }
            if ($keyboard['text'] == "text_requestagent") {
                $trace_keyboard[$key][$keyboard_key]['callback_data'] = "requestagent";
            }
        }
    }
    if ($admin_idss != 0) {
        $temp_addtional_key[] = ['text' => $textbotlang['Admin']['panelAdmin'], 'callback_data' => "admin"];
    }
    $keyboard = ['inline_keyboard' => []];
    $keyboardcustom = $trace_keyboard;
    $keyboardcustom = applyKeyboardLabels($keyboardcustom, $replacements);
    if (!empty($temp_addtional_key)) {
        $keyboardcustom[] = $temp_addtional_key;
    }
    $keyboard['inline_keyboard'] = $keyboardcustom;
    $keyboard = json_encode($keyboard);
} else {
    if ($admin_idss != 0) {
        $temp_addtional_key[] = ['text' => $textbotlang['Admin']['panelAdmin']];
    }
    $keyboard = ['keyboard' => [], 'resize_keyboard' => true];
    $keyboardcustom = $keyboardRows;
    $keyboardcustom = applyKeyboardLabels($keyboardcustom, $replacements);
    if (!empty($temp_addtional_key)) {
        $keyboardcustom[] = $temp_addtional_key;
    }
    $keyboard['keyboard'] = $keyboardcustom;
    $keyboard = json_encode($keyboard);
}

if (is_file(__DIR__.'/.alirezaserver-managed') && !is_file(__DIR__.'/.alireza-tenant')) {
    $azKeyboard=json_decode($keyboard,true);
    if(isset($azKeyboard['inline_keyboard']))$azKeyboard['inline_keyboard'][]=[['text'=>'🛍 خرید پنل نمایندگی','callback_data'=>'az:panels'],['text'=>'🧭 مدیریت پنل من','callback_data'=>'az:mine']];
    else $azKeyboard['keyboard'][]=[['text'=>'🛍 خرید پنل نمایندگی'],['text'=>'🧭 مدیریت پنل من']];
    $keyboard=json_encode($azKeyboard,JSON_UNESCAPED_UNICODE);
}

$keyboardPanel = json_encode([
    'inline_keyboard' => [
        [
            ['text' => $textbotlang['textbot']['discount'], 'callback_data' => "Discount"],
            ['text' => $textbotlang['textbot']['addBalance'], 'callback_data' => "Add_Balance"]
        ],
        [
            ['text' => $textbotlang['language']['changeButton'], 'callback_data' => "ّchange_language"],
        ],
        [['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"]],
    ],
    'resize_keyboard' => true
]);
if ($adminrulecheck['rule'] == "administrator") {
    $keyboardadmin = json_encode([
        'keyboard' => [
            [['text' => $textbotlang['Admin']['Status']['btn']]],
            [['text' => $textbotlang['Admin']['btnKeyboard']['managementPanel']], ['text' => $textbotlang['Admin']['btnKeyboard']['addPanel']]],
            [['text' => $textbotlang['keyboard']['quickSetTimePrice']], ['text' => $textbotlang['keyboard']['quickSetVolumePrice']]],
            [['text' => $textbotlang['Admin']['btnKeyboard']['manageUser']], ['text' => $textbotlang['keyboard']['shopSettings']]],
            [['text' => $textbotlang['keyboard']['financial']], ['text' => $textbotlang['keyboard']['cronStatus']]],
            [['text' => $textbotlang['keyboard']['supportSection']], ['text' => $textbotlang['keyboard']['educationSection']]],
            [['text' => $textbotlang['keyboard']['botReport']]],
            [['text' => $textbotlang['keyboard']['generalSettings']], ['text' => $textbotlang['keyboard']['pendingReceipts']]],
            [['text' => $textbotlang['bottext']['open_button']]],
            [['text' => $textbotlang['users']['backbtn']]]
        ],
        'resize_keyboard' => true
    ]);
}
if ($adminrulecheck['rule'] == "Seller") {
    $keyboardadmin = json_encode([
        'keyboard' => [
            [['text' => $textbotlang['Admin']['Status']['btn']]],
            [['text' => $textbotlang['keyboard']['manageUser']]],
            [['text' => $textbotlang['users']['backbtn']]]
        ],
        'resize_keyboard' => true
    ]);
}
if ($adminrulecheck['rule'] == "support") {
    $keyboardadmin = json_encode([
        'keyboard' => [
            [['text' => $textbotlang['keyboard']['manageUser']]],
            [['text' => $textbotlang['users']['backbtn']]]
        ],
        'resize_keyboard' => true
    ]);
}
$CartManage = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['setCardNumber'], 'callback_data' => "paygwopt-setCardNumber"], ['text' => $textbotlang['keyboard']['deleteCardNumber'], 'callback_data' => "paygwopt-deleteCardNumber"]],
        [['text' => $textbotlang['keyboard']['supportId'], 'callback_data' => "paygwopt-supportId"], ['text' => $textbotlang['keyboard']['offlineGatewayPv'], 'callback_data' => "paygwopt-offlineGatewayPv"]],
        [['text' => $textbotlang['keyboard']['disableShowCard'], 'callback_data' => "paygwopt-disableShowCard"], ['text' => $textbotlang['keyboard']['enableShowCard'], 'callback_data' => "paygwopt-enableShowCard"]],
        [['text' => $textbotlang['keyboard']['groupShowCard'], 'callback_data' => "paygwopt-groupShowCard"]],
        [['text' => $textbotlang['keyboard']['exportActiveCardUsers'], 'callback_data' => "paygwopt-exportActiveCardUsers"]],
        [['text' => $textbotlang['keyboard']['cashbackCartToCart'], 'callback_data' => "paygwopt-cashbackCartToCart"]],
        [['text' => $textbotlang['keyboard']['showCartAfterFirstPay'], 'callback_data' => "paygwopt-showCartAfterFirstPay"]],
        [['text' => $textbotlang['keyboard']['minAmountCartToCart'], 'callback_data' => "paygwopt-minAmountCartToCart"], ['text' => $textbotlang['keyboard']['maxAmountCartToCart'], 'callback_data' => "paygwopt-maxAmountCartToCart"]],
        [['text' => $textbotlang['keyboard']['setEducationCartToCart'], 'callback_data' => "paygwopt-setEducationCartToCart"]],
        [['text' => $textbotlang['keyboard']['autoConfirmNoCheck'], 'callback_data' => "paygwopt-autoConfirmNoCheck"]],
        [['text' => $textbotlang['keyboard']['excludeUserAutoConfirm'], 'callback_data' => "paygwopt-excludeUserAutoConfirm"]],
        [['text' => $textbotlang['keyboard']['autoConfirmNoCheckTime'], 'callback_data' => "paygwopt-autoConfirmNoCheckTime"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$trnado = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['apiT'], 'callback_data' => "paygwopt-apiT"]],
        [['text' => $textbotlang['keyboard']['cashbackIranPay2'], 'callback_data' => "paygwopt-cashbackIranPay2"]],
        [['text' => $textbotlang['keyboard']['feeStatusIranPay2'], 'callback_data' => "paygwopt-feeStatusIranPay2"], ['text' => $textbotlang['keyboard']['feeAmountIranPay2'], 'callback_data' => "paygwopt-feeAmountIranPay2"]],
        [['text' => $textbotlang['keyboard']['minAmountIranPay2'], 'callback_data' => "paygwopt-minAmountIranPay2"], ['text' => $textbotlang['keyboard']['maxAmountIranPay2'], 'callback_data' => "paygwopt-maxAmountIranPay2"]],
        [['text' => $textbotlang['keyboard']['setEducationIranPay2'], 'callback_data' => "paygwopt-setEducationIranPay2"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$keyboardzarinpal = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['zarinPalMerchant'], 'callback_data' => "paygwopt-zarinPalMerchant"]],
        [['text' => $textbotlang['keyboard']['cashbackZarinPal'], 'callback_data' => "paygwopt-cashbackZarinPal"]],
        [['text' => $textbotlang['keyboard']['minAmountZarinPal'], 'callback_data' => "paygwopt-minAmountZarinPal"], ['text' => $textbotlang['keyboard']['maxAmountZarinPal'], 'callback_data' => "paygwopt-maxAmountZarinPal"]],
        [['text' => $textbotlang['keyboard']['setEducationZarinPal'], 'callback_data' => "paygwopt-setEducationZarinPal"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$keyboardvariza = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['varizaApiToken'], 'callback_data' => "paygwopt-varizaApiToken"], ['text' => $textbotlang['keyboard']['varizaWebhookSecret'], 'callback_data' => "paygwopt-varizaWebhookSecret"]],
        [['text' => $textbotlang['keyboard']['cashbackVariza'], 'callback_data' => "paygwopt-cashbackVariza"]],
        [['text' => $textbotlang['keyboard']['minAmountVariza'], 'callback_data' => "paygwopt-minAmountVariza"], ['text' => $textbotlang['keyboard']['maxAmountVariza'], 'callback_data' => "paygwopt-maxAmountVariza"]],
        [['text' => $textbotlang['keyboard']['setEducationVariza'], 'callback_data' => "paygwopt-setEducationVariza"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$aqayepardakht = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['setAqayePardakhtMerchant'], 'callback_data' => "paygwopt-setAqayePardakhtMerchant"], ['text' => $textbotlang['keyboard']['cashbackAqayePardakht'], 'callback_data' => "paygwopt-cashbackAqayePardakht"]],
        [['text' => $textbotlang['keyboard']['minAmountAqayePardakht'], 'callback_data' => "paygwopt-minAmountAqayePardakht"], ['text' => $textbotlang['keyboard']['maxAmountAqayePardakht'], 'callback_data' => "paygwopt-maxAmountAqayePardakht"]],
        [['text' => $textbotlang['keyboard']['setEducationAqayePardakht'], 'callback_data' => "paygwopt-setEducationAqayePardakht"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$NowPaymentsManage = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['apiPlisio'], 'callback_data' => "paygwopt-apiPlisio"], ['text' => $textbotlang['keyboard']['cashbackPlisio'], 'callback_data' => "paygwopt-cashbackPlisio"]],
        [['text' => $textbotlang['keyboard']['minAmountPlisio'], 'callback_data' => "paygwopt-minAmountPlisio"], ['text' => $textbotlang['keyboard']['maxAmountPlisio'], 'callback_data' => "paygwopt-maxAmountPlisio"]],
        [['text' => $textbotlang['keyboard']['setEducationPlisio'], 'callback_data' => "paygwopt-setEducationPlisio"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$setting_panel = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['featureStatus']], ['text' => $textbotlang['keyboard']['adminSection']]],
        [['text' => $textbotlang['keyboard']['channelSettings']], ['text' => $textbotlang['keyboard']['botReports']]],
        [['text' => $textbotlang['keyboard']['agentMembershipFee']], ['text' => $textbotlang['keyboard']['qrBackground']]],
        [['text' => $textbotlang['keyboard']['setTestAccountLimitAll']]],
        [['text' => $textbotlang['keyboard']['activateWebPanel']], ['text' => $textbotlang['keyboard']['optimizeBot']]],
        [['text' => $textbotlang['keyboard']['setBotCommands']]],
        [['text' => $textbotlang['keyboard']['reWebhookAgentBots']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
$PaySettingcard = getPaySettingValue("Cartstatus");
$PaySettingnow = getPaySettingValue("nowpaymentstatus");
$PaySettingaqayepardakht = getPaySettingValue("statusaqayepardakht");
$PaySettingpv = getPaySettingValue("Cartstatuspv");
$usernamecart = getPaySettingValue("CartDirect");
$Swapino = getPaySettingValue("statusSwapWallet");
$trnadoo = getPaySettingValue("statustarnado");
$paymentverify = getPaySettingValue("checkpaycartfirst");
$stmt = $pdo->prepare("SELECT COUNT(*) FROM Payment_report WHERE id_user = :user_id AND payment_Status = 'paid'");
$stmt->bindValue(':user_id', $from_id);
$stmt->execute();
$paymentexits = (int) $stmt->fetchColumn();
$zarinpal = getPaySettingValue("zarinpalstatus");
$affilnecurrency = getPaySettingValue("digistatus");
$arzireyali3 = getPaySettingValue("statusiranpay3");
$abangateway4 = getPaySettingValue("statusiranpay4", "offiranpay4");
$paymentstatussnotverify = getPaySettingValue("paymentstatussnotverify");
$paymentsstartelegram = getPaySettingValue("statusstar");
$payment_status_nowpayment = getPaySettingValue("statusnowpayment");
$step_payment = [
    'inline_keyboard' => []
];
if ($PaySettingcard == "oncard" && intval($users['cardpayment']) == 1) {
    if ($PaySettingpv == "oncardpv") {
        $step_payment['inline_keyboard'][] = [
            ['text' => $textbotlang['textbot']['cartToCart'], 'url' => "https://t.me/$usernamecart"],
        ];
    } else {
        $step_payment['inline_keyboard'][] = [
            ['text' => $textbotlang['textbot']['cartToCart'], 'callback_data' => "cart_to_offline"],
        ];
    }
}
if (($paymentexits == 0 && $paymentverify == "onpayverify"))
    unset($step_payment['inline_keyboard']);
if ($PaySettingnow == "onnowpayment") {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['nowPayment'], 'callback_data' => "plisio"]
    ];
}
if ($payment_status_nowpayment == "1") {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['cryptoPayment'], 'callback_data' => "nowpayment"]
    ];
}
if ($affilnecurrency == "ondigi") {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['nowPaymentTron'], 'callback_data' => "digitaltron"]
    ];
}
if ($Swapino == "onSwapinoBot") {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['iranPay2'], 'callback_data' => "iranpay1"]
    ];
}
if ($trnadoo == "onternado") {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['iranPay3'], 'callback_data' => "iranpay2"]
    ];
}
// Both halves matter: the admin has switched it on, *and* the key and endpoint
// exist. A gateway shown without them takes the buyer to a page that cannot be
// created — the button is the last place to find that out.
if (
    $abangateway4 == "oniranpay4"
    && trim((string) getPaySettingValue("apiiranpay4", "")) !== ""
    && trim((string) getPaySettingValue("apiiranpay4", "")) !== "0"
    && function_exists('abangatewayEndpoint') && abangatewayEndpoint() !== null
) {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['iranPay4'], 'callback_data' => "iranpay4"]
    ];
}
if ($arzireyali3 == "oniranpay3" && $paymentexits >= 2) {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['iranPay1'], 'callback_data' => "iranpay3"]
    ];
}
if ($PaySettingaqayepardakht == "onaqayepardakht") {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['aqayePardakht'], 'callback_data' => "aqayepardakht"]
    ];
}
if ($zarinpal == "onzarinpal") {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['zarinPal'], 'callback_data' => "zarinpal"]
    ];
}
$variza = getPaySettingValue("variza_status", "offvariza");
if (
    $variza == "onvariza"
    && trim((string) getPaySettingValue("variza_api_token", "")) !== ""
    && trim((string) getPaySettingValue("variza_api_token", "")) !== "0"
    && trim((string) getPaySettingValue("variza_webhook_secret", "")) !== ""
    && trim((string) getPaySettingValue("variza_webhook_secret", "")) !== "0"
) {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['variza'], 'callback_data' => "variza"]
    ];
}
if ($paymentstatussnotverify == "onverifypay") {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['paymentNotVerify'], 'callback_data' => "paymentnotverify"]
    ];
}
if (intval($paymentsstartelegram) == 1) {
    $step_payment['inline_keyboard'][] = [
        ['text' => $textbotlang['textbot']['starTelegram'], 'callback_data' => "startelegrams"]
    ];
}
$step_payment['inline_keyboard'][] = [
    ['text' => $textbotlang['keyboard']['closeList'], 'callback_data' => "colselist"]
];
$step_payment = json_encode($step_payment);
$keyboardhelpadmin = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['addEducation']], ['text' => $textbotlang['keyboard']['deleteEducation']]],
        [['text' => $textbotlang['keyboard']['editEducation']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
$shopkeyboard = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['shopFeatureStatus']]],
        [['text' => $textbotlang['keyboard']['manageCategory']], ['text' => $textbotlang['keyboard']['manageProducts']]],
        [['text' => $textbotlang['keyboard']['manageGiftCode']], ['text' => $textbotlang['keyboard']['manageDiscountCode']]],
        [['text' => $textbotlang['keyboard']['minBulkBalance']], ['text' => $textbotlang['keyboard']['renewalCashback']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
$wheelFeatures = [
    'wheelagentfirst' => ['label' => $textbotlang['keyboard']['firstPurchaseWheel'], 'setting' => 'statusfirstwheel', 'on' => '1', 'off' => '0'],
    'wheelagent' => ['label' => $textbotlang['keyboard']['agentWheelOfLuck'], 'setting' => 'wheelagent', 'on' => '1', 'off' => '0'],
    'Dice' => ['label' => $textbotlang['keyboard']['wheelGameType'], 'setting' => 'Dice', 'on' => '1', 'off' => '0', 'onText' => $textbotlang['keyboard']['wheelModeDice'], 'offText' => $textbotlang['keyboard']['wheelModeSlot']],
];
$lotteryFeatures = [
    'score' => ['label' => $textbotlang['keyboard']['nightLottery'], 'setting' => 'scorestatus', 'on' => '1', 'off' => '0'],
    'Lotteryagent' => ['label' => $textbotlang['keyboard']['agentLottery'], 'setting' => 'Lotteryagent', 'on' => '1', 'off' => '0'],
];
$featureCategories = [
    'general' => [
        'label' => $textbotlang['keyboard']['featureCategoryGeneral'],
        'features' => [
            'statusbot' => ['label' => $textbotlang['Admin']['Status']['statusBot'], 'setting' => 'Bot_Status', 'on' => 'botstatuson', 'off' => 'botstatusoff'],
            'role' => ['label' => $textbotlang['Admin']['Status']['statusRole'], 'setting' => 'roll_Status', 'on' => 'rolleon', 'off' => 'rolleoff'],
            'notifnew' => ['label' => $textbotlang['Admin']['Status']['statusNotifNewUser'], 'setting' => 'statusnewuser', 'on' => 'onnewuser', 'off' => 'offnewuser'],
            'usernamebtn' => ['label' => $textbotlang['Admin']['Status']['statusUsernameBtn'], 'setting' => 'NotUser', 'on' => 'onnotuser', 'off' => 'offnotuser'],
            'inlinebtnmain' => ['label' => $textbotlang['Admin']['Status']['inlinebtns'], 'setting' => 'inlinebtnmain', 'on' => 'oninline', 'off' => 'offinline'],
            'keyconfig' => ['label' => $textbotlang['keyboard']['configKeyboard'], 'setting' => 'status_keyboard_config', 'on' => '1', 'off' => '0'],
            'statussupportpv' => ['label' => $textbotlang['keyboard']['supportInPv'], 'setting' => 'statussupportpv', 'on' => 'onpvsupport', 'off' => 'offpvsupport'],
            'btn_status_category' => ['label' => $textbotlang['keyboard']['educationCategory'], 'setting' => 'categoryhelp', 'on' => '1', 'off' => '0'],
            'linkappstatus' => ['label' => $textbotlang['keyboard']['appDownloadLinkAlt'], 'setting' => 'linkappstatus', 'on' => '1', 'off' => '0', 'config' => 'linkappsetting'],
            'Authenticationphone' => ['label' => $textbotlang['Admin']['Status']['Authenticationphone'], 'setting' => 'get_number', 'on' => 'onAuthenticationphone', 'off' => 'offAuthenticationphone'],
            'Authenticationiran' => ['label' => $textbotlang['Admin']['Status']['Authenticationiran'], 'setting' => 'iran_number', 'on' => 'onAuthenticationiran', 'off' => 'offAuthenticationiran'],
            'verifystart' => ['label' => $textbotlang['keyboard']['authenticate'], 'setting' => 'verifystart', 'on' => 'onverify', 'off' => 'offverify'],
            'verifybyuser' => ['label' => $textbotlang['keyboard']['authWithLink'], 'setting' => 'verifybucodeuser', 'on' => 'onverify', 'off' => 'offverify'],
        ],
    ],
    'sales' => [
        'label' => $textbotlang['keyboard']['featureCategorySales'],
        'features' => [
            'bulkbuy' => ['label' => $textbotlang['keyboard']['bulkPurchaseStatus'], 'setting' => 'bulkbuy', 'on' => 'onbulk', 'off' => 'offbulk'],
            'compycart' => ['label' => $textbotlang['keyboard']['copyCard'], 'setting' => 'statuscopycart', 'on' => '1', 'off' => '0'],
            'Debtsettlement' => ['label' => $textbotlang['keyboard']['settleDebt'], 'setting' => 'Debtsettlement', 'on' => '1', 'off' => '0'],
            'alert_balance' => ['label' => $textbotlang['keyboard']['lowBalanceAlert'], 'setting' => 'alert_balance', 'on' => '1', 'off' => '0', 'config' => 'setlowbalancealert'],
            'changeloc' => ['label' => $textbotlang['keyboard']['locationChangeLimit'], 'setting' => 'statuslimitchangeloc', 'on' => '1', 'off' => '0', 'config' => 'changeloclimit'],
            'statusnamecustom' => ['label' => $textbotlang['keyboard']['configNote'], 'setting' => 'statusnamecustom', 'on' => 'onnamecustom', 'off' => 'offnamecustom'],
            'statusnamecustomf' => ['label' => $textbotlang['keyboard']['userNote'], 'setting' => 'statusnoteforf', 'on' => '1', 'off' => '0'],
            'affiliates' => ['label' => $textbotlang['keyboard']['affiliateGift'], 'config' => 'affiliatesettings'],
            'wheel_luck' => ['label' => $textbotlang['keyboard']['wheelOfLuck'], 'config' => 'wheelsettings'],
            'score' => $lotteryFeatures['score'] + ['config' => 'lotterysettings'],
        ],
    ],
    'cron' => [
        'label' => $textbotlang['keyboard']['featureCategoryCron'],
        'features' => [
            'crontest' => ['label' => $textbotlang['keyboard']['cronTest'], 'cron' => 'test'],
            'cronday' => ['label' => $textbotlang['keyboard']['cronTime'], 'cron' => 'day', 'config' => 'settimecornday'],
            'cronvolume' => ['label' => $textbotlang['keyboard']['cronVolume'], 'cron' => 'volume', 'config' => 'settimecornvolume'],
            'on_hold' => ['label' => $textbotlang['keyboard']['cronFirstConnection'], 'cron' => 'on_hold', 'config' => 'setting_on_holdcron'],
            'notifremove' => ['label' => $textbotlang['keyboard']['cronDelete'], 'cron' => 'remove', 'config' => 'settimecornremove'],
            'notifremove_volume' => ['label' => $textbotlang['keyboard']['cronDeleteVolume'], 'cron' => 'remove_volume', 'config' => 'settimecornremovevolume'],
            'uptime_node' => ['label' => $textbotlang['keyboard']['nodeUptime'], 'cron' => 'uptime_node'],
            'uptime_panel' => ['label' => $textbotlang['keyboard']['panelUptime'], 'cron' => 'uptime_panel'],
        ],
    ],
];
function featureIsOn($feature, $setting)
{
    if (isset($feature['cron'])) {
        return !empty(json_decode($setting['cron_status'], true)[$feature['cron']]);
    }
    return $setting[$feature['setting']] == $feature['on'];
}
function featureCategoryKeyboard($categoryKey)
{
    global $featureCategories, $textbotlang;
    $setting = select("setting", "*");
    $rows = [];
    $settingsButtons = [];
    foreach ($featureCategories[$categoryKey]['features'] as $featureKey => $feature) {
        if (!isset($feature['setting']) && !isset($feature['cron'])) {
            $settingsButtons[] = ['text' => $feature['label'], 'callback_data' => $feature['config']];
            continue;
        }
        $row = [
            ['text' => $textbotlang['Admin']['Status'][featureIsOn($feature, $setting) ? 'statuson' : 'statusoff'], 'callback_data' => "feature-$categoryKey-$featureKey"],
            ['text' => $feature['label'], 'callback_data' => "feature-$categoryKey-$featureKey"],
        ];
        if (isset($feature['config'])) {
            array_unshift($row, ['text' => "⚙️", 'callback_data' => $feature['config']]);
        }
        $rows[] = $row;
    }
    array_push($rows, ...array_chunk($settingsButtons, 2));
    $categoryKeys = array_keys($featureCategories);
    $page = array_search($categoryKey, $categoryKeys);
    $pageCount = count($categoryKeys);
    $rows[] = [
        ['text' => "◀️", 'callback_data' => "featurecat-" . $categoryKeys[($page + $pageCount - 1) % $pageCount]],
        ['text' => ($page + 1) . " / $pageCount", 'callback_data' => "none"],
        ['text' => "▶️", 'callback_data' => "featurecat-" . $categoryKeys[($page + 1) % $pageCount]],
    ];
    return json_encode(['inline_keyboard' => $rows]);
}
function wheelSettingsMenu()
{
    global $wheelFeatures, $textbotlang;
    $setting = select("setting", "*");
    $rows = [];
    foreach ($wheelFeatures as $featureKey => $feature) {
        $isOn = featureIsOn($feature, $setting);
        $statusText = isset($feature['onText']) ? $feature[$isOn ? 'onText' : 'offText'] : $textbotlang['Admin']['Status'][$isOn ? 'statuson' : 'statusoff'];
        $rows[] = [
            ['text' => $statusText, 'callback_data' => "wheel-$featureKey"],
            ['text' => $feature['label'], 'callback_data' => "wheel-$featureKey"],
        ];
    }
    $rows[] = [
        ['text' => number_format((int) $setting['wheelـluck_price']), 'callback_data' => "wheelprize"],
        ['text' => $textbotlang['keyboard']['lotteryWinAmount'], 'callback_data' => "wheelprize"],
    ];
    $rows[] = [['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => "featurecat-sales"]];
    $text = sprintf($textbotlang['Admin']['Status']['wheelSettings'], number_format((int) $setting['wheelـluck_price']));
    return [$text, json_encode(['inline_keyboard' => $rows])];
}
function lotterySettingsMenu()
{
    global $lotteryFeatures, $textbotlang;
    $setting = select("setting", "*");
    $rows = [];
    foreach ($lotteryFeatures as $featureKey => $feature) {
        $rows[] = [
            ['text' => $textbotlang['Admin']['Status'][featureIsOn($feature, $setting) ? 'statuson' : 'statusoff'], 'callback_data' => "lottery-$featureKey"],
            ['text' => $feature['label'], 'callback_data' => "lottery-$featureKey"],
        ];
    }
    $prizes = json_decode($setting['Lottery_prize'], true);
    foreach (['one' => 'setFirstPrize', 'tow' => 'setSecondPrize', 'theree' => 'setThirdPrize'] as $prizeKey => $labelKey) {
        $rows[] = [
            ['text' => number_format((int) ($prizes[$prizeKey] ?? 0)), 'callback_data' => "lotteryprize-$prizeKey"],
            ['text' => $textbotlang['keyboard'][$labelKey], 'callback_data' => "lotteryprize-$prizeKey"],
        ];
    }
    $rows[] = [['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => "featurecat-sales"]];
    $text = sprintf($textbotlang['Admin']['Status']['lotterySettings'], number_format((int) ($prizes['one'] ?? 0)), number_format((int) ($prizes['tow'] ?? 0)), number_format((int) ($prizes['theree'] ?? 0)));
    return [$text, json_encode(['inline_keyboard' => $rows])];
}
function affiliateSettingsMenu()
{
    global $textbotlang;
    $setting = select("setting", "*");
    $affiliateSetting = select("affiliates", "*", null, null, "select");
    $commissionText = $textbotlang['Admin']['Status'][$affiliateSetting['status_commission'] == "oncommission" ? 'statuson' : 'statusoff'];
    $firstBuyText = $affiliateSetting['porsant_one_buy'] == "on_buy_porsant" ? $textbotlang['keyboard']['firstPurchaseBtn'] : $textbotlang['keyboard']['allPurchases'];
    $startGiftText = $textbotlang['Admin']['Status'][$affiliateSetting['Discount'] == "onDiscountaffiliates" ? 'statuson' : 'statusoff'];
    $percentText = ($setting['affiliatespercentage'] ?? 0) . "%";
    $giftAmountText = number_format((int) $affiliateSetting['price_Discount']);
    $rows = [
        [['text' => $commissionText, 'callback_data' => "affiliate-commission"], ['text' => $textbotlang['keyboard']['purchaseCommission'], 'callback_data' => "affiliate-commission"]],
        [['text' => $firstBuyText, 'callback_data' => "affiliate-firstbuy"], ['text' => $textbotlang['keyboard']['firstPurchaseCommission'], 'callback_data' => "affiliate-firstbuy"]],
        [['text' => $percentText, 'callback_data' => "affiliate-percent"], ['text' => $textbotlang['keyboard']['setAffiliatePercent'], 'callback_data' => "affiliate-percent"]],
        [['text' => $startGiftText, 'callback_data' => "affiliate-startgift"], ['text' => $textbotlang['keyboard']['startGift'], 'callback_data' => "affiliate-startgift"]],
        [['text' => $giftAmountText, 'callback_data' => "affiliate-giftamount"], ['text' => $textbotlang['keyboard']['startGiftAmount'], 'callback_data' => "affiliate-giftamount"]],
        [['text' => $textbotlang['keyboard']['setAffiliateBanner'], 'callback_data' => "affiliate-banner"]],
        [['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => "featurecat-sales"]],
    ];
    $text = sprintf($textbotlang['Admin']['affiliates']['settingsTitle'], $commissionText, $firstBuyText, $percentText, $startGiftText, $giftAmountText);
    return [$text, json_encode(['inline_keyboard' => $rows])];
}
function cronStatusMenu()
{
    global $textbotlang, $domainhosts;
    require_once __DIR__ . '/cronbot/jobs.php';
    $labels = $textbotlang['Admin']['cronHealth'];
    $cronStatus = json_decode((string) @file_get_contents(__DIR__ . '/storage/cron_status.json'), true) ?: [];
    $setting = select("setting", "*");
    $timeAgo = fn($time) => time() - $time < 60 ? $labels['justNow'] : sprintf($labels['minutesAgo'], intdiv(time() - $time, 60));
    $dispatcherRunning = isset($cronStatus['dispatcher']) && time() - $cronStatus['dispatcher'] <= 180;
    $lines = [];
    foreach (mirza_cron_jobs() as $job) {
        [$minute, $hour] = explode(' ', $job['schedule']);
        $intervalMinutes = str_starts_with($hour, '*/') ? (int) substr($hour, 2) * 60 : (str_starts_with($minute, '*/') ? (int) substr($minute, 2) : 1);
        $lastRun = $cronStatus['jobs'][$job['job']] ?? null;
        if ($job['job'] == 'lottery' && intval($setting['scorestatus']) != 1) {
            $icon = "⏸";
            $when = $labels['disabled'];
        } elseif (!$lastRun) {
            $icon = "❌";
            $when = $labels['never'];
        } else {
            $icon = $lastRun['error'] ? "⚠️" : (time() - $lastRun['time'] <= $intervalMinutes * 120 + 120 ? "✅" : "❌");
            $when = $timeAgo($lastRun['time']);
        }
        $lines[] = "$icon {$job['title']} — $when";
    }
    $text = $labels['title'] . "\n\n" . ($dispatcherRunning ? $labels['running'] : $labels['stopped']) . "\n";
    $text .= sprintf($labels['lastRun'], isset($cronStatus['dispatcher']) ? $timeAgo($cronStatus['dispatcher']) : $labels['never']) . "\n\n";
    if (isset($cronStatus['pdo_mysql']) && !$cronStatus['pdo_mysql']) {
        $text .= sprintf($labels['missingMysql'], htmlspecialchars((string) $cronStatus['php_cli'])) . "\n\n";
    }
    $text .= implode("\n", $lines);
    if (!$dispatcherRunning) {
        $text .= "\n\n" . sprintf($labels['command'], htmlspecialchars(mirza_cron_dispatcher_command((string) $domainhosts)));
    }
    $keyboard = json_encode([
        'inline_keyboard' => [
            [['text' => $labels['refresh'], 'callback_data' => "cronstatus_refresh"], ['text' => $labels['fix'], 'callback_data' => "cronstatus_fix"]],
        ]
    ]);
    return [$text, $keyboard];
}
function giftCodesMenu()
{
    global $pdo, $textbotlang;
    $giftCodes = $pdo->query("SELECT code, price FROM Discount")->fetchAll(PDO::FETCH_ASSOC);
    $rows = [[['text' => $textbotlang['keyboard']['createGiftCode'], 'callback_data' => "giftcode_create"]]];
    foreach ($giftCodes as $giftCode) {
        $rows[] = [
            ['text' => "❌", 'callback_data' => "giftcode_delete_{$giftCode['code']}"],
            ['text' => "{$giftCode['code']} (" . number_format((int) $giftCode['price']) . ")", 'callback_data' => "giftcode_show_{$giftCode['code']}"],
        ];
    }
    $rows[] = [['text' => $textbotlang['keyboard']['backToShopMenu'], 'callback_data' => "shopmenu_open"]];
    $text = sprintf($textbotlang['Admin']['Discount']['giftManage'], count($giftCodes));
    return [$text, json_encode(['inline_keyboard' => $rows])];
}
$wheelFlowKeyboard = json_encode(['inline_keyboard' => [[['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => "wheelsettings"]]]]);
$lotteryFlowKeyboard = json_encode(['inline_keyboard' => [[['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => "lotterysettings"]]]]);
$affiliateFlowKeyboard = json_encode(['inline_keyboard' => [[['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => "affiliatesettings"]]]]);
$giftCodeFlowKeyboard = json_encode(['inline_keyboard' => [[['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => "giftcode_list"]]]]);
$discountCodeFlowKeyboard = json_encode(['inline_keyboard' => [[['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => "discountcode_list"]]]]);
function editFlowMessage($text, $keyboard)
{
    global $from_id, $message_id, $datain, $user;
    $flowMessageId = json_decode($user['Processing_value'], true)['message_id'] ?? $message_id;
    if ($datain == "") {
        deletemessage($from_id, $message_id);
    }
    Editmessagetext($from_id, $flowMessageId, $text, $keyboard);
}
function discountPanelsKeyboard()
{
    global $pdo, $textbotlang;
    $rows = [[['text' => $textbotlang['keyboard']['allPanels'], 'callback_data' => "discountpanel_all"]]];
    foreach ($pdo->query("SELECT name_panel, code_panel FROM marzban_panel")->fetchAll(PDO::FETCH_ASSOC) as $panel) {
        $rows[] = [['text' => $panel['name_panel'], 'callback_data' => "discountpanel_{$panel['code_panel']}"]];
    }
    $rows[] = [['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => "discountcode_list"]];
    return json_encode(['inline_keyboard' => $rows]);
}
function discountProductsKeyboard($location)
{
    global $pdo, $textbotlang;
    $stmt = $pdo->prepare("SELECT name_product, code_product FROM product WHERE Location = :location OR Location = '/all'");
    $stmt->execute([':location' => $location]);
    $rows = [[['text' => $textbotlang['keyboard']['allProducts'], 'callback_data' => "discountproduct_all"]]];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $product) {
        $rows[] = [['text' => $product['name_product'], 'callback_data' => "discountproduct_{$product['code_product']}"]];
    }
    $rows[] = [['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => "discountcode_list"]];
    return json_encode(['inline_keyboard' => $rows]);
}
function discountCodesMenu()
{
    global $pdo, $textbotlang;
    $discountCodes = $pdo->query("SELECT codeDiscount, price FROM DiscountSell")->fetchAll(PDO::FETCH_ASSOC);
    $rows = [[['text' => $textbotlang['keyboard']['createDiscountCode'], 'callback_data' => "discountcode_create"]]];
    foreach ($discountCodes as $discountCode) {
        $rows[] = [
            ['text' => "❌", 'callback_data' => "discountcode_delete_{$discountCode['codeDiscount']}"],
            ['text' => "{$discountCode['codeDiscount']} ({$discountCode['price']}%)", 'callback_data' => "discountcode_show_{$discountCode['codeDiscount']}"],
        ];
    }
    $rows[] = [['text' => $textbotlang['keyboard']['backToShopMenu'], 'callback_data' => "shopmenu_open"]];
    $text = sprintf($textbotlang['Admin']['Discount']['discountManage'], count($discountCodes));
    return [$text, json_encode(['inline_keyboard' => $rows])];
}
$keyboard_Category_manage = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['addCategory']], ['text' => $textbotlang['keyboard']['deleteCategory']]],
        [['text' => $textbotlang['keyboard']['editCategoryMenu']]],
        [['text' => $textbotlang['keyboard']['backToShopMenu']]]
    ],
    'resize_keyboard' => true
]);
$keyboard_shop_manage = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['addProduct']], ['text' => $textbotlang['keyboard']['deleteProduct']]],
        [['text' => $textbotlang['keyboard']['editProduct']]],
        [['text' => $textbotlang['keyboard']['increaseGroupPrice']], ['text' => $textbotlang['keyboard']['decreaseGroupPrice']]],
        [['text' => $textbotlang['keyboard']['backToShopMenu']]]
    ],
    'resize_keyboard' => true
]);
if ($setting['inlinebtnmain'] == "oninline") {
    $confrimrolls = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $textbotlang['keyboard']['acceptRules'], 'callback_data' => "acceptrule"],
            ],
        ]
    ]);
} else {
    $confrimrolls = json_encode([
        'keyboard' => [
            [['text' => $textbotlang['keyboard']['acceptRules']]],
        ],
        'resize_keyboard' => true
    ]);
}
$request_contact = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['sendPhoneNumber'], 'request_contact' => true]],
        [['text' => $textbotlang['users']['backbtn']]]
    ],
    'resize_keyboard' => true
]);
$channelkeyboard = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['addChannel']], ['text' => $textbotlang['keyboard']['deleteChannel']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
if ($setting['inlinebtnmain'] == "oninline") {
    $backuser = json_encode([
        'inline_keyboard' => [
            [['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"]]
        ],
    ]);
} else {
    $backuser = json_encode([
        'keyboard' => [
            [['text' => $textbotlang['users']['backbtn']]]
        ],
        'resize_keyboard' => true,
    ]);
}
$backadmin = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true,
]);
//------------------  [ list panel ]----------------//
$namepanel = [];
    $allPanelRows = $pdo->query("SELECT * FROM marzban_panel")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($allPanelRows as $row) {
        $namepanel[] = [$row['name_panel']];
    }
    $list_marzban_panel = [
        'keyboard' => [],
        'resize_keyboard' => true,
    ];
    foreach ($namepanel as $button) {
        $list_marzban_panel['keyboard'][] = [
            ['text' => $button[0]]
        ];
    }
    $list_marzban_panel['keyboard'][] = [
        ['text' => $textbotlang['Admin']['backAdminBtn']],
        ['text' => $textbotlang['Admin']['backMenuBtn']]
    ];
    $json_list_marzban_panel = json_encode($list_marzban_panel);
    //------------------  [ list panel inline ]----------------//
    $list_marzban_panel_edit_product = ['inline_keyboard' => []];
    foreach ($allPanelRows as $row) {
        $list_marzban_panel_edit_product['inline_keyboard'][] = [['text' => $row['name_panel'], 'callback_data' => 'locationedit_' . $row['code_panel']]];
    }
    $list_marzban_panel_edit_product['inline_keyboard'][] = [['text' => $textbotlang['keyboard']['allPanels'], 'callback_data' => 'locationedit_all']];
    $list_marzban_panel_edit_product['inline_keyboard'][] = [['text' => $textbotlang['keyboard']['backToPreviousMenu'], 'callback_data' => 'backproductadmin']];
    $list_marzban_panel_edit_product = json_encode($list_marzban_panel_edit_product);
//------------------  [ list channel ]----------------//
$list_channels = [];
    $stmt = $pdo->prepare("SELECT * FROM channels");
    $stmt->execute();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $list_channels[] = [$row['link']];
    }
    $list_channels_join = [
        'keyboard' => [],
        'resize_keyboard' => true,
    ];
    foreach ($list_channels as $button) {
        $list_channels_join['keyboard'][] = [
            ['text' => $button[0]]
        ];
    }
    $list_channels_join['keyboard'][] = [
        ['text' => $textbotlang['Admin']['backAdminBtn']],
        ['text' => $textbotlang['Admin']['backMenuBtn']]
    ];
    $list_channels_joins = json_encode($list_channels_join);
//------------------  [ list card ]----------------//
$list_card = [];
    $stmt = $pdo->prepare("SELECT * FROM card_number");
    $stmt->execute();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $list_card[] = [$row['cardnumber']];
    }
    $list_card_remove = [
        'keyboard' => [],
        'resize_keyboard' => true,
    ];
    foreach ($list_card as $button) {
        $list_card_remove['keyboard'][] = [
            ['text' => $button[0]]
        ];
    }
    $list_card_remove['keyboard'][] = [
        ['text' => $textbotlang['Admin']['backAdminBtn']],
        ['text' => $textbotlang['Admin']['backMenuBtn']]
    ];
    $list_card_remove = json_encode($list_card_remove);
//------------------  [ help list ]----------------//
    $helpRows = $pdo->query("SELECT * FROM help")->fetchAll(PDO::FETCH_ASSOC);
    $helpkey = [];
    foreach ($helpRows as $row) {
        $helpkey[] = [$row['name_os']];
    }
    $help_arrke = [
        'keyboard' => [],
        'resize_keyboard' => true,
    ];
    foreach ($helpkey as $button) {
        $help_arrke['keyboard'][] = [
            ['text' => $button[0]]
        ];
    }
    $help_arrke['keyboard'][] = [
        ['text' => $textbotlang['users']['backbtn']],
    ];
    $json_list_helpkey = json_encode($help_arrke);
//------------------  [ help list ]----------------//
$helpcwtgory = ['inline_keyboard' => []];
$datahelp = [];
$helpCategoryMap = [];
foreach ($helpRows as $result) {
    if (in_array($result['category'], $datahelp))
        continue;
    if ($result['category'] == null)
        continue;
    $datahelp[] = $result['category'];
    $catId = dechex(crc32($result['category']));
    $helpCategoryMap[$catId] = $result['category'];
    $helpcwtgory['inline_keyboard'][] = [
        ['text' => $result['category'], 'callback_data' => "helpctg_{$catId}"]
    ];
}
if ($setting['linkappstatus'] == "1") {
    $helpcwtgory['inline_keyboard'][] = [
        ['text' => $textbotlang['keyboard']['appDownloadLink'], 'callback_data' => "linkappdownlod"],
    ];
}
$helpcwtgory['inline_keyboard'][] = [
    ['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"],
];
$json_list_helpـcategory = json_encode($helpcwtgory);


//------------------  [ help app ]----------------//
$appRows = $pdo->query("SELECT * FROM app")->fetchAll(PDO::FETCH_ASSOC);
$helpapp = ['inline_keyboard' => []];
foreach ($appRows as $result) {
    $helpapp['inline_keyboard'][] = [
        ['text' => $result['name'], 'url' => $result['link']]
    ];
}
$helpapp['inline_keyboard'][] = [
    ['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"],
];
$json_list_helpـlink = json_encode($helpapp);
//------------------  [ help app admin ]----------------//
$helpappremove = ['keyboard' => [], 'resize_keyboard' => true];
foreach ($appRows as $result) {
    $helpappremove['keyboard'][] = [
        ['text' => $result['name']],
    ];
}
$helpappremove['keyboard'][] = [
    ['text' => $textbotlang['Admin']['backAdminBtn']],
];
$json_list_remove_helpـlink = json_encode($helpappremove);
//------------------  [ listpanelusers ]----------------//
$activePanelRows = array_filter($allPanelRows, fn($panel) => $panel['status'] == "active" && in_array($panel['agent'], [$users['agent'], "all"]));
$manualsellCounts = [];
if (in_array('Manualsale', array_column($activePanelRows, 'type'))) {
    foreach ($pdo->query("SELECT codepanel, COUNT(*) AS c FROM manualsell WHERE status = 'active' GROUP BY codepanel")->fetchAll(PDO::FETCH_ASSOC) as $msRow) {
        $manualsellCounts[$msRow['codepanel']] = (int) $msRow['c'];
    }
}
$list_marzban_panel_users = ['inline_keyboard' => []];
$panelcount = count(array_filter($allPanelRows, fn($panel) => $panel['status'] == "active"));
if ($panelcount > 10) {
    $temp_row = [];
    foreach ($activePanelRows as $result) {
        if ($result['hide_user'] != null && in_array($from_id, json_decode($result['hide_user'], true)))
            continue;
        if ($result['type'] == "Manualsale" && empty($manualsellCounts[$result['code_panel']]))
            continue;
        if ($users['step'] == "getusernameinfo") {
            $temp_row[] = ['text' => $result['name_panel'], 'callback_data' => "locationnotuser_{$result['code_panel']}"];
        } else {
            $temp_row[] = ['text' => $result['name_panel'], 'callback_data' => "location_{$result['code_panel']}"];
        }
        if (count($temp_row) == 2) {
            $list_marzban_panel_users['inline_keyboard'][] = $temp_row;
            $temp_row = [];
        }
    }
    if (!empty($temp_row)) {
        $list_marzban_panel_users['inline_keyboard'][] = $temp_row;
    }
} else {
    foreach ($activePanelRows as $result) {
        if ($result['type'] == "Manualsale" && empty($manualsellCounts[$result['code_panel']]))
            continue;
        if ($result['hide_user'] != null and in_array($from_id, json_decode($result['hide_user'], true)))
            continue;
        if ($users['step'] == "getusernameinfo") {
            $list_marzban_panel_users['inline_keyboard'][] = [
                ['text' => $result['name_panel'], 'callback_data' => "locationnotuser_{$result['code_panel']}"]
            ];
        } else {
            $list_marzban_panel_users['inline_keyboard'][] = [
                ['text' => $result['name_panel'], 'callback_data' => "location_{$result['code_panel']}"]
            ];
        }
    }
}
$statusnote = false;
if ($setting['statusnamecustom'] == 'onnamecustom')
    $statusnote = true;
if ($setting['statusnoteforf'] == "0" && $users['agent'] == "f")
    $statusnote = false;
if ($statusnote) {
    $list_marzban_panel_users['inline_keyboard'][] = [
        ['text' => $textbotlang['users']['backbtn'], 'callback_data' => "buyback"],
    ];
} else {
    $list_marzban_panel_users['inline_keyboard'][] = [
        ['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"],
    ];
}
$list_marzban_panel_user = json_encode($list_marzban_panel_users);


//------------------  [ listpanelusers omdhe ]----------------//
$list_marzban_panel_users_om = ['inline_keyboard' => []];
foreach ($activePanelRows as $result) {
    if ($result['hide_user'] != null and in_array($from_id, json_decode($result['hide_user'], true)))
        continue;
    $list_marzban_panel_users_om['inline_keyboard'][] = [
        ['text' => $result['name_panel'], 'callback_data' => "locationom_{$result['code_panel']}"]
    ];
}
$list_marzban_panel_users_om['inline_keyboard'][] = [
    ['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"],
];
$list_marzban_panel_userom = json_encode($list_marzban_panel_users_om);

//------------------  [ change location ]----------------//
$list_marzban_panel_users_change = ['inline_keyboard' => []];
if ($panelcount > 10) {
    $temp_row = [];
    foreach ($activePanelRows as $result) {
        if ($result['name_panel'] == $users['Processing_value_four'])
            continue;
        if ($result['hide_user'] != null && in_array($from_id, json_decode($result['hide_user'], true)))
            continue;

        $temp_row[] = ['text' => $result['name_panel'], 'callback_data' => "changelocselectlo-{$result['code_panel']}"];
        if (count($temp_row) == 2) {
            $list_marzban_panel_users_change['inline_keyboard'][] = $temp_row;
            $temp_row = [];
        }
    }
    if (!empty($temp_row)) {
        $list_marzban_panel_users_change['inline_keyboard'][] = $temp_row;
    }
} else {
    foreach ($activePanelRows as $result) {
        if ($result['name_panel'] == $users['Processing_value_four'])
            continue;
        if ($result['hide_user'] != null and in_array($from_id, json_decode($result['hide_user'], true)))
            continue;
        $list_marzban_panel_users_change['inline_keyboard'][] = [
            ['text' => $result['name_panel'], 'callback_data' => "changelocselectlo-{$result['code_panel']}"]
        ];
    }
}
$list_marzban_panel_users_change['inline_keyboard'][] = [
    ['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backorder"],
];
$list_marzban_panel_userschange = json_encode($list_marzban_panel_users_change);


//------------------  [ listpanelusers test ]----------------//
$list_marzban_panel_usertest = ['inline_keyboard' => []];
foreach ($allPanelRows as $result) {
    if ($result['TestAccount'] != "ONTestAccount" || !in_array($result['agent'], [$users['agent'], "all"]))
        continue;
    if ($result['hide_user'] != null and in_array($from_id, json_decode($result['hide_user'], true)))
        continue;
    $list_marzban_panel_usertest['inline_keyboard'][] = [
        ['text' => $result['name_panel'], 'callback_data' => "locationtest_{$result['code_panel']}"]
    ];
}
$list_marzban_panel_usertest['inline_keyboard'][] = [
    ['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"],
];
$list_marzban_usertest = json_encode($list_marzban_panel_usertest);

//--------------------------------------------------
    $product = [];
    $stmt = $pdo->prepare("SELECT * FROM product WHERE Location = :text or Location = '/all' ");
    $stmt->bindParam(':text', $text, PDO::PARAM_STR);
    $stmt->execute();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $product[] = [$row['name_product']];
    }
    $list_product = [
        'keyboard' => [],
        'resize_keyboard' => true,
    ];
    $list_product['keyboard'][] = [
        ['text' => $textbotlang['Admin']['backAdminBtn']],
    ];
    foreach ($product as $button) {
        $list_product['keyboard'][] = [
            ['text' => $button[0]]
        ];
    }
    $json_list_product_list_admin = json_encode($list_product);
$payment = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['payAndGetService'], 'callback_data' => "confirmandgetservice"]],
        [['text' => $textbotlang['keyboard']['registerDiscountCode'], 'callback_data' => "aptdc"]],
        [['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"]]
    ]
]);
$paymentom = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['payAndGetService'], 'callback_data' => "confirmandgetservice"]],
        [['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"]]
    ]
]);
$change_product = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['price']], ['text' => $textbotlang['keyboard']['volume']], ['text' => $textbotlang['keyboard']['time']]],
        [['text' => $textbotlang['keyboard']['productName']], ['text' => $textbotlang['keyboard']['userType']], ['text' => "🔢 محدودیت IP"]],
        [['text' => $textbotlang['keyboard']['volumeResetType']], ['text' => $textbotlang['keyboard']['note']]],
        [['text' => $textbotlang['keyboard']['productLocation']], ['text' => $textbotlang['keyboard']['category']]],
        [['text' => $textbotlang['keyboard']['setInbound']], ['text' => $textbotlang['keyboard']['showFirstPurchase']]],
        [['text' => $textbotlang['keyboard']['productSaleStatus']]],
        [['text' => $textbotlang['keyboard']['hidePanel']], ['text' => $textbotlang['keyboard']['deleteAllHiddenPanels']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);

$keyboardprotocol = json_encode([
    'keyboard' => [
        [['text' => "vless"], ['text' => "vmess"], ['text' => "trojan"]],
        [['text' => "shadowsocks"]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
$MethodUsername = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['usernameSequential']]],
        [['text' => $textbotlang['keyboard']['numericIdRandom']]],
        [['text' => $textbotlang['keyboard']['customUsername']]],
        [['text' => $textbotlang['keyboard']['customUsernameRandom']]],
        [['text' => $textbotlang['keyboard']['customTextRandom']]],
        [['text' => $textbotlang['keyboard']['customTextSequential']]],
        [['text' => $textbotlang['keyboard']['numericIdSequential']]],
        [['text' => $textbotlang['keyboard']['agentCustomTextSequential']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
$panelPriceRows = [['customVolumePrice', 'extraVolumePrice'], ['extraTimePrice', 'customTimePrice']];
$panelLimitRows = [['minCustomVolume', 'maxCustomVolume'], ['minCustomTime', 'maxCustomTime']];
$panelTestRow = ['testServiceTime', 'testAccountVolume'];
$panelOptionRows = [
    'marzban' => [['manualCreateConfig', 'manageNodes'], ['panelName', 'deletePanel'], ['editPassword', 'editUsername'], ['editPanelUrl', 'setProtocolInbound'], ['renewalMethod', 'usernameMethod'], ['accountCreateLimit', 'changeUserGroup'], $panelTestRow, ...$panelPriceRows, ['changeLocationPrice'], ...$panelLimitRows, ['inboundDeactivate']],
    'marzneshin' => [['manualCreateConfig'], ['panelName', 'deletePanel'], ['editPassword', 'editUsername'], ['editPanelUrl', 'serviceSettings'], ['renewalMethod', 'usernameMethod'], ['accountCreateLimit', 'changeUserGroup'], $panelTestRow, ...$panelPriceRows, ['changeLocationPrice'], ...$panelLimitRows],
    'x-ui_single' => [['manualCreateConfig'], ['panelName', 'deletePanel'], ['editPassword', 'subLinkDomain'], ['editPanelUrl', 'setProtocolInbound'], ['renewalMethod', 'usernameMethod'], ['accountCreateLimit', 'changeUserGroup'], $panelTestRow, ...$panelPriceRows, ['changeLocationPrice'], ...$panelLimitRows],
    'hiddify' => [['manualCreateConfig'], ['panelName', 'deletePanel'], ['editPanelUrl', 'subLinkDomain'], ['renewalMethod', 'usernameMethod'], ['accountCreateLimit', 'changeUserGroup'], ['🔗 uuid admin'], $panelTestRow, ...$panelPriceRows, ['changeLocationPrice'], ...$panelLimitRows],
    'WGDashboard' => [['manualCreateConfig'], ['panelName', 'deletePanel'], ['editPassword'], ['editPanelUrl', 'setInboundId'], ['renewalMethod', 'usernameMethod'], ['accountCreateLimit', 'changeUserGroup'], $panelTestRow, ...$panelPriceRows, ['changeLocationPrice'], ...$panelLimitRows, ['inboundDeactivate']],
    'rebecca' => [['panelName', 'deletePanel'], ['editPassword'], ['editPanelUrl', 'setProtocolInbound'], ['renewalMethod', 'usernameMethod'], ['accountCreateLimit', 'changeUserGroup'], $panelTestRow, ...$panelPriceRows, ['changeLocationPrice'], ...$panelLimitRows, ['inboundDeactivate']],
    'ibsng' => [['panelName', 'deletePanel'], ['editPassword', 'editUsername'], ['editPanelUrl', 'setGroupName'], ['renewalMethod', 'usernameMethod'], ['accountCreateLimit', 'changeUserGroup'], ...$panelPriceRows, ...$panelLimitRows],
    'mirza_agent' => [['panelName', 'deletePanel'], ['editPassword'], ['editPanelUrl', 'panelSetting'], ['accountCreateLimit', 'changeUserGroup'], ...$panelPriceRows, ...$panelLimitRows],
    'Manualsale' => [['panelName', 'deletePanel'], ['usernameMethod'], ['accountCreateLimit', 'changeUserGroup'], ['addConfig', 'deleteConfig'], ['editConfig']],
];
$panelOptionRows['mikrotik'] = $panelOptionRows['ibsng'];
$panelOptionRows['nexora'] = $panelOptionRows['rebecca'];
$panelOptionRows['wg_mate'] = $panelOptionRows['rebecca'];
$panelOptions = [];
foreach ($panelOptionRows as $panelType => $panelRows) {
    $panelKeyboardRows = [[['text' => $textbotlang['keyboard']['panelFeatureStatus']]]];
    foreach ($panelRows as $panelRow) {
        $panelKeyboardRows[] = array_map(fn($key) => ['text' => $textbotlang['keyboard'][$key] ?? $key], $panelRow);
    }
    $panelKeyboardRows[] = [['text' => $textbotlang['keyboard']['hidePanelForUser']]];
    $panelKeyboardRows[] = [['text' => $textbotlang['keyboard']['removeFromHiddenList']]];
    $panelKeyboardRows[] = [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]];
    $panelOptions[$panelType] = json_encode(['keyboard' => $panelKeyboardRows, 'resize_keyboard' => true]);
}
if ($setting['statussupportpv'] == "onpvsupport") {
    $supportoption = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $textbotlang['textbot']['faq'], 'callback_data' => "fqQuestions"],
                ['text' => $textbotlang['keyboard']['sendMessageToSupport'], 'url' => "https://t.me/{$setting['id_support']}"],
            ],
            [
                ['text' => $textbotlang['keyboard']['backToMainMenu'], 'callback_data' => "backuser"]
            ],

        ]
    ]);
} else {
    $supportoption = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $textbotlang['textbot']['faq'], 'callback_data' => "fqQuestions"],
                ['text' => $textbotlang['keyboard']['sendMessageToSupport'], 'callback_data' => "support"],
            ],
            [
                ['text' => $textbotlang['keyboard']['backToMainMenu'], 'callback_data' => "backuser"]
            ],

        ]
    ]);
}
$adminrule = json_encode([
    'keyboard' => [
        [['text' => "administrator"], ['text' => "Seller"], ['text' => "support"]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
$helpedit = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['editName']], ['text' => $textbotlang['keyboard']['editDescription']]],
        [['text' => $textbotlang['keyboard']['editMedia']], ['text' => $textbotlang['keyboard']['editCategory']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
$Methodextend = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['resetVolumeTime']]],
        [['text' => $textbotlang['keyboard']['addTimeVolumeNextMonth']]],
        [['text' => $textbotlang['keyboard']['resetTimeAddVolume']]],
        [['text' => $textbotlang['keyboard']['resetVolumeAddTime']]],
        [['text' => $textbotlang['keyboard']['addTimeConvertVolume']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
$keyboardtimereset = json_encode([
    'keyboard' => [
        [['text' => "no_reset"], ['text' => "day"], ['text' => "week"]],
        [['text' => "month"], ['text' => "year"]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
$keyboardtypepanel = json_encode([
    'inline_keyboard' => [
        [
            ['text' => $textbotlang['keyboard']['marzban'], 'callback_data' => "typepanel#marzban"],
            ['text' => $textbotlang['keyboard']['marzneshin'], 'callback_data' => "typepanel#marzneshin"]
        ],
        [
            ['text' => $textbotlang['keyboard']['passargadPanel'], 'callback_data' => "typepanel#pasarguard"],
            ['text' => $textbotlang['keyboard']['mirzaAgentPanel'], 'callback_data' => "typepanel#mirza_agent"]
        ],
        [
            ['text' => $textbotlang['keyboard']['panelTypeSanaei'], 'callback_data' => 'typepanel#x-ui_single'],
            ['text' => $textbotlang['keyboard']['manualSale'], 'callback_data' => 'typepanel#Manualsale']
        ],
        [
            ['text' => $textbotlang['keyboard']['hiddify'], 'callback_data' => 'typepanel#hiddify'],
            ['text' => "WGDashboard", 'callback_data' => 'typepanel#WGDashboard']
        ],
        [
            ['text' => "ibsng", 'callback_data' => 'typepanel#ibsng'],
            ['text' => $textbotlang['keyboard']['mikrotik'], 'callback_data' => 'typepanel#mikrotik']
        ],
        [
            ['text' => $textbotlang['keyboard']['rebecca'], 'callback_data' => 'typepanel#rebecca'],
            ['text' => "Nexora", 'callback_data' => 'typepanel#nexora']
        ],
        [
            ['text' => "WG-Mate", 'callback_data' => 'typepanel#wg_mate']
        ],
        [
            ['text' => $textbotlang['Admin']['backAdminBtn'], 'callback_data' => 'admin']
        ]
    ],
]);

$panelechekc = count(array_filter($allPanelRows, fn($panel) => $panel['MethodUsername'] == "agentCustomTextSequential"));
if ($setting['inlinebtnmain'] == "oninline") {
    $keyboardagent = [
        'inline_keyboard' => [
            [
                ['text' => $textbotlang['keyboard']['bulkPurchase'], 'callback_data' => "kharidanbuh"],
                ['text' => $textbotlang['keyboard']['selectCustomName'], 'callback_data' => "selectname"]
            ],
            [
                ['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"]
            ]
        ],
        'resize_keyboard' => true
    ];
    if ($panelechekc == 0) {
        unset($keyboardagent['inline_keyboard'][0][1]);
    }
} else {
    $keyboardagent = [
        'keyboard' => [
            [['text' => $textbotlang['keyboard']['bulkPurchase']], ['text' => $textbotlang['keyboard']['selectCustomName']]],
            [['text' => $textbotlang['users']['backbtn']]]
        ],
        'resize_keyboard' => true
    ];
    if ($panelechekc == 0) {
        unset($keyboardagent['keyboard'][0][1]);
    }
}
$keyboardagent = json_encode($keyboardagent);
$Swapinokey = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['setApi'], 'callback_data' => "paygwopt-setApi"]],
        [['text' => $textbotlang['keyboard']['cashbackIranPay1'], 'callback_data' => "paygwopt-cashbackIranPay1"], ['text' => $textbotlang['keyboard']['setEducationIranPay1'], 'callback_data' => "paygwopt-setEducationIranPay1"]],
        [['text' => $textbotlang['keyboard']['minAmountIranPay1'], 'callback_data' => "paygwopt-minAmountIranPay1"], ['text' => $textbotlang['keyboard']['maxAmountIranPay1'], 'callback_data' => "paygwopt-maxAmountIranPay1"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);

$tronnowpayments = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['minAmountCryptoOffline'], 'callback_data' => "paygwopt-minAmountCryptoOffline"], ['text' => $textbotlang['keyboard']['maxAmountCryptoOffline'], 'callback_data' => "paygwopt-maxAmountCryptoOffline"]],
        [['text' => $textbotlang['keyboard']['setEducationCryptoOffline'], 'callback_data' => "paygwopt-setEducationCryptoOffline"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$configedit = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['configDetails']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
$iranpaykeyboard = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['apiIranPay'], 'callback_data' => "paygwopt-apiIranPay"]],
        [['text' => $textbotlang['keyboard']['minAmountIranPay3'], 'callback_data' => "paygwopt-minAmountIranPay3"], ['text' => $textbotlang['keyboard']['maxAmountIranPay3'], 'callback_data' => "paygwopt-maxAmountIranPay3"]],
        [['text' => $textbotlang['keyboard']['cashbackIranPay3'], 'callback_data' => "paygwopt-cashbackIranPay3"]],
        [['text' => $textbotlang['keyboard']['setEducationIranPay3'], 'callback_data' => "paygwopt-setEducationIranPay3"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$abangatewaykeyboard = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['apiIranPay4'], 'callback_data' => "paygwopt-apiIranPay4"], ['text' => $textbotlang['keyboard']['endpointIranPay4'], 'callback_data' => "paygwopt-endpointIranPay4"]],
        [['text' => $textbotlang['keyboard']['minAmountIranPay4'], 'callback_data' => "paygwopt-minAmountIranPay4"], ['text' => $textbotlang['keyboard']['maxAmountIranPay4'], 'callback_data' => "paygwopt-maxAmountIranPay4"]],
        [['text' => $textbotlang['keyboard']['dailyLimitIranPay4'], 'callback_data' => "paygwopt-dailyLimitIranPay4"]],
        [['text' => $textbotlang['keyboard']['cashbackIranPay4'], 'callback_data' => "paygwopt-cashbackIranPay4"]],
        [['text' => $textbotlang['keyboard']['setEducationIranPay4'], 'callback_data' => "paygwopt-setEducationIranPay4"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$supportcenter = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['setSupportId']]],
        [['text' => $textbotlang['keyboard']['addDepartment']], ['text' => $textbotlang['keyboard']['deleteDepartment']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
//------------------  [ list departeman ]----------------//
$departeman = [];
    $stmt = $pdo->prepare("SELECT * FROM departman");
    $stmt->execute();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $departeman[] = [$row['name_departman']];
    }
    $departemans = [
        'keyboard' => [],
        'resize_keyboard' => true,
    ];
    foreach ($departeman as $button) {
        $departemans['keyboard'][] = [
            ['text' => $button[0]]
        ];
    }
    $departemans['keyboard'][] = [
        ['text' => $textbotlang['Admin']['backAdminBtn']],
        ['text' => $textbotlang['Admin']['backMenuBtn']]
    ];
    $departemanslist = json_encode($departemans);
// list departeman
$list_departman = ['inline_keyboard' => []];
    $stmt = $pdo->prepare("SELECT * FROM departman");
    $stmt->execute();
    while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $list_departman['inline_keyboard'][] = [
            ['text' => $result['name_departman'], 'callback_data' => "departman_{$result['id']}"]
        ];
    }
$list_departman['inline_keyboard'][] = [
    ['text' => $textbotlang['users']['backbtn'], 'callback_data' => "backuser"],
];
$list_departman = json_encode($list_departman);
$active_panell = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['botReports']]],
    ],
    'resize_keyboard' => true
]);
$keyboardlinkapp = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['addApp']], ['text' => $textbotlang['keyboard']['deleteApp']]],
        [['text' => $textbotlang['keyboard']['editApp']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']], ['text' => $textbotlang['Admin']['backMenuBtn']]]
    ],
    'resize_keyboard' => true
]);
function KeyboardProduct($location, $query, $pricediscount, $datakeyboard, $statuscustom = false, $backuser = "backuser", $valuetow = null, $customvolume = "customsellvolume", $queryParams = [])
{
    global $pdo, $textbotlang, $from_id;
    $product = ['inline_keyboard' => []];
    $statusshowprice = select("shopSetting", "*", "Namevalue", "statusshowprice", "select")['value'];
    $stmt = $pdo->prepare($query);
    $stmt->execute($queryParams);
    if ($valuetow != null) {
        $valuetow = "-$valuetow";
    } else {
        $valuetow = "";
    }
    $countorder = null;
    while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $hide_panel = json_decode($result['hide_panel'], true);
        if (in_array($location, $hide_panel))
            continue;
        if ($result['one_buy_status'] == "1") {
            if ($countorder === null) {
                $stmts2 = $pdo->prepare("SELECT COUNT(*) FROM invoice WHERE Status != 'Unpaid' AND id_user = :id_user");
                $stmts2->bindValue(':id_user', $from_id);
                $stmts2->execute();
                $countorder = (int) $stmts2->fetchColumn();
            }
            if ($countorder != 0)
                continue;
        }
        if (intval($pricediscount) != 0) {
            $resultper = ($result['price_product'] * $pricediscount) / 100;
            $result['price_product'] = $result['price_product'] - $resultper;
        }
        $result['name_product']=alireza_service_badge($result).$result['name_product'];
        $namekeyboard = $result['name_product'] . " - " . number_format($result['price_product']) . $textbotlang['common']['labels']['toman'];
        if ($statusshowprice == "onshowprice") {
            $result['name_product'] = $namekeyboard;
        }
        if ($result['status_product'] == "disable" && str_starts_with($datakeyboard, "prodcutservice")) {
            $product['inline_keyboard'][] = [
                ['text' => $result['name_product'] . " | " . $textbotlang['keyboard']['productSoldOut'], 'callback_data' => "productsoldout"]
            ];
            continue;
        }
        $product['inline_keyboard'][] = [
            ['text' => $result['name_product'], 'callback_data' => "{$datakeyboard}{$result['code_product']}{$valuetow}"]
        ];
    }
    if ($statuscustom)
        $product['inline_keyboard'][] = [['text' => $textbotlang['users']['customSellVolume']['title'], 'callback_data' => $customvolume]];
    $product['inline_keyboard'][] = [
        ['text' => $textbotlang['users']['status']['backinfo'], 'callback_data' => $backuser],
    ];
    return json_encode($product);
}
function KeyboardCategory($location, $agent, $backuser = "backuser")
{
    global $pdo, $textbotlang;
    $stmts = $pdo->prepare("SELECT category, COUNT(*) AS c FROM product WHERE (Location = :location OR Location = '/all') AND agent = :agent GROUP BY category");
    $stmts->bindParam(':location', $location, PDO::PARAM_STR);
    $stmts->bindParam(':agent', $agent);
    $stmts->execute();
    $categoryCounts = [];
    foreach ($stmts->fetchAll(PDO::FETCH_ASSOC) as $catRow) {
        $categoryKey = mb_strtolower(trim((string) $catRow['category']), 'UTF-8');
        $categoryCounts[$categoryKey] = ($categoryCounts[$categoryKey] ?? 0) + (int) $catRow['c'];
    }
    $stmt = $pdo->prepare("SELECT * FROM category");
    $stmt->execute();
    $list_category = ['inline_keyboard' => [],];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if (empty($categoryCounts[mb_strtolower(trim((string) $row['remark']), 'UTF-8')]))
            continue;
        $list_category['inline_keyboard'][] = [['text' => $row['remark'], 'callback_data' => "categorynames_" . $row['id']]];
    }
    $list_category['inline_keyboard'][] = [
        ['text' => $textbotlang['keyboard']['backToPreviousMenu'], "callback_data" => $backuser],
    ];
    return json_encode($list_category);
}

function keyboardTimeCategory($name_panel, $agent, $callback_data = "producttime_", $callback_data_back = "backuser", $statuscustomvolume = false, $statusbtnextend = false)
{
    global $pdo, $textbotlang;
    $stmt = $pdo->prepare("SELECT (Service_time) FROM product WHERE (Location = :name_panel OR Location = '/all') AND  agent = :agent");
    $stmt->bindValue(':name_panel', $name_panel, PDO::PARAM_STR);
    $stmt->bindValue(':agent', $agent, PDO::PARAM_STR);
    $stmt->execute();
    $montheproduct = array_flip(array_flip($stmt->fetchAll(PDO::FETCH_COLUMN)));
    $monthkeyboard = ['inline_keyboard' => []];
    if (in_array("1", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['1day'], 'callback_data' => "{$callback_data}1"]
        ];
    }
    if (in_array("7", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['7day'], 'callback_data' => "{$callback_data}7"]
        ];
    }
    if (in_array("31", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['1'], 'callback_data' => "{$callback_data}31"]
        ];
    }
    if (in_array("30", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['1'], 'callback_data' => "{$callback_data}30"]
        ];
    }
    if (in_array("61", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['2'], 'callback_data' => "{$callback_data}61"]
        ];
    }
    if (in_array("60", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['2'], 'callback_data' => "{$callback_data}60"]
        ];
    }
    if (in_array("91", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['3'], 'callback_data' => "{$callback_data}91"]
        ];
    }
    if (in_array("90", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['3'], 'callback_data' => "{$callback_data}90"]
        ];
    }
    if (in_array("121", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['4'], 'callback_data' => "{$callback_data}121"]
        ];
    }
    if (in_array("120", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['4'], 'callback_data' => "{$callback_data}120"]
        ];
    }
    if (in_array("181", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['6'], 'callback_data' => "{$callback_data}181"]
        ];
    }
    if (in_array("180", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['6'], 'callback_data' => "{$callback_data}180"]
        ];
    }
    if (in_array("365", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['365'], 'callback_data' => "{$callback_data}365"]
        ];
    }
    if (in_array("0", $montheproduct)) {
        $monthkeyboard['inline_keyboard'][] = [
            ['text' => $textbotlang['common']['duration']['byVolume'], 'callback_data' => "{$callback_data}0"]
        ];
    }
    if ($statusbtnextend)
        $monthkeyboard['inline_keyboard'][] = [['text' => $textbotlang['keyboard']['renewCurrentPlan'], 'callback_data' => "exntedagei"]];
    if ($statuscustomvolume == true)
        $monthkeyboard['inline_keyboard'][] = [['text' => $textbotlang['users']['customSellVolume']['title'], 'callback_data' => "customsellvolume"]];
    $monthkeyboard['inline_keyboard'][] = [
        ['text' => $textbotlang['users']['status']['backinfo'], 'callback_data' => $callback_data_back]
    ];
    return json_encode($monthkeyboard);
}
$Startelegram = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['cashbackStar'], 'callback_data' => "paygwopt-cashbackStar"], ['text' => $textbotlang['keyboard']['setEducationStar'], 'callback_data' => "paygwopt-setEducationStar"]],
        [['text' => $textbotlang['keyboard']['minAmountStar'], 'callback_data' => "paygwopt-minAmountStar"], ['text' => $textbotlang['keyboard']['maxAmountStar'], 'callback_data' => "paygwopt-maxAmountStar"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$keyboardchangelimit = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['freeLimit']], ['text' => $textbotlang['keyboard']['generalLimit']]],
        [['text' => $textbotlang['keyboard']['resetAllUsersLimit']]],
        [['text' => $textbotlang['Admin']['backAdminBtn']]]
    ],
    'resize_keyboard' => true
]);
function KeyboardCategoryadmin()
{
    global $pdo, $textbotlang;
    $stmt = $pdo->prepare("SELECT * FROM category");
    $stmt->execute();
    $list_category = [
        'keyboard' => [],
        'resize_keyboard' => true,
    ];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $list_category['keyboard'][] = [['text' => $row['remark']]];
    }
    $list_category['keyboard'][] = [
        ['text' => $textbotlang['Admin']['backAdminBtn']],
    ];
    return json_encode($list_category);
}
$nowpayment_setting_keyboard = json_encode([
    'inline_keyboard' => [
        [['text' => $textbotlang['keyboard']['apiNowPayment'], 'callback_data' => "paygwopt-apiNowPayment"]],
        [['text' => $textbotlang['keyboard']['cashbackNowPayment'], 'callback_data' => "paygwopt-cashbackNowPayment"], ['text' => $textbotlang['keyboard']['setEducationNowPayment'], 'callback_data' => "paygwopt-setEducationNowPayment"]],
        [['text' => $textbotlang['keyboard']['minAmountNowPayment'], 'callback_data' => "paygwopt-minAmountNowPayment"], ['text' => $textbotlang['keyboard']['maxAmountNowPayment'], 'callback_data' => "paygwopt-maxAmountNowPayment"]],
        [['text' => $textbotlang['keyboard']['backToGateways'], 'callback_data' => "paygwlist"]],
    ]
]);
$paymentGateways = [
    'card' => ['label' => $textbotlang['keyboard']['cartToCartGateway'], 'setting' => 'Cartstatus', 'on' => 'oncard', 'off' => 'offcard', 'keyboard' => $CartManage],
    'plisio' => ['label' => 'Plisio', 'setting' => 'nowpaymentstatus', 'on' => 'onnowpayment', 'off' => 'offnowpayment', 'keyboard' => $NowPaymentsManage],
    'nowpayment' => ['label' => 'NOWPayments', 'setting' => 'statusnowpayment', 'on' => '1', 'off' => '0', 'keyboard' => $nowpayment_setting_keyboard],
    'iranpay1' => ['label' => $textbotlang['keyboard']['iranPay1Label'], 'setting' => 'statusSwapWallet', 'on' => 'onSwapinoBot', 'off' => 'offSwapinoBot', 'keyboard' => $Swapinokey],
    'iranpay2' => ['label' => $textbotlang['keyboard']['iranPay2Label'], 'setting' => 'statustarnado', 'on' => 'onternado', 'off' => 'offternado', 'keyboard' => $trnado],
    'iranpay4' => ['label' => $textbotlang['keyboard']['iranPay4Label'], 'setting' => 'statusiranpay4', 'on' => 'oniranpay4', 'off' => 'offiranpay4', 'keyboard' => $abangatewaykeyboard],
    'iranpay3' => ['label' => $textbotlang['keyboard']['iranPay3Label'], 'setting' => 'statusiranpay3', 'on' => 'oniranpay3', 'off' => 'offiranpay3', 'keyboard' => $iranpaykeyboard],
    'aqayepardakht' => ['label' => $textbotlang['keyboard']['aqayePardakhtGateway'], 'setting' => 'statusaqayepardakht', 'on' => 'onaqayepardakht', 'off' => 'offaqayepardakht', 'keyboard' => $aqayepardakht],
    'zarinpal' => ['label' => $textbotlang['keyboard']['zarinPalGateway'], 'setting' => 'zarinpalstatus', 'on' => 'onzarinpal', 'off' => 'offzarinpal', 'keyboard' => $keyboardzarinpal],
    'variza' => ['label' => $textbotlang['keyboard']['varizaGateway'], 'setting' => 'variza_status', 'on' => 'onvariza', 'off' => 'offvariza', 'keyboard' => $keyboardvariza],
    'digi' => ['label' => $textbotlang['keyboard']['cryptoOfflinePayment'], 'setting' => 'digistatus', 'on' => 'ondigi', 'off' => 'offdigi', 'keyboard' => $tronnowpayments],
    'star' => ['label' => 'Star Telegram', 'setting' => 'statusstar', 'on' => '1', 'off' => '0', 'keyboard' => $Startelegram],
];
function paymentGatewaysKeyboard()
{
    global $paymentGateways, $textbotlang;
    $rows = [];
    foreach ($paymentGateways as $key => $gateway) {
        $mark = getPaySettingValue($gateway['setting'], $gateway['off']) == $gateway['on'] ? '✅' : '❌';
        $rows[] = [['text' => "$mark {$gateway['label']}", 'callback_data' => "paygw-$key"]];
    }
    $rows[] = [['text' => $textbotlang['keyboard']['gatewaysGeneralSettings'], 'callback_data' => "none"]];
    $rows[] = [
        ['text' => $textbotlang['keyboard']['maxChargeBalance'], 'callback_data' => "maxbalanceaccount"],
        ['text' => $textbotlang['keyboard']['minChargeBalance'], 'callback_data' => "mainbalanceaccount"],
    ];
    $rows[] = [['text' => $textbotlang['keyboard']['walletAddress'], 'callback_data' => "walletaddress"]];
    return json_encode(['inline_keyboard' => $rows]);
}
$Exception_auto_cart_keyboard = json_encode([
    'keyboard' => [
        [['text' => $textbotlang['keyboard']['excludeUser']], ['text' => $textbotlang['keyboard']['removeUserFromList']]],
        [['text' => $textbotlang['keyboard']['showUserList']]],
        [['text' => $textbotlang['keyboard']['backToCardSettings']]]
    ],
    'resize_keyboard' => true
]);
function keyboard_config($config_split, $id_invoice, $back_active = true)
{
    global $textbotlang;
    $keyboard_config = ['inline_keyboard' => []];
    $keyboard_config['inline_keyboard'][] = [
        ['text' => $textbotlang['keyboard']['config'], 'callback_data' => "none"],
        ['text' => $textbotlang['keyboard']['configName'], 'callback_data' => "none"],
    ];
    for ($i = 0; $i < count($config_split); $i++) {
        $config = $config_split[$i];
        $split_config = explode("://", $config);
        $type_prtocol = $split_config[0];
        $split_config = $split_config[1] ?? '';
        if (isBase64($split_config)) {
            $split_config = base64_decode($split_config);
        }
        if ($type_prtocol == "vmess") {
            $split_config = json_decode($split_config, true)['ps'] ?? '';
        } else {
            $parts = explode("#", $split_config);
            $split_config = $parts[1] ?? $parts[0];
        }
        if ($type_prtocol==='https') $split_config=$textbotlang['alireza_service']['portal'];
        $keyboard_config['inline_keyboard'][] = [
            ['text' => $textbotlang['keyboard']['getConfig'], 'callback_data' => "configget_{$id_invoice}_$i"],
            ['text' => urldecode($split_config), 'callback_data' => "none"],
        ];

    }
    $keyboard_config['inline_keyboard'][] = [['text' => $textbotlang['keyboard']['getAllConfigs'], 'callback_data' => "configget_$id_invoice" . "_1520"]];
    if ($back_active) {
        $keyboard_config['inline_keyboard'][] = [['text' => $textbotlang['users']['status']['backinfo'], 'callback_data' => "product_$id_invoice"]];
    }
    return json_encode($keyboard_config);
}
$keyboard_buy = json_encode([
    'inline_keyboard' => [
        [
            ['text' => $textbotlang['keyboard']['buySubscription'], 'callback_data' => 'buy'],
        ],
    ]
]);
$keyboard_stat = json_encode([
    'inline_keyboard' => [
        [
            ['text' => $textbotlang['keyboard']['totalStats'], 'callback_data' => 'stat_all_bot'],
        ],
        [
            ['text' => $textbotlang['keyboard']['lastHourStats'], 'callback_data' => 'hoursago_stat'],
        ],
        [
            ['text' => $textbotlang['keyboard']['today'], 'callback_data' => 'today_stat'],
            ['text' => $textbotlang['keyboard']['yesterday'], 'callback_data' => 'yesterday_stat'],
        ],
        [
            ['text' => $textbotlang['keyboard']['currentMonth'], 'callback_data' => 'month_current_stat'],
            ['text' => $textbotlang['keyboard']['lastMonth'], 'callback_data' => 'month_old_stat'],
        ],
        [
            ['text' => $textbotlang['keyboard']['statsAtDate'], 'callback_data' => 'view_stat_time'],
        ]
    ]
]);
function keyboard_list_text($lang)
{
    global $textbotlang;
    $keyboard_text = ['inline_keyboard' => []];
    $keyboard_list_text = $textbotlang['bottext']['items'];
    $keyboard_text['inline_keyboard'][] = [
        ['text' => ($lang == 'fa' ? "✅" : "") . $textbotlang['bottext']['langs']['fa'], 'callback_data' => "bt_lang:fa"],
        ['text' => ($lang == 'en' ? "✅" : "") . $textbotlang['bottext']['langs']['en'], 'callback_data' => "bt_lang:en"],
        ['text' => ($lang == 'ru' ? "✅" : "") . $textbotlang['bottext']['langs']['ru'], 'callback_data' => "bt_lang:ru"],
        ['text' => ($lang == 'zh' ? "✅" : "") . $textbotlang['bottext']['langs']['zh'], 'callback_data' => "bt_lang:zh"],
    ];
    foreach ($keyboard_list_text as $data) {
        $keyboard_text['inline_keyboard'][] = [['text' => $data['label'], 'callback_data' => "bt_edit|$lang|{$data['key']}"]];
    }
    $keyboard_text['inline_keyboard'][] = [['text' => $textbotlang['bottext']['btn_close'], 'callback_data' => 'bt_close']];
    return json_encode($keyboard_text);
}
